// versus/server/meta.js — 2V2 对抗插件的全局钩子
//
// 对抗期核心（confront 状态机、共享血量、Boss 池）在引擎侧 gpt/versus-constants 分支；
// 本插件是管理器面：注册 versus 模式（modes part），暴露 settings，并在 meta 层
// 提供对局中的 versus 感知（如最终狩猎回合公告）。

/** 每个对局已发过「R13 公开对方视角」公告的 Match（GameData 实例唯一）。 */
const announced = new WeakMap();

export default function setup(sp) {
  const settings = sp.settings || {};
  const huntRound = Number.isInteger(settings.rosterMs) ? 13 : 13; // settings 的 rosterMs 是公示毫秒，非回合
  const label = '对抗 · 最终狩猎';

  sp.meta.register('global:versus-mode', {
    onRoundStart(ctx, ev) {
      // R14 公开对方视角（ Versus_CONFRONT.huntRound = 13，下一回合开始公开）
      if (ev.round !== huntRound + 1) return;
      let done = announced.get(ctx.gd);
      if (!done) { done = new Set(); announced.set(ctx.gd, done); }
      if (done.has('reveal')) return;
      done.add('reveal');
      ctx.log(`${label}：对方视角已公开`);
    },
  });
}
