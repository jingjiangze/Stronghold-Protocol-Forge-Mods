// watch-lineup/client/watchLineup.js — 房内观阵面板：自开关 + 队友「布阵」按钮 + 定稿棋盘渲染。
//
// 用到的面（都已合并）：
//   ctx.net.send('lineup', data)   ⇒ 线上是 { t:'pack.msg', pack:'watch-lineup', channel:'lineup', data }
//   ctx.net.on('lineup', fn)       ⇒ 只收自己包、自己声明过的通道
//   ctx.net.on('m.public', fn)     ⇒ 引擎类型原样透传：席位与存活从 players[] 来
//   ctx.net.on('m.field', fn)      ⇒ 引擎类型原样透传：服务端透传来的 m.field{prep:true, fieldId:'n:<pid>'} 在这儿
//   ctx.net.welcome()              ⇒ 自己的 playerId
//
// 渲染纪律：这里是 C 层面板，改不了对局——棋盘画错也只是画错。收到的 m.field 是服务端
// prepFieldMeta 的原样透传（服务端零计算），本面板不再加工数值，只做摆位展示。

const FEED_CAP = 10;
const DIR_TEXT = { LEFT: '←', RIGHT: '→', UP: '↑', DOWN: '↓' };
/** mount 的退订表按宿主挂（unmount(ctx) 只拿得到 host）：WeakMap 随宿主 GC，不添进程级留账。 */
const CLEANUPS = new WeakMap();

export function mount(ctx) {
  const host = ctx && ctx.host;
  if (!host || typeof host.appendChild !== 'function') return;
  const doc = host.ownerDocument || (typeof document !== 'undefined' ? document : null);
  if (!doc || typeof doc.createElement !== 'function') return;

  const net = ctx.net || null;
  const offs = [];
  const state = {
    me: null,
    players: [],            // m.public.players 的展示面
    on: false,              // 自开关的面板侧影子（服务端 Set 才是闸门真源）
    viewing: null,          // 正在看的 target playerId（最后一次点「布阵」的）
    board: null,            // 最近一帧 m.field{prep:true}
    pendingAt: 0,           // 最近一次查看请求发出的时间（未收到提示用）
    feed: [],
  };

  const card = doc.createElement('div');
  card.className = 'watch-lineup';
  host.appendChild(card);
  const title = doc.createElement('strong');
  title.className = 'watch-lineup__t';
  title.textContent = '观阵 · 查看队友布阵';
  card.appendChild(title);

  const hint = doc.createElement('div');
  hint.className = 'watch-lineup__hint';
  hint.textContent = '只读透传：服务端把队友 prep 期末定稿的棋盘原样转发，不做任何计算。战斗中查看时主画面会临时切到该棋盘，点「返回自己」恢复。';
  card.appendChild(hint);

  const toggle = doc.createElement('button');
  toggle.type = 'button';
  toggle.className = 'watch-lineup__toggle';
  toggle.textContent = '观看布阵：关';
  toggle.addEventListener('click', () => {
    const next = !state.on;
    if (!send('lineup', { action: next ? 'on' : 'off' })) return;
    state.on = next;
    if (!next) { state.viewing = null; state.board = null; }
    draw();
  });
  card.appendChild(toggle);

  const seats = doc.createElement('div');
  seats.className = 'watch-lineup__seats';
  card.appendChild(seats);

  const boardBox = doc.createElement('div');
  boardBox.className = 'watch-lineup__board';
  card.appendChild(boardBox);

  const feed = doc.createElement('div');
  feed.className = 'watch-lineup__feed';
  card.appendChild(feed);

  const note = (line) => {
    state.feed.push(line);
    while (state.feed.length > FEED_CAP) state.feed.shift();
    draw();
  };

  const send = (channel, data) => {
    if (!net || typeof net.send !== 'function') { note('发送失败：没有 ctx.net.send'); return false; }
    let ok = false;
    try { ok = net.send(channel, data) === true; } catch { ok = false; }
    if (!ok) note('发送被拒：通道未声明（CLIENT_CHANNEL_UNDECLARED）');
    return ok;
  };

  const nameOf = (pid) => {
    const p = state.players.find((x) => x.playerId === pid);
    return (p && p.name) || pid;
  };

  const drawSeats = () => {
    while (seats.firstChild) seats.removeChild(seats.firstChild);
    if (!state.players.length) {
      const p = doc.createElement('div');
      p.className = 'watch-lineup__empty';
      p.textContent = '还没收到席位表（m.public 未到，或这局还没开始）。';
      seats.appendChild(p);
      return;
    }
    for (const pl of state.players) {
      if (pl.playerId === state.me) continue;
      const line = doc.createElement('div');
      line.className = 'watch-lineup__seat' + (pl.alive === false ? ' is-dead' : '');
      const who = doc.createElement('span');
      who.className = 'watch-lineup__who';
      who.textContent = (pl.name || pl.playerId) + (pl.alive === false ? '（已淘汰）' : '');
      line.appendChild(who);
      if (state.on && pl.alive !== false) {
        const b = doc.createElement('button');
        b.type = 'button';
        b.className = 'watch-lineup__btn';
        b.textContent = '布阵';
        b.addEventListener('click', () => {
          state.viewing = pl.playerId;
          state.pendingAt = Date.now();
          if (send('lineup', { action: 'view', target: pl.playerId })) {
            note('已请求查看 ' + (pl.name || pl.playerId) + ' 的布阵…');
          }
          draw();
        });
        line.appendChild(b);
      }
      seats.appendChild(line);
    }
  };

  const drawBoard = () => {
    while (boardBox.firstChild) boardBox.removeChild(boardBox.firstChild);
    if (!state.board) {
      const p = doc.createElement('div');
      p.className = 'watch-lineup__empty';
      p.textContent = state.viewing && state.on
        ? '还没收到 ' + nameOf(state.viewing) + ' 的棋盘（目标无效 / 已淘汰 / 另一组隐秘 / 发出后 1.5 秒未回 = 被服务端拒绝）。'
        : '打开开关后点队友旁的「布阵」。';
      boardBox.appendChild(p);
      return;
    }
    const f = state.board;
    const head = doc.createElement('div');
    head.className = 'watch-lineup__bhead';
    head.textContent = nameOf(state.viewing) + ' 的定稿布阵' + (f.stageId ? ' · ' + f.stageId : '');
    boardBox.appendChild(head);

    const rect = f.rect && typeof f.rect === 'object' ? f.rect : null;
    const grid = doc.createElement('div');
    grid.className = 'watch-lineup__grid';
    if (rect && Number.isFinite(rect.w) && rect.w > 0 && Number.isFinite(rect.h) && rect.h > 0) {
      grid.style.position = 'relative';
      grid.style.paddingBottom = (rect.h / rect.w) * 62 + '%';
    }
    const units = Array.isArray(f.units) ? f.units : [];
    const onBoard = units.filter((u) => u && u.area === 'board');
    for (const u of onBoard) {
      const chip = doc.createElement('span');
      chip.className = 'watch-lineup__unit' + (u.golden ? ' is-golden' : '');
      chip.textContent = (u.name || u.defId || '?') + (Number.isFinite(u.tier) && u.tier > 1 ? ' T' + u.tier : '') + (u.dir && DIR_TEXT[u.dir] ? ' ' + DIR_TEXT[u.dir] : '');
      if (rect && Number.isFinite(u.x) && Number.isFinite(u.y)) {
        chip.style.left = ((u.x - rect.x + 0.5) / rect.w) * 100 + '%';
        chip.style.top = ((u.y - rect.y + 0.5) / rect.h) * 100 + '%';
      }
      grid.appendChild(chip);
    }
    if (!onBoard.length) {
      const p = doc.createElement('div');
      p.className = 'watch-lineup__empty';
      p.textContent = '棋盘上没有单位。';
      grid.appendChild(p);
    }
    boardBox.appendChild(grid);

    const hand = units.filter((u) => u && u.area === 'hand').map((u) => u.name || u.defId);
    const temp = units.filter((u) => u && u.area === 'temp').map((u) => u.name || u.defId);
    const fx = Array.isArray(f.effects) ? f.effects.map((e) => (e && (e.name || e.id)) || '').filter(Boolean) : [];
    const bench = doc.createElement('div');
    bench.className = 'watch-lineup__bench';
    bench.textContent = '整备区：' + (hand.length ? hand.join('、') : '（空）')
      + ' · 临时：' + (temp.length ? temp.join('、') : '（空）')
      + ' · 效果：' + (fx.length ? fx.join('、') : '（无）')
      + ' · 下一波敌人：' + (Array.isArray(f.nextEnemies) ? f.nextEnemies.length : 0) + ' 个';
    boardBox.appendChild(bench);
  };

  const draw = () => {
    toggle.textContent = '观看布阵：' + (state.on ? '开' : '关');
    toggle.className = 'watch-lineup__toggle' + (state.on ? ' is-on' : '');
    drawSeats();
    drawBoard();
    while (feed.firstChild) feed.removeChild(feed.firstChild);
    for (const line of state.feed) {
      const p = doc.createElement('div');
      p.className = 'watch-lineup__line';
      p.textContent = line;
      feed.appendChild(p);
    }
  };

  if (net && typeof net.on === 'function') {
    const w = typeof net.welcome === 'function' ? net.welcome() : null;
    if (w && typeof w.playerId === 'string') state.me = w.playerId;
    offs.push(net.on('welcome', (msg) => {
      if (msg && typeof msg.playerId === 'string') { state.me = msg.playerId; draw(); }
    }));
    offs.push(net.on('m.public', (msg) => {
      const list = msg && Array.isArray(msg.players) ? msg.players : [];
      state.players = list.filter((p) => p && typeof p.playerId === 'string')
        .map((p) => ({ playerId: p.playerId, name: p.name || '', alive: p.alive }));
      draw();
    }));
    // 服务端透传来的定稿棋盘：prep 侦查帧的特征是 prep:true + fieldId 'n:<pid>'；
    // 自己战场的 m.field（live 战斗帧）不带 prep ⇒ 不会被误当布阵。
    offs.push(net.on('m.field', (msg) => {
      if (!msg || msg.prep !== true) return;
      if (typeof msg.fieldId !== 'string' || !msg.fieldId.startsWith('n:')) return;
      const pid = msg.fieldId.slice(2);
      if (!state.viewing || pid !== state.viewing) return;
      state.board = msg;
      draw();
    }));
  }

  draw();

  const cleanup = () => {
    for (const off of offs) { try { off(); } catch { /* 退订失败忽略 */ } }
  };
  CLEANUPS.set(host, cleanup);
  return cleanup;
}

export function unmount(ctx) {
  const host = ctx && ctx.host;
  if (!host) return;
  const cleanup = CLEANUPS.get(host);
  if (typeof cleanup === 'function') { try { cleanup(); } catch { /* 退订失败忽略 */ } }
  CLEANUPS.delete(host);
  if (typeof host.querySelector === 'function') {
    const card = host.querySelector('.watch-lineup');
    if (card && card.parentNode) card.parentNode.removeChild(card);
  }
}
