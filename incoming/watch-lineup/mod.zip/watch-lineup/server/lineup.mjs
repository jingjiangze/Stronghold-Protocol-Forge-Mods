// watch-lineup/server/lineup.mjs — 观阵的服务端半边：只读透传，零计算。
//
// 两个面都用已合并的引擎能力，不依赖任何在审 PR：
//   · uses:["matchClass"] + combat:true ⇒ 子类上的 handlePackMsg(playerId, msg)（README「包与自己的面板通信」§28.14）
//   · client.panels[].messages + server.modules[].channels ⇒ 通道两边都声明（线上名 <包id>.<短名>）
// 透传的载体是引擎现成的 Match.prepFieldMeta（休整侦查的序列化读法：board/hand/temp 单位 + 效果列 +
// 下一波敌人预览的纯拼装）——本模块不改它、不包装它、不算任何数值，拿到什么发什么。
//
// 纪律（与 duel-mode 同款）：
//   · handlePackMsg 会收到**任何包**的 pack.msg ⇒ 先认 msg.pack，再认房间（this.mods 里没本包一个分支都不进）；
//   · matchClass 是进程级包装器 ⇒ 每局的状态挂 this（随房销毁），模块层不留在局状态；
//   · 静态确定性扫描禁 process/globalThis/require/eval/new Function ⇒ 本文件一个都没有，也不 import 任何东西。

export const PACK_ID = 'watch-lineup';
/** 必须与 pack.json 的 client.panels[].messages / server.modules[].channels 逐字相同。 */
export const CHANNELS = ['lineup'];

/** 房间集合自门控（判据形状照抄 isDuelRoom / isXieRoom：mods.packs[].id）。 */
export function isWatchRoom(mods) {
  return !!(mods && Array.isArray(mods.packs) && mods.packs.some((p) => p && p.id === PACK_ID));
}

/**
 * 纯判定：观看者 viewerId 现在能不能拉 targetId 的定稿棋盘。规则与引擎内置实现
 * （Stronghold-Protocol-Forge#8 / Deploy#1/#2 的 MatchWatch._watchPrepBoard）逐条同源：
 *   ① 开关是观看者自己的，没开 = 一律拒（吞掉，不转发不报错——面板侧自己有未收到提示）；
 *   ② 目标必须存在且存活；
 *   ③ live field 命名碰撞：clientCombat 的战场 fieldId 恰为 'n:<pid>'（combat.js _ccField）——
 *      目标正在战场上时，棋盘请求让位给引擎自己的 g.watch 战场分支（观战语义归引擎）；
 *   ④ boss/hidden 分组规则：最终攻势 / 隐秘核心期间不能读另一组的布阵（bossGroupOf 同源判断）。
 * 本函数不碰 this，全部输入显式传入 ⇒ 测试不用起对局。
 * @param {{
 *   on?: Set<string> | null,
 *   viewerId?: string,
 *   targetId?: unknown,
 *   players?: Map<string, { alive?: boolean, playerId?: string }> | null,
 *   fields?: Array<{ fieldId?: string }> | null,
 *   bossGroupOf?: ((ps: unknown) => unknown) | null,
 * }} o
 * @returns {{ ok: true, target: { alive?: boolean, playerId?: string } } | { ok: false, why: string }}
 */
export function decideView(o = {}) {
  const on = o.on instanceof Set ? o.on : null;
  const viewerId = typeof o.viewerId === 'string' ? o.viewerId : '';
  if (!on || !on.has(viewerId)) return { ok: false, why: 'switch-off' };
  if (typeof o.targetId !== 'string' || !o.targetId) return { ok: false, why: 'bad-target' };
  if (o.targetId === viewerId) return { ok: false, why: 'self' };
  const players = o.players instanceof Map ? o.players : null;
  const target = players ? players.get(o.targetId) : null;
  if (!target || target.alive !== true) return { ok: false, why: 'dead-or-unknown' };
  const fields = Array.isArray(o.fields) ? o.fields : [];
  if (fields.some((f) => f && f.fieldId === 'n:' + o.targetId)) return { ok: false, why: 'live-field' };
  const groupOf = typeof o.bossGroupOf === 'function' ? o.bossGroupOf : null;
  if (groupOf) {
    const viewer = players ? players.get(viewerId) : null;
    const gT = target ? groupOf(target) : null;
    const gV = viewer ? groupOf(viewer) : null;
    if (gT && gV && gT !== gV) return { ok: false, why: 'other-group-hidden' };
  }
  return { ok: true, target };
}

export function registerServer(host) {
  if (!host || typeof host.matchClass !== 'function') return;
  host.matchClass((Base) => class WatchLineupMatch extends Base {
    /** 局内状态挂在 Match 实例上 ⇒ 随房销毁；模块层（进程级）不留在局状态。 */
    __lineup() {
      if (!this.__lineupState) this.__lineupState = { on: new Set(), views: 0, refused: 0 };
      return this.__lineupState;
    }

    handlePackMsg(playerId, msg) {
      // 归属判据：引擎把任何包的 pack.msg 都送进所有包装器，通道名不是命名空间 ⇒ 先认包。
      if (!msg || msg.pack !== PACK_ID) return undefined;
      // 房间没选本包 ⇒ 一个分支都不进（不消费、不计数），转发照上游。
      if (!isWatchRoom(this.mods)) return undefined;
      if (msg.channel !== CHANNELS[0]) return undefined;
      const id = String(playerId ?? '');
      const st = this.__lineup();
      const d = msg.data && typeof msg.data === 'object' ? msg.data : {};
      if (d.action === 'on') {
        st.on.add(id);
        return true; // 消费：开关广播没有别人要听
      }
      if (d.action === 'off') {
        st.on.delete(id);
        return true;
      }
      if (d.action === 'view') {
        const v = decideView({
          on: st.on,
          viewerId: id,
          targetId: d.target,
          players: this.players,
          fields: this.fields,
          bossGroupOf: (ps) => this.bossGroupOf(ps),
        });
        if (!v.ok) { st.refused += 1; return true; } // 拒绝也消费：不外溢给同房
        // 零计算透传：prepFieldMeta 是引擎现成的读法（本模块不算任何数值），结果原样给观看者。
        try {
          this.sendTo(id, this.prepFieldMeta(v.target));
          st.views += 1;
        } catch { /* 透传失败不影响对局：引擎的对局状态一行未动 */ }
        return true;
      }
      return undefined;
    }
  });
}
