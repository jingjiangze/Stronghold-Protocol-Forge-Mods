// watch-lineup/test/gate.test.mjs — decideView 纯判定：不起对局，把每一条闸门钉死。
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { decideView, isWatchRoom, PACK_ID, CHANNELS } from '../server/lineup.mjs';

const players = new Map([
  ['p_0', { playerId: 'p_0', alive: true }],   // boss A 组
  ['p_1', { playerId: 'p_1', alive: true }],   // 无组（普通回合 / 淘汰者口径）
  ['p_2', { playerId: 'p_2', alive: false }],  // 已淘汰
  ['p_3', { playerId: 'p_3', alive: true }],   // boss B 组
]);

test('开关是观看者自己的：没开一律拒，开了才放行', () => {
  const on = new Set(['p_1']);
  const base = { on, viewerId: 'p_1', targetId: 'p_0', players };
  assert.equal(decideView(base).ok, true);
  assert.equal(decideView({ ...base, on: new Set() }).why, 'switch-off');
  assert.equal(decideView({ ...base, on: null }).why, 'switch-off');
});

test('目标判据：不存在 / 已淘汰 / 查自己 都拒', () => {
  const on = new Set(['p_1']);
  const base = { on, viewerId: 'p_1', players };
  assert.equal(decideView({ ...base, targetId: '' }).why, 'bad-target');
  assert.equal(decideView({ ...base, targetId: 'nope' }).why, 'dead-or-unknown');
  assert.equal(decideView({ ...base, targetId: 'p_2' }).why, 'dead-or-unknown');
  assert.equal(decideView({ ...base, targetId: 'p_1' }).why, 'self');
});

test('战斗中（fields 里每条 fieldId 恰为 n:<pid>）仍可看 —— live-field 闸门已撤销（2026-10-21 真机验收）', () => {
  const on = new Set(['p_1']);
  const base = { on, viewerId: 'p_1', targetId: 'p_0', players };
  // 曾因「命名碰撞」把这条路堵死；撤销判据：战斗中棋盘冻结，透传与战场观战互不冲突
  assert.equal(decideView({ ...base, fields: [{ fieldId: 'n:p_0' }] }).ok, true, 'COMBAT 中看队友棋盘应放行');
  assert.equal(decideView({ ...base, fields: [{ fieldId: 'u' }] }).ok, true);
  assert.equal(decideView({ ...base, fields: [] }).ok, true);
});

// ⚠ 桩必须与引擎同形：Match.bossGroupOf 每次调用都**新建包装对象**（infra.js:155-157），
// 唯一稳定的是 players 数组。用字符串桩曾掩盖「引用比较 ⇒ 同组也误杀」的真机 bug（2026-10-21）。
const GROUP_A = ['p_4', 'p_5'];
const GROUP_B = ['p_3', 'p_0'];
const players2 = new Map([
  ['p_0', { playerId: 'p_0', alive: true }],   // boss B 组（组身份 = GROUP_B 数组引用）
  ['p_3', { playerId: 'p_3', alive: true }],   // boss B 组（与 p_0 同组）
  ['p_4', { playerId: 'p_4', alive: true }],   // boss A 组
  ['p_5', { playerId: 'p_5', alive: true }],   // boss A 组（与 p_4 同组）
  ['p_1', { playerId: 'p_1', alive: true }],   // 无组
]);
const bossGroupOf = (ps) => {
  if (!ps) return null;
  if (GROUP_A.includes(ps.playerId)) return { wave: { id: 'a' }, players: GROUP_A, side: GROUP_A.indexOf(ps.playerId) === 1 ? 'R' : 'L' };
  if (GROUP_B.includes(ps.playerId)) return { wave: { id: 'b' }, players: GROUP_B, side: GROUP_B.indexOf(ps.playerId) === 1 ? 'R' : 'L' };
  return null;
};

test('boss/hidden 分组：同组放行、跨组拒、无组自由观战', () => {
  const withGroups = { players: players2, bossGroupOf };
  // 同组搭档（p_4 ⇄ p_5）：必须放行 —— 引用比较会在这里误杀（真机验收 2026-10-21 的回归）
  assert.equal(decideView({ ...withGroups, on: new Set(['p_4']), viewerId: 'p_4', targetId: 'p_5' }).ok, true, '同组搭档应放行');
  assert.equal(decideView({ ...withGroups, on: new Set(['p_5']), viewerId: 'p_5', targetId: 'p_4' }).ok, true, '反向同组也应放行');
  // 跨组（p_0 看 p_4）：拒
  assert.equal(decideView({ ...withGroups, on: new Set(['p_0']), viewerId: 'p_0', targetId: 'p_4' }).why, 'other-group-hidden');
  // 无组观看者（p_1）看任一组：自由观战 ⇒ 放行
  assert.equal(decideView({ ...withGroups, on: new Set(['p_1']), viewerId: 'p_1', targetId: 'p_4' }).ok, true);
  assert.equal(decideView({ ...withGroups, on: new Set(['p_1']), viewerId: 'p_1', targetId: 'p_0' }).ok, true);
  // 查自己仍然拒
  assert.equal(decideView({ ...withGroups, on: new Set(['p_4']), viewerId: 'p_4', targetId: 'p_4' }).why, 'self');
});

test('淘汰的观看者也可以看（与引擎 PR 同口径：开关在谁身上谁说了算）', () => {
  const on = new Set(['p_2']);
  assert.equal(decideView({ on, viewerId: 'p_2', targetId: 'p_0', players }).ok, true);
});

test('放行时把目标原样带出（模块拿它调 prepFieldMeta）', () => {
  const v = decideView({ on: new Set(['p_1']), viewerId: 'p_1', targetId: 'p_0', players });
  assert.equal(v.ok, true);
  assert.deepEqual(v.target, { playerId: 'p_0', alive: true });
});

test('房间自门控：mods.packs 里没有本包 ⇒ isWatchRoom=false', () => {
  assert.equal(isWatchRoom({ packs: [{ id: PACK_ID }] }), true);
  assert.equal(isWatchRoom({ packs: [{ id: 'other' }] }), false);
  assert.equal(isWatchRoom(null), false);
  assert.equal(isWatchRoom(undefined), false);
});

test('通道名与 pack id 一致性（防手滑改两边）', () => {
  assert.deepEqual(CHANNELS, ['lineup']);
  assert.equal(PACK_ID, 'watch-lineup');
});
