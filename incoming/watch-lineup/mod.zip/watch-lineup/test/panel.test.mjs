// watch-lineup/test/panel.test.mjs — 面板用假 DOM 与假 net 跑：不发真请求也能钉住
// 「按了才发、发的是哪条通道与载荷、m.field prep 帧才渲染、退订真的撤掉」。
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { mount, unmount } from '../client/watchLineup.js';

function fakeDoc() {
  const el = (tag) => {
    const node = {
      tag, children: [], className: '', textContent: '', type: '', style: {}, parentNode: null,
      get firstChild() { return node.children[0] || null; },
      appendChild(c) { c.parentNode = node; node.children.push(c); return c; },
      removeChild(c) { node.children = node.children.filter((x) => x !== c); c.parentNode = null; return c; },
      addEventListener(ev, fn) { (node.listeners ||= {})[ev] = fn; },
      querySelector(sel) { return node.children.find((c) => sel === '.' + c.className) || null; },
      click() { node.listeners?.click?.({}); },
    };
    return node;
  };
  return { createElement: el };
}

function fakeNet(opts = {}) {
  const sent = [];
  const subs = [];
  return {
    sent, subs,
    welcome: () => (opts.welcome ?? null),
    send: (channel, data) => { sent.push({ channel, data }); return opts.ok === false ? false : true; },
    on: (type, fn) => { subs.push({ type, fn }); return () => { const i = subs.findIndex((s) => s.fn === fn); if (i >= 0) subs.splice(i, 1); }; },
    emit(type, msg) { for (const s of subs.filter((x) => x.type === type)) s.fn(msg); },
  };
}

const ctxOf = (net) => {
  const doc = fakeDoc();
  const host = doc.createElement('div');
  host.ownerDocument = doc;
  return { doc, host, net };
};

const hasCls = (c, cls) => (' ' + (c.className || '') + ' ').includes(' ' + cls + ' ');

/** 卡片是 host 的唯一子节点，元素都挂在卡片里 —— 用遍历找，不假设层级。类名按包含匹配（is-golden 等修饰共存）。 */
const find = (root, cls) => {
  for (const c of root.children || []) {
    if (hasCls(c, cls)) return c;
    const hit = find(c, cls);
    if (hit) return hit;
  }
  return null;
};
const findAll = (root, cls, out = []) => {
  for (const c of root.children || []) {
    if (hasCls(c, cls)) out.push(c);
    findAll(c, cls, out);
  }
  return out;
};

test('mount：开关默认关；点开关发 {action:"on"}，再点发 {action:"off"}', () => {
  const net = fakeNet({ welcome: { playerId: 'p_1' } });
  const { host } = ctxOf(net);
  mount({ host, net });
  const toggle = find(host, 'watch-lineup__toggle');
  assert.ok(toggle, '开关在');
  assert.match(toggle.textContent, /关/);
  toggle.click();
  assert.deepEqual(net.sent[0], { channel: 'lineup', data: { action: 'on' } });
  assert.match(toggle.textContent, /开/);
  toggle.click();
  assert.deepEqual(net.sent[1], { channel: 'lineup', data: { action: 'off' } });
  assert.match(toggle.textContent, /关/);
});

test('开关关着：不画任何「布阵」按钮（服务端也不会放行）', () => {
  const net = fakeNet({ welcome: { playerId: 'p_1' } });
  const { host } = ctxOf(net);
  mount({ host, net });
  net.emit('m.public', { players: [{ playerId: 'p_0', name: 'A', alive: true }] });
  assert.equal(findAll(host, 'watch-lineup__btn').length, 0);
});

test('开关开着：每个存活队友一枚「布阵」；点击发 {action:"view", target}；自己与已淘汰的不给按钮', () => {
  const net = fakeNet({ welcome: { playerId: 'p_1' } });
  const { host } = ctxOf(net);
  mount({ host, net });
  find(host, 'watch-lineup__toggle').click(); // on
  net.emit('m.public', { players: [
    { playerId: 'p_0', name: 'A', alive: true },
    { playerId: 'p_1', name: '我', alive: true },
    { playerId: 'p_2', name: '亡', alive: false },
  ] });
  const btns = findAll(host, 'watch-lineup__btn');
  assert.equal(btns.length, 1, '只有 A 有按钮');
  btns[0].click();
  assert.deepEqual(net.sent[1], { channel: 'lineup', data: { action: 'view', target: 'p_0' } });
});

test('m.field：只有 prep:true 的 n: 帧才被当布阵渲染；自己战场帧与别人不渲染', () => {
  const net = fakeNet({ welcome: { playerId: 'p_1' } });
  const { host } = ctxOf(net);
  mount({ host, net });
  find(host, 'watch-lineup__toggle').click();
  net.emit('m.public', { players: [{ playerId: 'p_0', name: 'A', alive: true }] });
  findAll(host, 'watch-lineup__btn')[0].click(); // 请求查看 A ⇒ state.viewing = 'p_0'
  const board = () => find(host, 'watch-lineup__board');
  net.emit('m.field', { fieldId: 'n:p_0', prep: true, rect: { x: 0, y: 0, w: 12, h: 7 }, units: [{ area: 'board', x: 3, y: 2, name: '煌心', tier: 2, golden: true, dir: 'RIGHT' }], effects: [], nextEnemies: [{}] });
  assert.ok(find(board(), 'watch-lineup__unit'), '渲染了单位');
  assert.match(find(board(), 'watch-lineup__bhead').textContent, /A 的定稿布阵/);
  net.emit('m.field', { fieldId: 'f_normal', live: true, units: [] }); // 自己战场帧：不动
  assert.match(find(board(), 'watch-lineup__bhead').textContent, /A 的定稿布阵/);
  net.emit('m.field', { fieldId: 'n:p_9', prep: true, units: [] }); // 别人的：不动
  assert.match(find(board(), 'watch-lineup__bhead').textContent, /A 的定稿布阵/);
  assert.equal(findAll(board(), 'watch-lineup__unit').length, 1);
});

test('send 失败（通道未声明）：开关本地不翻转', () => {
  const net = fakeNet({ welcome: { playerId: 'p_1' }, ok: false });
  const { host } = ctxOf(net);
  mount({ host, net });
  find(host, 'watch-lineup__toggle').click();
  assert.match(find(host, 'watch-lineup__toggle').textContent, /关/);
});

test('unmount：卡片摘掉、退订撤掉', () => {
  const net = fakeNet({ welcome: { playerId: 'p_1' } });
  const { host } = ctxOf(net);
  mount({ host, net });
  const before = net.subs.length;
  assert.ok(before > 0);
  unmount({ host });
  assert.equal(host.children.length, 0);
  assert.equal(net.subs.length, 0, `退订后应为 0，实际 ${net.subs.length}（before=${before}）`);
});
