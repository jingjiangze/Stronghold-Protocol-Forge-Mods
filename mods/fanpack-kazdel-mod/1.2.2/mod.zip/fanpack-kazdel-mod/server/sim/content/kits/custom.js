// server/sim/content/kits/custom.js — kit aliases for the fan-made content pack's chess (its chess.json, PACKS.md).
//
// A custom piece reuses the hand-authored kit of the official chess of the SAME operator (same charId → same
// skills, talents and blackboards), so 红豆 behaves exactly like its official counterpart. Operators the season
// already ships at that tier need no entry at all: the pack extends that official piece (docs/research/
// custom-operators.json `extend`) instead of creating a second one. Every piece the pack adds itself is
// hand-authored below (docs/CUSTOM.md §6.3) — nothing falls back to the generic kit.
//
// Keyed by the custom chess id; `setupUnitKit` looks up baseId → id → suffix-less id, so one entry covers the
// normal and the elite piece.

import OFFICIAL_VIGNA from './ops/chess_char_1_05-vigna.js';
import { skillBbOf, skillRec } from './shared/tier1.js';
import { COLS } from '../../constants.js';
import { hypot } from '../../detmath.js';
import { hasHp, periodicDamage } from '../../damage.js';
import { bodyInKeys } from '../../body.js';
import { frontOf } from '../../dir.js';
import { sortEnemyTargets } from '../../targeting.js';
import { PRIO_REVIVE } from '../items/battle.js';

const of = (reg, id) => (reg && typeof reg[id] === 'function' ? reg[id] : null);

/** `{ [customChessId]: kitFn }` — aliases to an official kit of the same operator. */
const ALIASES = {
  chess_char_9_01_a: of(OFFICIAL_VIGNA, 'chess_char_1_05_a'), // 红豆
};

// ---------------------------------------------------------------------------------------------------------------
// Hand-authored kits for the pack's own pieces (docs/CUSTOM.md §6.3). Every number comes from the chess record's
// blackboards (its chess.json ← character_table); the lines marked [ASSUMED] are details the text does not
// carry. All twelve: Mon3tr, 凯尔希, 逻各斯, 维什戴尔, 阿斯卡纶, 霜叶, 煌, 坚雷, 阿米娅, 闪灵, 陨星 and 赫德雷.

const MONSTR_TOKEN = 'token_10050_monstr_prosts'; // 重构体 — a hand card the mode gives Mon3tr's owner
const WISDEL_TOKEN = 'token_10035_wisdel_wward'; // 魂灵之影 — 维什戴尔's summon (talent 2 / 爆裂黎明)
/** 魂灵之影 "最多存在3个" (the token record's `deployLimit`) — talent 2 死魂灵的余息 / S3 爆裂黎明 share it. */
const WISDEL_SHADOW_CAP = 3;
/** 死魂灵的余息 "在魂灵之影周围时获得迷彩" [ASSUMED: the 8 neighbours and its own tile, 1.5 tiles]. */
const WISDEL_CAMO_RANGE = 1.5;
/** 维什戴尔 S3 爆裂黎明 "溅射范围大幅扩大": the blackboard carries no radius, but PRTS's 备注 for the skill gives it
 *  outright ("施加锁定、普通攻击、溅射均可对空，攻击溅射半径2.5") — official, not a reading. */
const WISDEL_S3_SPLASH = 2.5;
/** 煌 S3 沸腾爆裂 收尾: PRTS 备注 "对前方3×3区域内的所有敌人造成一次物理伤害（碰撞判定，可对空）" — the circle of
 *  radius 1.5 around the front tile's centre covers exactly those 9 tiles (its corners are √2 ≈ 1.41 away). */
const HUANG_BURST_RADIUS = 1.5;
/** 煌 S3 的切割 / 攻防爬坡节奏: PRTS 备注 "前8秒内每秒更新一次攻防属性…9s时攻防属性更新至最大属性值". */
const HUANG_RAMP_SEC = 9;

const num = (v, d = 0) => (typeof v === 'number' && Number.isFinite(v) ? v : (typeof v === 'string' && v.trim() !== '' && Number.isFinite(+v) ? +v : d));
const on = (u) => !!u && u.alive && u.deployed && !u.removed;
const talentBb = (chess, i) => ((chess?.talents || []).find((t) => t && t.index === i)?.bb) ?? {};
/** Drop zero / non-finite entries (a zero mod is noise in the buff list). */
const mods = (m) => { const o = {}; for (const k of Object.keys(m)) { const v = m[k]; if (typeof v === 'number' && Number.isFinite(v) && v !== 0) o[k] = v; } return o; };
/** An attack-interval change in seconds as the mod's fraction of the unit's base attack time. */
const batPct = (sec, chess) => { const b = num(chess?.stats?.bat, 1) || 1; const v = num(sec) / b; return v ? Math.max(-0.9, v) : 0; };
/** The unit's summon of that token id on the field (the mode turns talent summons into hand cards). */
const tokenOf = (battle, unit, tokenId) => battle.allyUnits.find((t) => on(t) && t.kind === 'token' && t.ownerUnit === unit && t.defId === tokenId) || null;
/** Mon3tr's 重构体 on the field. */
const prostOf = (battle, unit) => tokenOf(battle, unit, MONSTR_TOKEN);
/** `t` is that Mon3tr's own 重构体 (`profile.healThrough(healer, target)` — no battle at hand there). */
const isProstsOf = (t, unit) => !!t && t.kind === 'token' && t.defId === MONSTR_TOKEN && t.ownerUnit === unit;
const neighbors = (a, b) => Math.abs(a.tileR - b.tileR) <= 1 && Math.abs(a.tileC - b.tileC) <= 1;
/** Periodic check while the unit is on the field. */
const whileOn = (battle, unit, sec, fn) => { battle.every(sec, () => { if (on(unit)) fn(); }, { owner: unit }); };
/** Is the tile of `a` inside `b`'s current attack range? */
const inRangeOf = (b, a) => {
  if (!b) return false;
  const key = a.tileR * COLS + a.tileC;
  if (b.rangeKeySet) return b.rangeKeySet.has(key);
  return Array.isArray(b.rangeKeys) && b.rangeKeys.includes(key);
};

// Mon3tr — T5 链愈师. Trait 恢复友方单位生命，且会在3个友方单位间跳跃，每次跳跃治疗量降低25%: the profession layer
// reads the trait blackboard (attack@chain.max_target / atk_scale), so nothing to author. 
//   天赋1 自我修复: the 重构体 grants allies around it +15% ATK, and a heal of it by Mon3tr or itself jumps once
//     more without the chain falloff [ASSUMED: the extra jump targets the nearest injured ally in heal range].
//   天赋2 战术协同: a heal by the unit or its 重构体 gives the target (and the healer) +20 ASPD for 10 s, no stack.
//   策略：熔毁 (S3): 25 s — ATK +250%, BAT −1.5 s, block +2, max HP +5000, 80 HP/s drain (true, can kill), attacks
//     deal true damage and heal itself for 50% ATK; it moves onto the 重构体's tile when the skill starts (a
//     【移动】 = Battle.moveRedeploy) and — "技能结束或受到致命伤害时，返回初始位置" — returns to its own tile both
//     when the skill ends and when a lethal blow lands while it runs (a 'fatal' saver at PRIO_REVIVE: the 【返回】 is
  //     the same onEnd path). PRTS 备注: 技能期间不死，受到致命伤害结算后**立即结束技能**（即返回）✓ matches the saver;
  //     HP is restored [ASSUMED: the 备注 says nothing about HP after the 不死, and a 0-HP unit cannot stand].
const PACK_KITS = {
  chess_char_9_21_a: (bb, chess) => {
    const t0 = talentBb(chess, 0), t1 = talentBb(chess, 1);
    const auraAtk = num(t0.atk, 0.15);
    return {
      // Mon3tr is the ONE healer 重构体 accepts: PRTS 重构体 备注 "持有禁疗（可以被Mon3tr无视）" — `profile.healThrough
      // (healer, target)` is what the heal pipeline / heal targeting read (damage.js heal, Battle.injuredAlliesInKeys,
      // ai.js doHeal; the shape upstream's own Mon3tr kit uses, kits/ops/op-monstr.js — 0.2.0 replaced the v0.1.3
      // `healThroughNoHeal` flag with it, see DESIGN §23.42).
      // canHitFly false: his record says so (医疗表默认 true), and 策略：熔毁 把他变成攻击者时"不能对空中敌方单位攻击"
      // [user report 2026-10-06] — the kit trait is where a pack piece pins its profile (professions.js resolveProfile).
      trait: { healThrough: (healer, a) => isProstsOf(a, healer), canHitFly: false },
      skill: {
        kind: 'duration',
        duration: num(bb.duration, 25),
        mods: mods({
          atkPct: num(bb.atk),
          batPct: batPct(bb.base_attack_time, chess),
          blockCnt: num(bb.block_cnt),
          hpFlat: num(bb.max_hp),
        }),
        attack: {
          dmgType: 'true',
          onHit(ctx) {
            const u = ctx.unit, scale = num(bb['attack@heal_scale']);
            if (on(u) && scale > 0) ctx.battle.heal(u, u, u.s.atk * scale, { tags: ['skill', 'monstr'] });
          },
        },
        onTick(ctx) {
          const u = ctx.unit, dps = num(bb.damage_per_second);
          if (!on(u) || !(dps > 0)) return;
          u.mem.monstrDrain = num(u.mem.monstrDrain) + num(ctx.dt);
          while (u.mem.monstrDrain >= 1) {
            u.mem.monstrDrain -= 1;
            ctx.battle.dealDamage(u, u, { amount: dps, type: 'true', isSkill: true, tags: ['skill', 'monstr'] });
          }
        },
        onStart(ctx) {
          const { battle, unit } = ctx;
          const tk = prostOf(battle, unit);
          // PRTS 备注 of 策略：熔毁 spells the flow out: ① 撤退场上的重构体（返回待部署区）② 在它原先的位置执行
          // 【移动】，并在**原位置**部署一个「路标形态」的重构体作为【返回】移动的标志物. So the 重构体 is withdrawn
          // (back to hand) and the 【返回】 is the same redeploy path home — matching what this hook does.
          // "场上不存在重构体时技能不能开启" (the client's skchr_monstr_3 `_onlyAvailableWhenTokenValid`) is the
          // `install` guard below; this branch only backstops a start that slipped through (and pays the charge back).
          if (!tk) { ctx.skill?.end('noToken'); ctx.skill?.addCharge(1); return; }
          if (unit.tileR === tk.tileR && unit.tileC === tk.tileC) return;
          const home = { r: unit.tileR, c: unit.tileC, tok: { r: tk.tileR, c: tk.tileC } };
          battle.retreat(tk, { reason: 'expired', permanent: true });
          const fromX = unit.x, fromY = unit.y;
          if (!battle.moveRedeploy(unit, home.tok.r, home.tok.c)) return;
          unit.mem.monstrHome = home;
          // the official flow leaves a 路标形态 重构体 on the original tile; holding it has the same effect for the
          // rules that matter (isReservedTile): 维什戴尔's 魂灵之影 can no longer take the tile Mon3tr must return to.
          battle.holdTile(unit, home.r, home.c);
          battle.fx('teleport', { x: unit.x, y: unit.y, id: unit.id, fromX, fromY });
        },
        onEnd(ctx) {
          const { battle, unit } = ctx;
          const home = unit.mem.monstrHome;
          unit.mem.monstrHome = null;
          if (!home || !on(unit)) { battle.releaseTile(unit); return; }
          const fromX = unit.x, fromY = unit.y;
          if (!battle.moveRedeploy(unit, home.r, home.c)) { battle.releaseTile(unit); return; }
          battle.releaseTile(unit);
          battle.fx('teleport', { x: unit.x, y: unit.y, id: unit.id, fromX, fromY });
          battle.spawnToken(unit, MONSTR_TOKEN, home.tok.r, home.tok.c);
        },
      },
      talents: [
        { install(battle, unit) { // 自我修复
          const aura = () => {
            if (!on(unit)) return;
            const tk = prostOf(battle, unit);
            if (tk) {
              for (const a of battle.allyUnits) {
                if (!on(a) || a === tk || !neighbors(a, tk)) continue;
                battle.addBuff(a, { key: 'monstr:prost', duration: 1.5, refresh: 'extend', mods: { atkPct: auraAtk }, tags: ['talent'] });
              }
            }
            battle.after(1, aura, { owner: unit });
          };
          aura();
          // 重构体 受到自身和Mon3tr治疗时，可额外进行一次不会衰减的治疗跳跃
          battle.on('heal', (c) => {
            if (!(num(c.amount) > 0) || c.opts?.regen) return;
            if (c.source !== unit && c.source !== prostOf(battle, unit)) return;
            const tk = prostOf(battle, unit);
            if (!tk || c.target !== tk || unit.mem.monstrJumping) return;
            const ally = battle.allyUnits
              .filter((a) => on(a) && a !== c.target && a.hp < a.s.maxHp - 1e-6 && neighbors(a, tk))
              .sort((a, b) => a.hp / a.s.maxHp - b.hp / b.s.maxHp)[0];
            if (!ally) return;
            unit.mem.monstrJumping = true;
            try { battle.heal(c.source, ally, num(c.amount), { tags: ['talent', 'monstr'] }); } finally { unit.mem.monstrJumping = false; }
          }, { owner: unit, priority: 20 });
        } },
        { install(battle, unit) { // 战术协同
          battle.on('heal', (c) => {
            if (!(num(c.amount) > 0) || c.opts?.regen) return;
            const tk = prostOf(battle, unit);
            if (c.source !== unit && !(tk && c.source === tk)) return;
            const buff = { key: 'monstr:coord', duration: num(t1.buff_duration, 10), refresh: 'extend', mods: { aspd: num(t1.attack_speed, 20) }, tags: ['talent'] };
            if (on(c.target)) battle.addBuff(c.target, buff);
            if (c.source !== c.target && on(c.source)) battle.addBuff(c.source, { ...buff });
          }, { owner: unit, priority: 10 });
        } },
      ],
      install(battle, unit) { // 策略：熔毁 — 受到致命伤害时返回初始位置
        // PRTS 重构体 备注: "Mon3tr因移动之外的原因退场时强制撤退场上的重构体" — knocked out or withdrawn (the
        // 熔毁 【移动】 is a moveRedeploy, not a death, and it withdraws the 重构体 itself in onStart)
        battle.on('death', (c) => {
          if (c.unit !== unit) return;
          battle.releaseTile(unit);
          const tk = prostOf(battle, unit);
          if (tk) battle.retreat(tk, { reason: 'expired', permanent: true });
        }, { owner: unit });
        // "场上不存在重构体时技能不能开启" (the client's skchr_monstr_3 `_onlyAvailableWhenTokenValid`, and the same
        // guard as the official Mon3tr's kit — kits/ops/op-monstr.js): EVERY activation path is refused while no 重构体
        // stands. Without it the skill auto-fires as soon as 技力 is full (its rule is DEFAULT and her 精一 record's
        // DEFAULT skill IS 熔毁), and 熔毁 makes her a true-damage attacker that no longer heals — which is exactly what
        // the owner saw as 「Mon3tr 不放重构体不会治疗干员」(report 2026-10-08).
        const sk = unit.skill;
        if (sk && sk.id === 'skchr_monstr_3' && !Object.prototype.hasOwnProperty.call(sk, 'activate')) {
          const activate = sk.activate;
          Object.defineProperty(sk, 'activate', {
            configurable: true, writable: true, enumerable: false,
            value(reason, opts) { return prostOf(battle, unit) ? activate.call(this, reason, opts) : false; },
          });
        }
        // A lethal blow while the skill runs does not knock it out: it returns home (the skill's own onEnd does the
        // 【返回】 + puts a fresh 重构体 back) and its HP is restored [ASSUMED]. Priority PRIO_REVIVE: a 坚固维式重锤
        // 不死 window (−99, holdsUndying) runs first and is not consumed, so a held Mon3tr never returns (the same
        // "持有不死的情况下不会触发" reading as 史尔特尔's 余烬), while 埃芒加德 / M3茧甲 (below it) step aside.
        battle.on('fatal', (c) => {
          if (c.unit !== unit || c.prevented) return;
          if (!unit.skill || !unit.skill.active) return; // the 【返回】 line belongs to the skill
          c.prevented = true;
          battle.heal(unit, unit, unit.s.maxHp, { self: true, ignoreHealFree: true, silent: true });
          unit.skill.end('fatal');
        }, { owner: unit, priority: PRIO_REVIVE });
      },
    };
  },

  // 凯尔希 — T4 医师. Her Mon3tr (token_10002_kalts_mon3tr) is a hand card the mode hands her; the token record
  // already carries its 25 s redeploy time.
  //   天赋1 Mon3tr: 优先治疗自身和Mon3tr (the heal picker's content hook `heal.prefer`, server/sim/ai.js — her own
  //     tile first, then the token; a unit the hook does not return still heals, this is a reorder, not a filter) and
  //     "Mon3tr不在凯尔希攻击范围内时防御力降至0" (a short defPct −1 buff kept up while the token stands outside her
  //     range). The talent's third clause (the token counts as a hand card here) is the pack's own model.
  //   天赋2 不毁重构: Mon3tr knocked out (not retreated) → the 8 surrounding tiles are stunned for 3 s and take
  //     1200 true damage.
  //   指令：熔毁 (S3, 18 s): Mon3tr gains DEF +120 % and an ATK bonus decaying from +160 % to +0 % (1 s steps), its
  //     damage type turns true, and if it killed nothing while the skill ran 凯尔希 loses 50 % of her max HP when it
  //     ends. "该技能与Mon3tr绑定" only means the buffs land on the token (she buffs nothing else), so nothing to gate.
  chess_char_9_18_a: (bb, chess) => {
    const KALTS_TOKEN = 'token_10002_kalts_mon3tr';
    const atkFrom = num(bb['attack@atk'], 1.6);
    const defUp = num(bb['attack@def'], 1.2);
    const penalty = num(bb['attack@hp_ratio'], 0.5);
    return {
      trait: {
        heal: {
          mode: 'single',
          prefer(battle, unit, cands) { // 优先治疗自身和Mon3tr
            if (cands.includes(unit)) return unit;
            const tk = tokenOf(battle, unit, KALTS_TOKEN);
            return tk && cands.includes(tk) ? tk : null;
          },
        },
      },
      skill: {
        kind: 'duration',
        duration: num(bb.duration, 18),
        onStart(ctx) {
          ctx.unit.mem.kaltsKills = 0;
          ctx.unit.mem.kaltsMelt = 0;
        },
        onTick(ctx) {
          const { battle, unit, dt } = ctx;
          const tk = tokenOf(battle, unit, KALTS_TOKEN);
          if (!tk) return;
          unit.mem.kaltsMelt = num(unit.mem.kaltsMelt) + num(dt);
          if (unit.mem.kaltsMelt < 1) return;
          unit.mem.kaltsMelt = 0;
          // 攻击力从 +160% 逐渐降低至 +0%: re-grant the pair every second at the fraction of the skill left
          const dur = num(unit.skill?.duration, 18);
          const left = Math.max(0, num(unit.skill?.timeLeft, dur));
          const frac = dur > 0 ? left / dur : 0;
          battle.addBuff(tk, {
            key: 'kalts:melt', refresh: 'replace', duration: Math.max(left, 0.1),
            mods: mods({ defPct: defUp, atkPct: atkFrom * frac }), tags: ['skill', 'kalts'],
          });
        },
        onEnd(ctx) {
          const { battle, unit } = ctx;
          if (num(unit.mem.kaltsKills) > 0 || !on(unit)) return; // 技能期间未击杀任何敌人
          const loss = unit.s.maxHp * penalty;
          if (loss > 0) battle.dealDamage(unit, unit, { amount: loss, type: 'true', isSkill: true, tags: ['skill', 'kalts'] });
        },
      },
      talents: [
        { install(battle, unit) { // 天赋1 Mon3tr — Mon3tr不在凯尔希攻击范围内时防御力降至0
          whileOn(battle, unit, 0.25, () => {
            const tk = tokenOf(battle, unit, KALTS_TOKEN);
            if (!tk) return;
            if (inRangeOf(unit, tk)) battle.removeBuff(tk, 'kalts:outrange');
            // a 0.4 s buff refreshed every 0.25 s: it lapses on its own the moment the token is gone / out of reach
            else battle.addBuff(tk, { key: 'kalts:outrange', duration: 0.4, refresh: 'extend', mods: { defPct: -1 }, visible: true, tags: ['talent'] });
          });
        } },
        { install(battle, unit) { // 不毁重构
          battle.on('kill', (c) => {
            const tk = tokenOf(battle, unit, KALTS_TOKEN);
            if (!tk || c.victim !== tk) return;
            if (c.reason === 'retreat' || c.reason === 'expired') return; // 不包括撤退
            if (tk.mem.kaltsKills != null) tk.mem.kaltsKills++;
            if (unit.mem.kaltsKills != null) unit.mem.kaltsKills++;
            for (const e of battle.foesInRadius(tk.tileC, tk.tileR, 1)) {
              if (!e.alive) continue;
              battle.applyStatus(e, 'stun', { duration: 3, source: unit });
              battle.dealDamage(unit, e, { amount: 1200, type: 'true', isSkill: true, tags: ['talent', 'kalts'] });
            }
          }, { owner: unit });
        } },
      ],
      install(battle, unit) { // 指令：熔毁 — "伤害类型变为真实" while the skill runs
        // The 'hit' hook runs before mitigation and the pipeline re-reads `dmg.type` after it (damage.js), so the
        // token's own normal attacks land as 真实伤害 for the skill's duration; a phys/arts one keeps its dodge roll
        // off (真实伤害 is not dodged).
        battle.on('hit', (c) => {
          if (!unit.skill || !unit.skill.active) return;
          if (c.dmg.type !== 'phys' && c.dmg.type !== 'arts') return;
          const tk = tokenOf(battle, unit, KALTS_TOKEN);
          if (!tk || c.source !== tk) return;
          c.dmg.type = 'true';
          c.dmg.canDodge = false;
        }, { owner: unit });
      },
    };
  },

  // 逻各斯 — T6 核心术师. Trait 攻击造成法术伤害 is the corecaster default (ranged/arts/bolt), nothing to author.
  //   天赋1 语汇演化: on every attack, a `prob` roll fires an EXTRA arts hit of atk_scale × ATK at a random targetable
  //     enemy inside 逻各斯's range and slows it for `sluggish` s. [ASSUMED: "攻击范围内一个随机目标" — a uniform pick
  //     over the whole range, the main target included (the text excludes none).]
  //   天赋2 剜魂具辞: every attack marks its targets with resFlat `magic_resistance` (−10) and artsTakenFlat
  //     `atk_addition` (+150) for `duration` s — the flat half is the engine mod `artsTakenFlat` (buffs.js, applied
  //     after mitigation in damage.js), the official "受到的法术伤害提高N点" attribute.
  //   延异视阈 (S3): 持续时间无限 ⇒ kind 'toggle' — ATK +`atk` (160 % normal / 220 % elite), up to 3 targets at once
  //     and the skill's own (expanded) range. "使攻击范围内敌方子弹的飞行速度大幅降低" = enemy projectiles inside the
  //     range are slowed to projectile_move_scale of their speed while it runs (a per-tick sweep, a flag on the
  //     projectile so a shell is only slowed once), and "技能结束时将其全部清除" = onEnd drops every enemy projectile
  //     inside the range (the range is still the skill's own while onEnd runs).
  chess_char_9_22_a: (bb, chess, def) => {
    const t0 = talentBb(chess, 0), t1 = talentBb(chess, 1);
    const prob = num(t0.prob), extraScale = num(t0.atk_scale), slow = num(t0.sluggish);
    const carve = num(t1.duration, 5), carveRes = num(t1.magic_resistance), carveArts = num(t1.atk_addition);
    const slowFactor = num(bb.projectile_move_scale, 1);
    // S1 (skchr_logos_1) is authored in `skills` as well, so its numbers must come from ITS OWN blackboard (bb is the
    // SELECTED skill's) — and the range grid from its own record.
    const logos1 = skillBbOf(chess, 'skchr_logos_1');
    const logos1Grid = skillRec(chess, 'skchr_logos_1')?.rangeGrid ?? null;
    const logos1KillScale = num(logos1['attack@kill_atk_scale']);
    const logos1KillDamage = num(logos1['attack@kill_damage'], 9999999);
    const onGrid = (unit, x, y) => !unit.rangeKeySet || unit.rangeKeySet.has(Math.round(y) * COLS + Math.round(x));
    const enemyProj = (battle, unit) => battle.projectiles.list.filter((p) => p.source && p.source.side === 'enemy' && onGrid(unit, p.x, p.y));
    return {
      skill: {
        kind: 'toggle', // 持续时间无限
        mods: mods({ atkPct: num(bb.atk) }),
        targeting: { maxTargets: Math.max(1, Math.floor(num(bb['attack@max_target'], 1))), rangeGrid: def?.skill?.rangeGrid ?? null },
        onTick({ battle, unit }) {
          if (!(slowFactor > 0) || slowFactor >= 1) return;
          // PRTS 备注: "减速效果只对水平坐标位于范围内的、阵营为敌方的部分弹道生效，受影响的弹道的飞行速度/角速度
          // 降低至0.05倍" — `projectile_move_scale` is that 0.05, applied once per projectile. The engine's projectiles
          // are straight lines with a single `speed`, so there is no angular velocity to slow as well.
          for (const p of enemyProj(battle, unit)) {
            if (p.logosSlowed) continue;
            p.logosSlowed = true;
            p.speed *= slowFactor;
          }
        },
        onEnd({ battle, unit }) {
          // PRTS 备注: "技能结束时的效果受缴械类效果制约"
          if (unit.s.flags.disarm) return;
          const hit = enemyProj(battle, unit);
          if (!hit.length) return;
          const list = battle.projectiles.list;
          for (const p of hit) {
            const i = list.indexOf(p);
            if (i >= 0) list.splice(i, 1); // 清除: dropped without resolving, so nothing hits
          }
        },
      },      skills: {
        // S1 (skchr_logos_1): 攻击范围扩大、攻击力 +40 %/+70 %；攻击范围内生命值低于自身攻击力 90 %/120 % 的敌人
        // 「立刻倒下」，并对另一个随机目标造成等于该敌人生命值的法术伤害 — 持续时间无限（同样是 toggle，开启后不再关闭）。
        // 阈值比的是敌人的最大生命（官方「生命值低于…的敌人」），斩杀用黑板里的 attack@kill_damage。
        // 注意：`skills` 的值必须是 SkillSpec **对象**（selectSkillSpec 直接把它当 spec 用）——写成工厂函数会让
        // SkillRuntime 拿到一个函数，kind 回落到棋子记录里的 kind（赫德雷 S2 就是这样变成每次技力满都重开的）。
        skchr_logos_1: {
          kind: 'toggle',
          mods: mods({ atkPct: num(logos1.atk) }),
          ...(logos1Grid ? { targeting: { rangeGrid: logos1Grid } } : {}),
          onTick({ battle, unit }) {
            if (!(logos1KillScale > 0) || !unit.alive) return;
            const keys = Array.isArray(unit.rangeKeys) ? unit.rangeKeys : [];
            if (!keys.length) return;
            const limit = num(unit.s.atk) * logos1KillScale;
            for (const e of battle.enemiesInKeys(keys, unit, unit.profile)) {
              if (!e.alive || e.side !== 'enemy' || e.s.flags.invulnerable) continue;
              if (!(num(e.s.maxHp) < limit)) continue;
              const pool = battle.enemiesInKeys(keys, unit, unit.profile).filter((o) => o !== e && o.alive && o.side === 'enemy');
              const hp = num(e.s.maxHp);
              battle.dealDamage(unit, e, { amount: logos1KillDamage, type: 'arts', isSkill: true, tags: ['skill', 'logos'] });
              const extra = pool.length ? battle.rng.pick(pool) : null;
              if (extra && extra.alive) battle.dealDamage(unit, extra, { amount: hp, type: 'arts', isSkill: true, tags: ['skill', 'logos'] });
            }
          },
        },
      },      talents: [
        { install(battle, unit) { // 语汇演化
          battle.on('beforeAttack', (c) => {
            if (c.attacker !== unit || !(prob > 0) || !(extraScale > 0)) return;
            if (!battle.rng.chance(prob)) return;
            const keys = unit.rangeKeys;
            if (!keys || !keys.length) return;
            const foes = battle.enemiesInKeys(keys, unit, unit.profile);
            if (!foes.length) return;
            const t = foes[Math.min(foes.length - 1, Math.floor(battle.rng() * foes.length))];
            if (!t) return;
            battle.dealDamage(unit, t, { amount: unit.s.atk * extraScale, type: 'arts', canDodge: false, tags: ['talent', 'logos'] });
            if (slow > 0) battle.applyStatus(t, 'sluggish', { duration: slow, source: unit });
            battle.fx('extraAttack', { x: t.x, y: t.y, id: unit.id });
          }, { owner: unit });
        } },
        { install(battle, unit) { // 剜魂具辞
          battle.on('hit', (c) => {
            if (c.source !== unit || !c.dmg.isAttack) return;
            if (!c.target || c.target.side !== 'enemy') return;
            battle.addBuff(c.target, {
              key: 'logos:carve', duration: carve, refresh: 'replace', visible: true, tags: ['talent'],
              mods: mods({ resFlat: carveRes, artsTakenFlat: carveArts }),
            });
          }, { owner: unit, priority: 10 });
        } },
      ],
    };
  },

  // 维什戴尔 — T6 投掷手 (bombarder). Trait 攻击对小范围的地面敌人造成两次物理伤害（第二次为余震）: the profession
  // layer already reads the trait blackboard (battle field 0.9, splash, `attack@append_atk_scale` 0.5, shockTimes 2), so
  // nothing to author — her 余震 instances carry the tag 'aftershock' (professions.js).
  //   天赋1 好礼: the main target of an attack takes attack@main_atk_scale × ATK and is marked with a 残影; an 余震
  //     that reaches a marked enemy explodes with attack@prob chance, dealing attack@bomb_atk_scale × ATK phys to every
  //     enemy within attack@range_radius and stunning them for attack@stun s. PRTS 备注: the 残影 lasts forever, does not
  //     stack and disappears with her (a `death` hook clears the marks); every 余震 rolls independently; the explosion is
  //     中点判定 and hits air units; the ×main_atk_scale part only applies to normal attacks / 余震 (not to skill hits).
  //   天赋2 死魂灵的余息: "部署后立刻在攻击范围内召唤一个魂灵之影，在魂灵之影周围时获得迷彩" — every deployment summons one
  //     魂灵之影 on a free deployable tile of her range (PRTS 备注 "部署时优先在距离自身最近的>地图下方行>地图左侧列可部署位
  //     部署"), at most WISDEL_SHADOW_CAP standing ("最多存在3个"). The token is `placeable: false` in the pack's tokens.json,
  //     so this summon (and S3's) is the only way it reaches the field — the engine's own fallback is off under a
  //     hand-authored kit. It never normal-attacks (trait noAttack) and is 禁疗; its skill (AUTO, 5 SP over time)
  //     strikes an enemy of her own range (残影-less ones first, never air units) with 1 × its ATK arts, `sluggish` s
  //     停顿, a 残影 and 0-2 SP. She has 迷彩 while she stands beside one of them (PRTS 备注: the 迷彩 does not lift by
  //     blocking; the token "仅在登场时尝试给予" it).
  //     [ASSUMED] "在魂灵之影周围" = within 1.5 tiles (its own tile and the 8 neighbours); the poll re-grants the 迷彩
  //     whenever she is back near any of her shadows.
  //   爆裂黎明 (S3, kind 'ammo' 6): ATK +150 %, BAT +2.9 s (an absolute addition, 2.1 → 5.0 s), attacks at
  //     attack@atk_scale_3 × ATK with a much wider splash (attack 溅射半径 2.5, PRTS 备注) and 好礼 always procs
  //     (attack@prob 1 — read per roll, so it lapses with the skill). "可随时停止" has no automatic counterpart: the
  //     ammo kind ends the skill when the last bullet is spent.
  chess_char_9_10_a: (bb, chess) => {
    const t0 = talentBb(chess, 0);
    const mainScale = num(t0['attack@main_atk_scale'], 1.15);
    const boomProb = num(t0['attack@prob'], 0.15);
    const boomScale = num(t0['attack@bomb_atk_scale'], 1.5);
    const boomStun = num(t0['attack@stun'], 1);
    const boomRadius = num(t0['attack@range_radius'], 1.1);
    const skillProb = num(bb['attack@prob']);   // 1 while the skill runs
    const skillScale = num(bb['attack@atk_scale_3'], 1);
    /** Her 魂灵之影 on the field. */
    const shadowsOf = (battle, host) => battle.allyUnits.filter((t) => on(t) && t.kind === 'token' && t.ownerUnit === host && t.defId === WISDEL_TOKEN);
    /** The free deployable tile of her range a 魂灵之影 takes (nearest to her > lower row > left column), or null. */
    const shadowTile = (battle, host) => {
      let best = null, bd = Infinity;
      for (const k of host.rangeKeys ?? []) {
        const r = Math.floor(k / COLS), c = k % COLS;
        if (!battle.grid.inRect(r, c) || !battle.grid.canStand(r, c, { ranged: true }) || battle.isReservedTile(r, c)) continue;
        const d = hypot(r - host.tileR, c - host.tileC);
        if (d < bd - 1e-9 || (Math.abs(d - bd) <= 1e-9 && (r < best[0] || (r === best[0] && c < best[1])))) { bd = d; best = [r, c]; }
      }
      return best;
    };
    /** The enemy a 魂灵之影 strikes: a targetable ground enemy of her range, 残影-less ones first, then the usual order. */
    const shadowTarget = (battle, host, t) => {
      const pool = battle.enemiesInKeys(host.rangeKeys, t, { canHitFly: false });
      if (!pool.length) return null;
      const fresh = pool.filter((e) => !e.findBuff('wisdel:shadow'));
      const list = fresh.length ? fresh : pool;
      sortEnemyTargets(battle, t, list, null);
      return list[0];
    };
    /** 魂灵之影's kit: 禁疗, no normal attack, its skill cast once it holds a target of her range. */
    const shadowKit = (host) => ({
      skill: {
        kind: 'instant',
        trigger: 'NEVER', // the tick below activates it, so it can only ever strike an enemy of her range
        onStart({ battle, unit: t, bb: sbb }) {
          const e = t.mem.wisdelTarget;
          t.mem.wisdelTarget = null;
          if (e && e.alive) {
            battle.fx('strike', { x: e.x, y: e.y, id: t.id, target: e.id });
            battle.dealDamage(t, e, { amount: t.s.atk * t.s.atkScaleMul, type: 'arts', isSkill: true, tags: ['skill', 'wisdel:shadow'] });
            if (hasHp(e)) {
              const sluggish = num(sbb.sluggish, 1);
              if (sluggish > 0) battle.applyStatus(e, 'sluggish', { duration: sluggish, source: t });
              if (on(host)) battle.addBuff(e, { key: 'wisdel:shadow', duration: Infinity, refresh: 'keep', visible: true, source: host, tags: ['talent'] });
            }
          }
          // token_wisdel_skill_end: "之后获得0-2点技力" (an integer of [sp_min, sp_max))
          const lo = Math.max(0, Math.floor(num(sbb.sp_min))), hi = Math.max(lo + 1, Math.floor(num(sbb.sp_max, lo + 2)));
          const add = lo + battle.rng.int(hi - lo);
          if (add > 0) t.skill.gainSp(add, 'init');
        },
      },
      trait: { noAttack: true },
      install(battle, t) {
        battle.addBuff(t, { key: 'trait:abnormal', flags: { noHeal: true }, persist: true, allowDead: true }); // 持有禁疗
        battle.on('tick', () => {
          const sk = t.skill;
          if (!on(t) || !sk || !sk.ready || sk.active || !t.canAct || t.s.flags.silence || !on(host)) return;
          const e = shadowTarget(battle, host, t);
          if (!e) return;
          t.mem.wisdelTarget = e;
          sk.activate('DEFAULT');
        }, { owner: t });
      },
    });
    /** The 迷彩 a 魂灵之影 gives her the moment it arrives (the poll below keeps it up while she stays near one). */
    const grantCamo = (battle, host, t) => {
      if (!on(host) || hypot(host.x - t.x, host.y - t.y) > WISDEL_CAMO_RANGE) return;
      battle.addBuff(host, { key: 'wisdel:camou', duration: 0.4, refresh: 'extend', flags: { camou: true }, visible: true, tags: ['talent'] });
    };
    /** Summon up to `n` 魂灵之影 (never beyond the cap); the first of a batch starts with `firstSp` SP. */
    const summon = (battle, host, n, firstSp = 0) => {
      for (let i = 0; i < n; i++) {
        if (shadowsOf(battle, host).length >= WISDEL_SHADOW_CAP) return;
        const tile = shadowTile(battle, host);
        if (!tile) return;
        const t = battle.spawnToken(host, WISDEL_TOKEN, tile[0], tile[1], { kit: shadowKit(host) });
        if (!t) return;
        if (i === 0 && firstSp > 0 && t.skill) t.skill.gainSp(firstSp, 'init');
        battle.fx('summon', { x: t.x, y: t.y, id: host.id, token: WISDEL_TOKEN });
        grantCamo(battle, host, t);
      }
    };
    return {
      skill: {
        kind: 'ammo',
        ammo: Math.max(1, Math.floor(num(bb['attack@trigger_time'], 6))),
        mods: mods({ atkPct: num(bb.atk), batPct: batPct(bb.base_attack_time, chess) }),
        attack: { atkScale: skillScale, splashRadius: WISDEL_S3_SPLASH },
        onStart(ctx) {
          ctx.unit.mem.wisdelBoost = true;
          // 爆裂黎明 "召唤 max_cnt 个魂灵之影" (PRTS: 初始技力分别为 3sp（优先召唤）与 0sp)
          summon(ctx.battle, ctx.unit, Math.max(1, Math.floor(num(ctx.bb?.max_cnt, 1))), num(ctx.bb?.sp));
        },
        onEnd(ctx) { ctx.unit.mem.wisdelBoost = false; },
      },
      talents: [
        { install(battle, unit) { // 好礼
          battle.on('beforeAttack', (c) => {
            if (c.attacker !== unit) return;
            unit.mem.wisdelMain = (c.targets || []).find((t) => t && t.alive) ?? null;
          }, { owner: unit, priority: 50 });
          battle.on('hit', (c) => {
            if (c.source !== unit || !c.target || c.target.side !== 'enemy') return;
            if (c.dmg.isAttack && c.target === unit.mem.wisdelMain) { // 主目标 ×1.15 + 附着残影
              c.dmg.amount *= mainScale;
              battle.addBuff(c.target, { key: 'wisdel:shadow', duration: Infinity, refresh: 'keep', visible: true, tags: ['talent'] });
              return;
            }
            if (!c.dmg.tags || c.dmg.tags.indexOf('aftershock') < 0) return; // 残影受到余震影响时
            if (!c.target.findBuff('wisdel:shadow')) return;
            const p = unit.mem.wisdelBoost ? skillProb : boomProb;
            if (!(p > 0) || !battle.rng.chance(p)) return;
            battle.removeBuff(c.target, 'wisdel:shadow');
            for (const e of battle.foesInRadius(c.target.x, c.target.y, boomRadius, true)) {
              if (!e.alive) continue;
              battle.dealDamage(unit, e, { amount: unit.s.atk * boomScale, type: 'phys', isSplash: true, tags: ['talent', 'wisdel'] });
              battle.applyStatus(e, 'stun', { duration: boomStun, source: unit });
            }
            battle.fx('aoe', { x: c.target.x, y: c.target.y, id: unit.id, r: boomRadius, skill: 'wisdel' });
          }, { owner: unit, priority: 20 });
          battle.on('death', (c) => { // 残影 "维什戴尔退场后消失" (PRTS 备注 of 好礼)
            if (c.unit !== unit) return;
            for (const e of battle.enemies) if (e.buffs.length) battle.removeBuff(e, 'wisdel:shadow');
          }, { owner: unit });
        } },
        { install(battle, unit) { // 死魂灵的余息
          battle.on('deploy', (ctx) => { if (ctx.unit === unit) summon(battle, unit, 1); }, { owner: unit }); // "部署后立刻在攻击范围内召唤一个魂灵之影"
          whileOn(battle, unit, 0.25, () => {
            const near = shadowsOf(battle, unit).some((t) => hypot(unit.x - t.x, unit.y - t.y) <= WISDEL_CAMO_RANGE);
            if (near) battle.addBuff(unit, { key: 'wisdel:camou', duration: 0.4, refresh: 'extend', flags: { camou: true }, visible: true, tags: ['talent'] });
            else battle.removeBuff(unit, 'wisdel:camou');
          });
        } },
      ],
    };
  },

  // 阿斯卡纶 — T5 伏击客 (stalker). Trait 对攻击范围内所有敌人造成伤害 / 拥有50%的物理和法术闪避且不容易成为攻击目标:
  // the profession layer reads the trait blackboard (`allInRange` + `installStalker` from `prob`) — nothing to author.
  //   天赋1 死亡拘审 (PRTS 精英2: 移动速度降低18％, 每秒受到10％当前攻击力的法术伤害, 持续25秒, 最多叠加三层):
  //     every attack slows the target (`slow`) and puts a stacking DoT on it — every `interval` s it takes
  //     `atk_ratio` × 阿斯卡纶's CURRENT ATK arts damage (the tick reads `unit.s.atk`), up to `max_stack_cnt` stacks,
  //     lasting `debuff_duration` s. PRTS 备注: "攻击已有本天赋效果的单位时叠加一层效果并重置持续时间；本天赋效果叠加
  //     时令已有的减速效果数值增加一倍" ⇒ the slow carries the stack count (18 % → 36 % → 54 %), and "自身退场后，所有已
  //     施加的本天赋效果将立刻结束" ⇒ a `death` hook clears the marks.
  //   天赋2 噬光残影: ASPD +`attack_speed`, and +`attack_speed_add` more while at least `cnt` of the 4 orthogonal
  //     neighbours is a 高台 (high-ground) tile — a 0.5 s poll (grid.isLow is false).
  //   恩赐 (S2): ATK +`atk` (the generic spec), "使攻击范围内所有敌人移动速度-`move_speed`" — a 0.25 s aura over every
  //     enemy of her current range, **地面与空中都算** (owner confirmed 2026-10-08; PRTS 修正 备注 says the 描述's 地面敌人
  //     does not match the game) under a key of her own, so it does not fight 天赋1's own slow (同名效果取最高) — and
  //     "在地面敌人被击倒时对周围地面敌人施加一层第一天赋效果": a ground enemy of her range knocked out while the skill
  //     runs gives one 死亡拘审 layer to every ground enemy within `range_radius` (PRTS 备注 "尸爆半径1.3", 中点判定).
  //   降临 (S3, 45 s in the data): ATK +`atk`, BAT `base_attack_time` (−1.5 s on the elite blackboard), taunt
  //     +`taunt_level` (PRTS 备注: "技能期间自身嘲讽等级+2（从-1提升至1）") and the skill's own (expanded) range. "使攻击
  //     范围内的地面敌人物理与法术命中率-X%": a ground enemy inside the range carries `ascln:blind`
  //     (data.miss = |damage_hitrate_physical|) while the skill runs, and its **physical / arts** damage is cancelled
  //     with that chance — the engine has no 命中率 attribute, so this is the practical equivalent of the miss roll
  //     [ASSUMED]; true / elemental damage keeps landing. "敌人未命中自身或自身闪避时回复最大生命值": both that miss
  //     (when it targets her) and the engine's own `dodge` event heal `hp_ratio` × max HP.
  chess_char_9_09_a: (bb, chess, def) => {
    const t0 = talentBb(chess, 0), t1 = talentBb(chess, 1);
    const s2 = skillRec(chess, 'skchr_ascln_2')?.bb ?? {}; // 恩赐 (S2)
    const slowBy = Math.min(0.9, Math.abs(num(t0.move_speed)));
    const dotRatio = num(t0.atk_ratio), dotDur = num(t0.debuff_duration, 25);
    const dotMax = Math.max(1, Math.floor(num(t0.max_stack_cnt, 3)));
    const dotIv = Math.max(0.2, num(t0.interval, 1));
    const aspdBase = num(t1.attack_speed), aspdHigh = num(t1.attack_speed_add);
    const highNeed = Math.max(1, Math.floor(num(t1.cnt, 1)));
    const missChance = Math.min(1, Math.max(0, -num(bb['attack@damage_hitrate_physical'])));
    const hpRatio = num(bb['attack@hp_ratio']);
    const mend = (battle, unit) => { if (hpRatio > 0 && on(unit)) battle.heal(unit, unit, unit.s.maxHp * hpRatio, { tags: ['skill', 'ascln'] }); };
    /**
     * One layer of 死亡拘审 on `target`: the stacking 减速 (+18 % a layer) and its 法术持续伤害 tick. Both the attacks of
     * 天赋1 and S2 恩赐's 尸爆 use it.
     */
    const judge = (battle, unit, target) => {
      if (!target || !target.alive || target.side !== 'enemy') return;
      // 叠加时 "令已有的减速效果数值增加一倍" — the slow grows with the stack count instead of multiplying as two
      // independent `slow` statuses would (0.82² = −32.8 % instead of the official −36 %).
      const had = target.findBuff('ascln:judge');
      const stacks = Math.min(dotMax, (had ? Math.max(1, Math.floor(had.stacks || 1)) : 0) + 1);
      if (slowBy > 0) battle.applyStatus(target, 'slow', { value: Math.min(0.9, slowBy * stacks), duration: dotDur, source: unit });
      if (!(dotRatio > 0)) return;
      battle.addBuff(target, {
        key: 'ascln:judge', duration: dotDur, refresh: 'stack', stacks: 1, maxStacks: dotMax, visible: true, tags: ['talent'],
        interval: dotIv,
        onTick({ battle: b, unit: e, buff }) {
          if (!on(unit) || !e.alive) return;
          b.dealDamage(unit, e, { amount: dotRatio * unit.s.atk * Math.max(1, buff.stacks), type: 'arts', tags: ['talent', 'ascln'] });
        },
      });
    };
    return {
      skill: {
        kind: 'duration',
        mods: mods({ atkPct: num(bb.atk), batPct: batPct(bb.base_attack_time, chess), taunt: num(bb.taunt_level) }),
        targeting: { rangeGrid: def?.skill?.rangeGrid ?? null },
        onEnd({ battle }) {
          for (const e of battle.enemies) if (e.buffs.length) battle.removeBuff(e, 'ascln:blind');
        },
      },
      talents: [
        { install(battle, unit) { // 死亡拘审
          battle.on('hit', (c) => {
            if (c.source !== unit || !c.dmg.isAttack) return;
            judge(battle, unit, c.target);
          }, { owner: unit, priority: 10 });
          battle.on('death', (c) => { // "自身退场后，所有已施加的本天赋效果将立刻结束"
            if (c.unit !== unit) return;
            for (const e of battle.enemies) {
              if (!e.buffs.length || !e.findBuff('ascln:judge')) continue;
              battle.removeBuff(e, 'ascln:judge');
              battle.removeBuff(e, 'slow'); // the 减速 belongs to the same talent (another source's slow ends too — approximation)
            }
          }, { owner: unit });
        } },
        { install(battle, unit) { // 噬光残影
          if (aspdBase > 0) battle.addBuff(unit, { key: 'ascln:shadow', mods: { aspd: aspdBase }, persist: true, allowDead: true });
          if (!(aspdHigh > 0)) return;
          whileOn(battle, unit, 0.5, () => {
            let high = 0;
            for (const [dr, dc] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
              const r = unit.tileR + dr, c = unit.tileC + dc;
              if (battle.grid.inRect(r, c) && !battle.grid.isLow(r, c)) high++;
            }
            if (high >= highNeed) battle.addBuff(unit, { key: 'ascln:shadowHigh', duration: 0.7, refresh: 'extend', mods: { aspd: aspdHigh }, visible: true, tags: ['talent'] });
            else battle.removeBuff(unit, 'ascln:shadowHigh');
          });
        } },
      ],
      install(battle, unit) {
        // 恩赐 (S2): "使攻击范围内所有敌人移动速度-30%" — PRTS 修正 (原因 "描述与游戏实际表现不符合"): every enemy of her
        // range, **地面与空中都算** (owner confirmed 2026-10-08; the data's own 描述 says 地面敌人, which is the text the
        // 修正 supersedes) — and "在地面敌人被击倒时对周围地面敌人施加一层第一天赋效果" (PRTS 备注 "尸爆半径1.3", a 中点
        // 判定 around the enemy, refreshed while the skill runs).
        if (unit.skill && unit.skill.id === 'skchr_ascln_2') {
          const ms = Math.min(0.9, Math.abs(num(s2.move_speed))), radius = num(s2.range_radius, 1.3);
          const aura = () => {
            if (ms <= 0 || !on(unit) || !unit.skill || !unit.skill.active) return;
            for (const e of battle.enemiesInKeys(unit.rangeKeys, unit, { canHitFly: true })) {
              // A key of her own, so 天赋1's own `slow` (同名效果取最高) and this one multiply, and two 阿斯卡纶 do not stack
              battle.applyStrongest(e, 'ascln:s2slow', { duration: 0.4, value: ms, mods: (v) => ({ moveMul: Math.max(0, 1 - v) }), source: unit });
            }
          };
          battle.on('skillStart', (c) => { if (c.unit === unit) aura(); }, { owner: unit });
          whileOn(battle, unit, 0.25, aura);
          battle.on('death', (c) => { // 尸爆: a ground enemy of her range knocked out while the skill runs
            const v = c.unit;
            if (c.reason !== 'killed' || !v || v.side !== 'enemy' || v.isFlying || !on(unit) || !unit.skill || !unit.skill.active) return;
            if (!unit.rangeKeySet || !bodyInKeys(v, unit.rangeKeySet)) return;
            battle.fx('aoe', { x: v.x, y: v.y, r: radius, id: unit.id, skill: 'ascln:endowment' });
            for (const e of battle.foesInRadius(v.x, v.y, radius, true)) {
              if (e === v || e.isFlying) continue; // 地面敌人 only, the dead one itself excluded
              judge(battle, unit, e);
            }
          }, { owner: unit });
        }
        // 降临: 命中率 + 闪避回复
        battle.on('hit', (c) => {
          if (!c.source || c.source.side !== 'enemy' || c.dmg.cancel) return;
          // "物理与法术命中率-X %": true / elemental damage takes no miss roll
          if (c.dmg.type !== 'phys' && c.dmg.type !== 'arts') return;
          if (typeof c.source.findBuff !== 'function') return;
          const blind = c.source.findBuff('ascln:blind');
          if (!blind) return;
          if (!battle.rng.chance(num(blind.data && blind.data.miss, 0))) return;
          c.dmg.cancel = true; // 敌人未命中: the attack happened (cooldown, 技力), nothing landed
          if (c.target === unit) mend(battle, unit);
        }, { owner: unit, priority: -50 });
        battle.on('dodge', (c) => { if (c.target === unit && unit.skill && unit.skill.active) mend(battle, unit); }, { owner: unit });
        if (missChance > 0) whileOn(battle, unit, 0.25, () => {
          if (!unit.skill || !unit.skill.active) return;
          for (const e of battle.enemiesInKeys(unit.rangeKeys, unit, unit.profile)) {
            if (e.isFlying) continue; // 地面敌人
            battle.addBuff(e, { key: 'ascln:blind', duration: 0.6, refresh: 'extend', visible: true, data: { miss: missChance }, tags: ['skill', 'ascln'] });
          }
        });
      },
    };
  },

  // 霜叶 — T1 领主 (lord). Trait 可以进行远程攻击，但此时攻击力降低至80%: the profession layer reads the trait
  // blackboard (`rangedScale` from `atk_scale`) — nothing to author.
  //   天赋 掩护打击 (the elite record only): 攻击范围扩大 — the talent carries its own grid, installed as the unit's
  //     permanent range (unit.rangeGrid + refreshRange, the module idiom) — and 攻击间隔略微增大 (`base_attack_time`
  //     +0.15 s).
  //   凝冰枪刃 (S2, 25 s in the data): ASPD +`attack_speed`; every attack lands a `slow` of |move_speed| and, with
  //     `prob` chance, a 束缚 for `debuff` s (PRTS 凝冰枪刃 gives 1.5 s for the 束缚 at Lv4 — the blackboard's `debuff`
  //     matches). PRTS names no duration for the slow itself, so it shares `debuff`; since every attack refreshes it and
  //     `debuff` ≥ her interval, the slow is continuous anyway [ASSUMED duration].
  chess_char_9_11_a: (bb, chess) => {
    const slowBy = Math.min(0.9, Math.abs(num(bb.move_speed)));
    const bindProb = num(bb.prob), bindFor = num(bb.debuff, 1.5);
    const cover = (chess?.talents || []).find((t) => t && t.index === 0) ?? null;
    return {
      skill: { kind: 'duration', mods: mods({ aspd: num(bb.attack_speed) }) },
      talents: [
        { install(battle, unit) { // 掩护打击 (elite only)
          if (!cover) return;
          const bat = num(cover.bb && cover.bb.base_attack_time);
          if (bat) battle.addBuff(unit, { key: 'frostl:cover', mods: { batPct: batPct(bat, chess) }, persist: true, allowDead: true });
          const g = cover.rangeGrid;
          if (Array.isArray(g) && g.length) {
            unit.rangeGrid = g.map((p) => [p[0], p[1]]);
            battle.refreshRange(unit);
          }
        } },
      ],
      install(battle, unit) { // 凝冰枪刃: 每次攻击减速 + 束缚
        battle.on('hit', (c) => {
          if (!unit.skill || !unit.skill.active) return;
          if (c.source !== unit || !c.dmg.isAttack) return;
          if (!c.target || c.target.side !== 'enemy') return;
          if (slowBy > 0) battle.applyStatus(c.target, 'slow', { value: slowBy, duration: bindFor, source: unit });
          if (bindProb > 0 && battle.rng.chance(bindProb)) battle.applyStatus(c.target, 'bind', { duration: bindFor, source: unit });
        }, { owner: unit, priority: 10 });
      },
    };
  },

  // 煌 — T4 强攻手 (centurion). Trait 同时攻击阻挡的所有敌人: the profession layer sets `hitAllBlocked` — nothing to author.
  //   天赋1 紧急除颤 (PRTS 备注 "每次部署后，煌常态持有不死效果；首次生命比例低于或等于25%时，触发天赋并解除不死效果" —
  //     the undying is a 'fatal' saver at PRIO_REVIVE that stops working once the flag is spent): the first time her HP
  //     ratio reaches hp_ratio (25 %) she heals `huang_t_1[heal].hp_ratio` (50 %) of her max HP and for
  //     `huang_t_1[lock].duration` (6 s) damage that would take her below `huang_t_1[lock].min_hp_ratio` (50 %) is
  //     reduced — PRTS: "该伤害减少(伤害值−当前生命值+最大生命值×50%)点", i.e. the HP is clamped back to that floor
  //     right after the loss. [ASSUMED: the clamp is done on the `damaged` hook, which runs after the HP loss.]
  //   天赋2 严酷训练: `interval` (15 s) after deployment she gains 抵抗 (`resist`, value `1 + one_minus_status_resistance`
  //     = 0.5).
  //   沸腾爆裂 (S3, 10 s): 攻击力和防御力逐渐增至 +atk/+def — the pair is re-granted every second at min(1, t/9)
  //     (PRTS 备注 "前8秒内每秒更新一次攻防属性…9s时攻防属性更新至最大属性值"); at the 9 s mark, "对前方一格内的敌方
  //     单位进行切割" = ONE physical hit of her ATK [ASSUMED: the 备注 gives no coefficient for this instance] to every
  //     GROUND enemy she reaches (her range is her own tile + the one in front). When the skill ends she loses
  //     `hp_ratio` (25 %) of her max HP — never below 1 HP (PRTS "最多令生命值降至1点") — and deals
  //     `damage_by_atk_scale` × 此时攻击力 physical to every enemy in the 3×3 area in front (碰撞判定, flyers included).
  chess_char_9_16_a: (bb, chess) => {
    const t0 = talentBb(chess, 0), t1 = talentBb(chess, 1);
    const thr = num(t0.hp_ratio, 0.25);
    const healRatio = num(t0['huang_t_1[heal].hp_ratio'], 0.5);
    const floor = num(t0['huang_t_1[lock].min_hp_ratio'], 0.5);
    const lockFor = num(t0['huang_t_1[lock].duration'], 6);
    const resistAfter = num(t1.interval, 15);
    const resist = Math.max(0, Math.min(0.95, 1 + num(t1.one_minus_status_resistance)));
    const atkUp = num(bb.atk), defUp = num(bb.def);
    const burstScale = num(bb.damage_by_atk_scale, 1);
    const hpCost = num(bb.hp_ratio, 0.25);
    // S2 (skchr_huang_2) is authored in `skills` as well: its own blackboard and its own range grid
    const huang2 = skillBbOf(chess, 'skchr_huang_2');
    const huang2Grid = skillRec(chess, 'skchr_huang_2')?.rangeGrid ?? null;
    /** Everything of hers she reaches at that moment (her range + the enemies it blocks). */
    const reached = (battle, unit) => {
      const out = battle.enemiesInKeys(unit.rangeKeys, unit, unit.profile);
      for (const e of unit.blocking) if (e.alive && !out.includes(e)) out.push(e);
      return out;
    };
    return {
      skill: {
        kind: 'duration',
        onStart(ctx) {
          ctx.unit.mem.huangT = 0;
          ctx.unit.mem.huangTick = 0;
          ctx.unit.mem.huangCut = false;
        },
        onTick({ battle, unit, dt }) {
          const dur = num(unit.skill?.duration, 10);
          unit.mem.huangT = num(unit.mem.huangT) + num(dt);
          const t = unit.mem.huangT;
          if (t - num(unit.mem.huangTick) >= 1) { // 每秒更新一次攻防属性
            unit.mem.huangTick = t;
            const prog = Math.min(1, t / HUANG_RAMP_SEC);
            battle.addBuff(unit, {
              key: 'huang:burst', refresh: 'replace', duration: Math.max(0.4, dur - t + 0.3), visible: true, tags: ['skill', 'huang'],
              mods: mods({ atkPct: atkUp * prog, defPct: defUp * prog }),
            });
          }
          if (!unit.mem.huangCut && t >= HUANG_RAMP_SEC) { // 切割: one hit on everything she reaches, ground only
            unit.mem.huangCut = true;
            for (const e of reached(battle, unit)) {
              if (!e.alive || e.isFlying) continue;
              battle.dealDamage(unit, e, { amount: unit.s.atk, type: 'phys', isSkill: true, tags: ['skill', 'huang'] });
            }
          }
        },
        onEnd({ battle, unit }) {
          if (!on(unit)) return;
          const atk = unit.s.atk; // 此时攻击力 (the ramp is still applied while onEnd runs)
          // PRTS 备注 orders it 流失生命 first: "9s时攻防属性更新至最大属性值，随后流失生命，对前方3×3区域内的所有敌人
          // 造成一次物理伤害（碰撞判定，可对空）"
          const loss = Math.min(unit.s.maxHp * hpCost, Math.max(0, unit.hp - 1)); // 不会导致自身死亡
          if (loss > 0) battle.loseHp(unit, loss, { source: unit });
          const [fr, fc] = frontOf(unit.tileR, unit.tileC, unit.dir);
          for (const e of battle.foesInRadius(fc, fr, HUANG_BURST_RADIUS, true)) {
            if (!e.alive) continue;
            battle.dealDamage(unit, e, { amount: atk * burstScale, type: 'phys', isSkill: true, tags: ['skill', 'huang'] });
          }
          battle.fx('aoe', { x: fc, y: fr, id: unit.id, r: HUANG_BURST_RADIUS, skill: 'huang' });
        },
      },
      skills: {
        // S2 (skchr_huang_2): 攻击力 +55 %/+70 %、防御力 +15 %/+20 %、攻击距离加长 — 持续时间无限。用户 2026-10-06：
        // 这类「持续无限 / 可切换」技能开启后不再关闭，所以是 toggle（开启即保持到被击倒）。值必须是 SkillSpec 对象
        // （见 逻各斯 S1 处的注释）。攻击距离用技能自己的 rangeGrid（3 格），从棋子记录的 skills[] 里取，避免写死。
        skchr_huang_2: {
          kind: 'toggle',
          mods: mods({ atkPct: num(huang2.atk), defPct: num(huang2.def) }),
          ...(huang2Grid ? { targeting: { rangeGrid: huang2Grid } } : {}),
        },
      },
      talents: [
        { install(battle, unit) { // 紧急除颤
          battle.on('fatal', (c) => { // 常态不死, spent with the rescue
            if (c.unit !== unit || c.prevented || unit.mem.huangRescue) return;
            c.prevented = true;
          }, { owner: unit, priority: PRIO_REVIVE });
          battle.on('damaged', (c) => {
            if (c.target !== unit || !unit.alive) return;
            if (!unit.mem.huangRescue) {
              if (!(thr > 0) || unit.hpRatio > thr) return;
              unit.mem.huangRescue = battle.time; // 仅一次 (mem is per deployment)
              battle.heal(unit, unit, unit.s.maxHp * healRatio, { self: true, ignoreHealFree: true, tags: ['talent', 'huang'] });
              battle.addBuff(unit, { key: 'huang:lock', duration: lockFor, visible: true, tags: ['talent', 'huang'] });
              return;
            }
            if (!unit.findBuff('huang:lock')) return;
            const min = unit.s.maxHp * floor; // 使生命值不低于50 %
            if (unit.hp < min) unit.hp = min;
          }, { owner: unit, priority: 30 });
        } },
        { install(battle, unit) { // 严酷训练
          if (!(resistAfter > 0) || !(resist > 0)) return;
          battle.after(resistAfter, () => {
            if (on(unit)) battle.applyStatus(unit, 'resist', { value: resist, duration: Infinity, source: unit });
          }, { owner: unit });
        } },
      ],
    };
  },

  // 坚雷 — T2 驭法铁卫 (artsprotector — a subProfession the engine's table does not carry, so its trait is authored
  // here). Trait 技能开启时普通攻击会造成法术伤害 and 起盾回击's "同时攻击阻挡的所有敌人" both ride on the skill's `attack`
  // override: effectiveProfile copies every key of it onto the profile while the skill runs (`dmgType: 'arts'`,
  // `hitAllBlocked: true`).
  //   天赋 攻守兼备: ATK +atk / DEF +def (4 % each on the normal blackboard) as a permanent buff.
  chess_char_9_13_a: (bb, chess) => {
    const t0 = talentBb(chess, 0);
    const atk = num(t0.atk), def = num(t0.def);
    return {
      // The record's derived `dmgType` is 'arts' (the trait text mentions 法术), but 驭法铁卫 attacks physically unless a
      // skill runs — the skill's `attack.dmgType` below switches the arts damage on and off with it.
      trait: { dmgType: 'phys' },
      skill: {
        kind: 'duration',
        mods: mods({ atkPct: num(bb.atk) }),
        attack: { dmgType: 'arts', hitAllBlocked: true },
      },
      talents: [
        { install(battle, unit) { // 攻守兼备
          if (!(atk > 0) && !(def > 0)) return;
          battle.addBuff(unit, { key: 'durnar:guard', mods: mods({ atkPct: atk, defPct: def }), persist: true, allowDead: true });
        } },
      ],
    };
  },

  // 阿米娅 — T3 核心术师 (corecaster). Trait 攻击造成法术伤害 is the corecaster default — nothing to author.
  //   天赋 情绪吸收: every attack of hers refunds `amiya_t_1[atk].sp` (2) 技力, every kill `amiya_t_1[kill].sp` (8).
  //   奇美拉 (S3, 30 s): ATK +atk (130 %), max HP +max_hp (50 %), the skill's own (expanded) range and — "伤害类型变为
  //     真实" — her attacks land as 真实伤害 (`attack.dmgType`, the same switch Mon3tr's 熔毁 uses). "技能结束后阿米娅
  //     强制退出战场": onEnd retreats her — PRTS 史尔特尔 余烬's reading of 强制退出战场 ("视为撤回干员"), so the mode
  //     leaves a 倒地干员 on her tile and redeploys her there.
  chess_char_9_14_a: (bb, chess, def) => {
    const t0 = talentBb(chess, 0);
    const spAtk = num(t0['amiya_t_1[atk].sp']), spKill = num(t0['amiya_t_1[kill].sp']);
    return {
      skill: {
        kind: 'duration',
        mods: mods({ atkPct: num(bb.atk), hpPct: num(bb.max_hp) }),
        targeting: { rangeGrid: def?.skill?.rangeGrid ?? null },
        attack: { dmgType: 'true' },
        onEnd({ battle, unit }) {
          if (on(unit)) battle.retreat(unit, { reason: 'retreat' });
        },
      },
      talents: [
        { install(battle, unit) { // 情绪吸收
          if (spAtk > 0) battle.on('attack', (c) => { if (c.attacker === unit) unit.skill.gainSp(spAtk, 'talent'); }, { owner: unit });
          if (spKill > 0) battle.on('kill', (c) => { if (c.killer === unit) unit.skill.gainSp(spKill, 'talent'); }, { owner: unit });
        } },
      ],
    };
  },

  // 闪灵 — T3 医师 (physician). Trait 恢复友方单位生命 is the medic default — nothing to author.
  //   天赋1 黑恶魔的庇护: allies inside her range (her own tile included) get +def DEF — a flat `defFlat`, refreshed by a
  //     0.25 s aura like every other talent aura.
  //   天赋2 法典: ASPD +attack_speed (10) as a permanent buff.
  //   教条力场 (S3, 60 s): ATK +atk, and "攻击范围内的所有友方单位防御力+def%" — the same aura with a separate buff key
  //     (`defPct`), so the extra DEF lapses with the skill while 黑恶魔的庇护 keeps running.
  chess_char_9_04_a: (bb, chess) => {
    const t0 = talentBb(chess, 0), t1 = talentBb(chess, 1);
    const auraDef = num(t0.def);
    const aspd = num(t1.attack_speed);
    const fieldDef = num(bb.def);
    const auraTick = (battle, unit, key, mods, visible) => whileOn(battle, unit, 0.25, () => {
      for (const a of battle.alliesInGrid(unit)) {
        battle.addBuff(a, { key, duration: 0.4, refresh: 'extend', mods, visible: !!visible, tags: ['talent'] });
      }
    });
    return {
      skill: { kind: 'duration', mods: mods({ atkPct: num(bb.atk) }) },
      talents: [
        { install(battle, unit) { // 黑恶魔的庇护
          if (auraDef > 0) auraTick(battle, unit, 'shining:protect', { defFlat: auraDef });
        } },
        { install(battle, unit) { // 法典
          if (aspd > 0) battle.addBuff(unit, { key: 'shining:codex', mods: { aspd }, persist: true, allowDead: true });
        } },
      ],
      install(battle, unit) { // 教条力场
        if (!(fieldDef > 0)) return;
        whileOn(battle, unit, 0.25, () => {
          if (!unit.skill || !unit.skill.active) return;
          for (const a of battle.alliesInGrid(unit)) {
            battle.addBuff(a, { key: 'shining:field', duration: 0.4, refresh: 'extend', mods: { defPct: fieldDef }, visible: true, tags: ['skill', 'shining'] });
          }
        });
      },
    };
  },

  // 陨星 — T2 群射手 (aoesniper). Trait 攻击造成群体物理伤害: the profession layer sets the 1.1 splash — nothing to author.
  //   天赋 爆破附着改装: "普通攻击和技能释放时，15%几率当次攻击的攻击力+60%" — rolled ONCE per attack in `beforeAttack`, so
  //     every damage instance of that attack (main + splash) carries it.
  //   高爆弹头 (S2, an instant skill — the data has durationType NONE): the attack it rides on (the engine's instant-skill
  //     pattern: fired when she is about to attack) hits at atk_scale × ATK, and every victim of it gets
  //     defFlat `def` (−170) for `duration` (10 s).
  chess_char_9_02_a: (bb, chess) => {
    const t0 = talentBb(chess, 0);
    const prob = num(t0.prob), boost = num(t0.atk);
    const shatter = Math.abs(num(bb.def));
    const shatterFor = num(bb.duration, 10);
    return {
      skill: {
        kind: 'instant',
        attack: {
          atkScale: num(bb.atk_scale, 1),
          onEachHit({ battle, unit, target }) {
            if (!(shatter > 0) || !target || target.side !== 'enemy' || !target.alive) return;
            battle.addBuff(target, { key: 'meteo:shatter', duration: shatterFor, refresh: 'replace', mods: { defFlat: -shatter }, visible: true, tags: ['skill', 'meteo'] });
          },
        },
      },
      talents: [
        { install(battle, unit) { // 爆破附着改装
          if (!(prob > 0) || !(boost > 0)) return;
          battle.on('beforeAttack', (c) => {
            if (c.attacker === unit) unit.mem.meteoBoost = battle.rng.chance(prob);
          }, { owner: unit, priority: 50 });
          battle.on('hit', (c) => {
            if (c.source !== unit || !c.dmg.isAttack || !unit.mem.meteoBoost) return;
            c.dmg.amount *= 1 + boost;
          }, { owner: unit, priority: 30 });
        } },
      ],
    };
  },

  // 赫德雷 — T4 重剑手 (crusher). Trait 同时攻击阻挡的所有敌人: the profession layer sets `hitAllBlocked` — nothing to author.
  //   天赋1 及锋而试: "攻击敌人时攻击力提升至110%，若目标处于晕眩、束缚则改为提升至140%" — PRTS 备注 "本天赋于每次攻击的附加
  //     效果后、计算伤害前判断并生效": the branch is read per damage instance in a late `hit` hook, so a target the skill's own
  //     晕眩 (applied in `beforeAttack` below) already holds takes the 140 % branch.
  //   天赋2 余火之氅: herself and the ally on the tile BEHIND her get 18 % 庇护 (`damage_resistance` ⇒ dmgTakenMul 0.82),
  //     refreshed by a 0.25 s aura. [ASSUMED: "身后一格" = the tile opposite her facing, computed as the mirror of `frontOf`.]
  //   死境硝烟 (S3, 70 s): 攻击距离+1 (`rangeExtend`), 生命上限+30 %, 攻击力+60 %; she loses `attack@value` (100) HP per
  //     second (a 流失, it can knock her out); every enemy she attacked and every enemy that attacked her takes
  //     `attack@damage` (200) true damage per second — PRTS 备注 "伤害分类为无来源真实持续伤害…持续至技能结束，不可叠加",
  //     so each tick is a sourceless periodic instance (`periodicDamage`) and the marks go with the skill. Every attack
  //     heals her `attack@hp_ratio` (5 %) of her max HP and has `attack@buff_prob` (25 %) chance to stun its targets for
  //     `attack@stun` s — both applied in `beforeAttack`, before the damage.
  chess_char_9_06_a: (bb, chess) => {
    const t0 = talentBb(chess, 0), t1 = talentBb(chess, 1);
    const stunScale = num(t0.atk_scale, 1.4), plainScale = num(t0.atk_scale_2, 1.1);
    const dr = num(t1.damage_resistance);
    const drain = num(bb['attack@value']), tickDmg = num(bb['attack@damage']);
    const healRatio = num(bb['attack@hp_ratio']), stunProb = num(bb['attack@buff_prob']), stunFor = num(bb['attack@stun']);
    // S2 (skchr_hodrer_2) is authored in `skills` as well: its own blackboard, plus the chess's real 攻击间隔
    const s2 = skillBbOf(chess, 'skchr_hodrer_2');
    const stun2 = num(s2['attack@stun']);
    const bat = num(chess.stats?.bat, 1);
    return {
      skill: {
        kind: 'duration',
        mods: mods({ atkPct: num(bb.atk), hpPct: num(bb.max_hp) }),
        targeting: mods({ rangeExtend: Math.round(num(bb.ability_range_forward_extend)) }),
        onTick({ battle, unit, dt }) {
          if (drain > 0) { // 每秒流失100点生命 — a silent 流失: one `dmg` event per point would draw 100 white numbers,
            // glow particles and hit flashes a second over her (the 重构体's drain, same idiom, owner report 2026-10-08)
            unit.mem.hodrerDrain = num(unit.mem.hodrerDrain) + drain * num(dt);
            while (unit.mem.hodrerDrain >= 1 && unit.alive) { unit.mem.hodrerDrain -= 1; battle.loseHp(unit, 1, { source: unit, silent: true }); }
          }
          if (!(tickDmg > 0)) return;
          unit.mem.hodrerTick = num(unit.mem.hodrerTick) + num(dt);
          if (unit.mem.hodrerTick < 1) return;
          unit.mem.hodrerTick = 0;
          for (const e of battle.enemies) {
            if (!e.alive || e.s.flags.invulnerable || !e.findBuff('hodrer:smoke')) continue;
            battle.dealDamage(unit, e, periodicDamage(tickDmg)); // 无来源真实持续伤害
          }
        },
        onEnd({ battle }) {
          for (const e of battle.enemies) if (e.buffs.length) battle.removeBuff(e, 'hodrer:smoke');
        },
      },
      skills: {
        // S2 死境硝烟以外的那一个 (skchr_hodrer_2): 官方文案「被动效果：攻击力+16%／主动触发可以在下列状态和初始状态间切换：
        // 攻击间隔略微增大，阻挡数+1，攻击使目标晕眩1秒」。用户 2026-10-06 要求这类「可切换」技能开启后**不再关闭**，所以
        // 它是 toggle —— 开启即保持到被击倒，不再回到初始状态。被动的那份攻击力并入技能的 mods（[ASSUMED] 这个 kit 没有
        // 独立的被动槽）；数值必须取 S2 自己的黑板（bb 是「当前选中的技能」的黑板，选 S3 时它是 S3 的）。值必须是
        // SkillSpec 对象：写成工厂函数会让 SkillRuntime 拿到一个函数，kind 回落到记录里的 instant —— 技力一满就再切一次。
        skchr_hodrer_2: {
          kind: 'toggle',
          mods: mods({
            atkPct: num(s2.atk),
            blockCnt: num(s2.block_cnt),
            // "攻击间隔略微增大" = base_attack_time 的绝对值加算，换算成相对倍率
            batPct: bat > 0 ? num(s2.base_attack_time) / bat : 0,
          }),
          attack: {
            onEachHit({ battle, unit, target }) {
              if (!(stun2 > 0) || !target || !target.alive || target.side !== 'enemy') return;
              battle.applyStatus(target, 'stun', { duration: stun2, source: unit });
            },
          },
        },
      },
      talents: [
        { install(battle, unit) { // 及锋而试
          battle.on('hit', (c) => {
            if (c.source !== unit || !c.dmg.isAttack) return;
            const f = c.target && c.target.s ? c.target.s.flags : null;
            c.dmg.amount *= f && (f.stun || f.bind) ? stunScale : plainScale; // 附加效果后、计算伤害前
          }, { owner: unit, priority: -10 });
        } },
        { install(battle, unit) { // 余火之氅
          if (!(dr > 0)) return;
          const cloak = { key: 'hodrer:cloak', duration: 0.4, refresh: 'extend', mods: { dmgTakenMul: 1 - dr }, visible: true, tags: ['talent'] };
          whileOn(battle, unit, 0.25, () => {
            battle.addBuff(unit, { ...cloak });
            const [fr, fc] = frontOf(unit.tileR, unit.tileC, unit.dir);
            const behind = battle.allyUnits.find((a) => a !== unit && a.alive && a.deployed && a.tileR === unit.tileR * 2 - fr && a.tileC === unit.tileC * 2 - fc);
            if (behind) battle.addBuff(behind, { ...cloak });
          });
        } },
      ],
      install(battle, unit) { // 死境硝烟: the marks + the per-attack heal / stun
        const mark = (e) => { if (e && e.alive && e.buffs) battle.addBuff(e, { key: 'hodrer:smoke', duration: Infinity, refresh: 'keep', visible: true, tags: ['skill', 'hodrer'] }); };
        battle.on('beforeAttack', (c) => { // the attack's own effects, before the damage (PRTS: 附加效果后、计算伤害前)
          if (!unit.skill || !unit.skill.active || c.attacker !== unit) return;
          if (healRatio > 0) battle.heal(unit, unit, unit.s.maxHp * healRatio, { tags: ['skill', 'hodrer'] });
          for (const t of c.targets || []) {
            if (!t || !t.alive || t.side !== 'enemy') continue;
            if (stunProb > 0 && battle.rng.chance(stunProb)) battle.applyStatus(t, 'stun', { duration: stunFor, source: unit });
          }
        }, { owner: unit, priority: 60 });
        battle.on('hit', (c) => { // 自身攻击过的敌人
          if (!unit.skill || !unit.skill.active || c.source !== unit || !c.dmg.isAttack) return;
          if (c.target && c.target.side === 'enemy') mark(c.target);
        }, { owner: unit, priority: 40 });
        battle.on('damaged', (c) => { // 攻击过自身的敌人
          if (!unit.skill || !unit.skill.active || c.target !== unit) return;
          if (c.source && c.source.side === 'enemy') mark(c.source);
        }, { owner: unit, priority: 40 });
      },
    };
  },
};

const out = {};
for (const [id, fn] of Object.entries(ALIASES)) if (fn) out[id] = fn;

/** Aliased kit count (a smoke signal for the content tests / logs). */
export const ALIAS_COUNT = Object.keys(out).length;

export default { ...out, ...PACK_KITS };
