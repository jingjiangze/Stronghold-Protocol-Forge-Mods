// server/sim/content/bonds/custom.js — the fan-made core bonds 卡兹戴尔 (kazdelShip) and 罗德岛 (rhodesShip),
// plus the conditional parts of their four bond items (the pack's records.json, docs/CUSTOM.md).
//
// Loaded by content/bonds.js next to bonds/core.js and bonds/addon.js. The numbers come from the pack's
// `env_gbuff_new` blackboard (`buffParams(bondRecord(id), 'env_gbuff_new')`), never from literals — except the
// item conditionals, whose extra values live on the item's own `char_dynamic_ability_new` buff
// (`act2autochess_equip_custom_*`), read through the same `buffsOf` / `buffParams` helpers the item system uses.
//
// The two records' `bbStr.key` (`act2autochess_bond_eff_kazdel` / `act2autochess_bond_eff_rhodes`) is a DATA LABEL
// only: unlike the official core bonds, this module dispatches on the bond **id** (KAZDEL / RHODES below), so that
// key string is never read anywhere in the code base (and does not need to be).
//
//   卡兹戴尔 kazdelShip  members deal +(base_damage_scale + damage_scale_per_stack×L) damage to enemies under
//                        眩晕 / 停顿 / 束缚 / 不动 (a `hit` multiplier — the 谢拉格 pattern); at 6 distinct members
//                        every member +bonus_attack_speed ASPD and its attacks carry true_damage_scale×ATK as 真实伤害
//                        (the 卡西米尔 6 pattern); prep: every `layer` layers grant one 萨卡兹的断角
//   罗德岛 rhodesShip    members ATK +(base_atk + atk_per_stack×L), max HP +(base_max_hp + max_hp_per_stack×L)
//                        (directMods, live layers); at 6 distinct members every member: heals received ×(1+heal_scale),
//                        +sp_per_interval SP every sp_interval s, and 生命回复速度 regen_hp_scale×max HP per second
//                        (an hpRegenRatio buff, checklist 11: no 治疗加成, 禁疗-proof) plus regen_element_scale×1000
//                        元素损伤 per second
//
// Item conditionals (all bond-gated, so they live with the bonds rather than in items/battle.js):
//   提卡兹之根  a kazdelShip carrier additionally gets atk_scale / attack_speed_scale (bond members only)
//   断角 combo  a kazdelShip carrier holding both 提卡兹之根 and 萨卡兹的断角: enemies in its range that are under
//               眩晕 / 停顿 / 束缚 take 20% of its ATK as 真实伤害 every second
//   抑制环      carrier element gauge intake ×(1 − elem_taken) (elemTakenMul)
//   源石弧      carrier damage taken ×(1 − damage_taken); a rhodesShip carrier additionally gains
//               field_sum_share × (Σ ATK, Σ max HP of every on-field operator); holding 罗德岛抑制环 too grants the
//               arc's own atk / max_hp part to every on-field operator while it lives

import {
  num, bondRecord, buffParams, buffsOf, bondActive, bondTier, bondLayers, isMember, onField, playerOps,
  itemsOf, itemKeyOf, hasItemKey, passiveBuff, directMods, fxOn, itemRecord, battleStore,
} from '../support/index.js';
import { ELEMENT_GAUGE_MAX } from '../../constants.js';

const KAZDEL = 'kazdelShip';
const RHODES = 'rhodesShip';
const EYE_KEY = 'chess_item_c_02_e';
const HORN_KEY = 'chess_item_c_01_e';
const RING_KEY = 'chess_item_c_03_e';
const ARC_KEY = 'chess_item_c_04_e';
const CLAW_KEY = 'chess_item_c_05_e';   // M3利爪 (custom)
const CARAPACE_KEY = 'chess_item_4_12_e'; // M3茧甲 / M3护甲 (official)
const COMBO_DPS_SCALE = 0.2; // 断角 combo: 20% of ATK per second (the design's number)
const POLL = 0.25;           // arc field-sum recompute interval (s)

/** Bond effect blackboard `{ ...bb, ...bbStr }` (numbers only) or {}. */
const bbOf = (id) => buffParams(bondRecord(id), 'env_gbuff_new') ?? {};

/** `{ ...bb, ...bbStr }` of an item's buff whose bbStr.key is `key`. */
function itemParams(itemId, key) {
  const rec = itemRecord(itemId);
  if (!rec) return null;
  for (const b of buffsOf(rec)) if (b.bbKey === key) return b.p;
  return null;
}

/** The equipped id of an item family on `u` (any quality), or null. */
const itemIdOf = (u, key) => itemsOf(u).find((x) => itemKeyOf(x) === key) ?? null;

/** Enemy under 眩晕 / 停顿 / 束缚 / 不动 (any one of them counts).
 *
 * 不动 is a MOVEMENT state, not a buff: it is the same test 荒芜拉普兰德 (chess_char_6_18) uses for her
 * attack targeting (kits/tier6.js `still` — 被阻挡 / 没在移动 / 移速为 0 / flags.noMove). 眩晕 / 停顿 / 束缚
 * stay status checks (stun / sluggish / bind). */
function controlled(t) {
  if (!t || !t.findBuff) return false;
  const f = (t.s && t.s.flags) || {};
  if (f.stun || f.bind || f.immobile || f.rooted) return true;
  if (t.blockedBy || t.moving === false || !(t.s?.moveSpeed > 0) || f.noMove) return true;
  return !!(t.findBuff('stun') || t.findBuff('sluggish') || t.findBuff('bind') || t.findBuff('immobile'));
}

const isEnemy = (t) => !!t && t.side === 'enemy' && t.alive;
const tagged = (dmg, tag) => !!(dmg && Array.isArray(dmg.tags) && dmg.tags.includes(tag));

// =====================================================================================================================

export function install(battle) {
  if (!battle || !Array.isArray(battle.players)) return;
  // Idempotent: the module is reached through content/bonds.js AND may be passed as extraContent (tests) — a second
  // install would double every `battle.every` / `battle.on` handler it registers.
  const guard = battleStore(battle, 'bonds:custom', () => ({ installed: false }));
  if (guard.installed) return;
  guard.installed = true;

  for (const p of battle.players) {
    const pid = p.playerId;
    const kazdel = bondActive(battle, pid, KAZDEL);
    const rhodes = bondActive(battle, pid, RHODES);
    // The item legs below (提卡兹之根 / 抑制环 / 源石弧 / M3利爪) are item-driven, so the loop runs even when
    // neither bond is active; each leg checks its own bond condition internally.
    const ops = playerOps(battle, pid);

    // ---- 卡兹戴尔 ----------------------------------------------------------------------------------------------
    if (kazdel) {
      const bb = bbOf(KAZDEL);
      const members = ops.filter((u) => isMember(battle, u, KAZDEL));
      const L = () => bondLayers(battle, pid, KAZDEL);
      const six = bondTier(battle, pid, KAZDEL) >= 2 || reachedCount(battle, pid, KAZDEL, bb.power_bond_char_cnt);

      // tier 1: damage bonus vs controlled enemies (conditional → a `hit` multiplier, the 谢拉格 pattern).
      // 2026-10-11: the bonus multiplies the ATTACK (pre-mitigation amount), not the post-DEF result, so the owner's
      // formula holds: 伤害 = 攻击力 × (1 + 20 % + 0.9 %×L) − 防御 (100 ATK, 0 L, 100 DEF → 100×1.2 − 100 = 20).
      // The tier-2 proc below is deliberately NOT skipped by the tag guard any more: its own true damage has to take
      // the same bonus when its target is controlled (owner 2026-10-11).
      if (members.length) {
        const memberSet = new Set(members);
        battle.on('hit', (c) => {
          const s = c.source, t = c.target, dmg = c.dmg;
          if (!s || !memberSet.has(s) || !dmg || dmg.sourceless) return;
          if (!isEnemy(t) || !controlled(t)) return;
          const bonus = num(bb.base_damage_scale) + num(bb.damage_scale_per_stack) * L();
          if (bonus > 0) dmg.amount *= 1 + bonus;
        });
      }

      // tier 2 (6 distinct): +ASPD and attacks carry 20% ATK true damage. That proc is ANOTHER damage instance of the
      // same member: its own `hit` runs through the tier-1 handler above, so a controlled target takes 20 % × ATK ×
      // (1 + 20 % + 0.9 %×L) true damage (the `damaged` guard below only stops it from re-proccing itself).
      if (six && members.length) {
        const aspd = num(bb.bonus_attack_speed);
        const scale = num(bb.true_damage_scale);
        const memberSet = new Set(members);
        for (const u of members) if (aspd > 0) passiveBuff(battle, u, `bond:${KAZDEL}:aspd`, { aspd });
        if (scale > 0) {
          battle.on('damaged', (c) => {
            const s = c.source, t = c.target, dmg = c.dmg;
            if (!s || !memberSet.has(s) || !dmg || !dmg.isAttack || !isEnemy(t)) return;
            if (tagged(dmg, `bond:${KAZDEL}`)) return;
            battle.dealDamage(s, t, { amount: scale * s.s.atk, type: 'true', canDodge: false, tags: [`bond:${KAZDEL}`] });
          });
        }
      }
    }

    // ---- 罗德岛 ------------------------------------------------------------------------------------------------
    if (rhodes) {
      const bb = bbOf(RHODES);
      const members = ops.filter((u) => isMember(battle, u, RHODES));
      const live = () => {
        const L = bondLayers(battle, pid, RHODES);
        const mods = directMods({
          atk: num(bb.base_atk) + num(bb.atk_per_stack) * L,
          hp: num(bb.base_max_hp) + num(bb.max_hp_per_stack) * L,
        });
        for (const u of members) passiveBuff(battle, u, `bond:${RHODES}`, mods);
      };
      if (members.length) {
        live();
        battle.on('layerGain', (c) => {
          if (c && c.playerId === pid && c.bondId === RHODES) battle.after(0, live);
        });
      }
      const six = bondTier(battle, pid, RHODES) >= 2 || reachedCount(battle, pid, RHODES, bb.power_bond_char_cnt);
      if (six && members.length) {
        const healMul = 1 + num(bb.heal_scale);
        for (const u of members) if (healMul !== 1) passiveBuff(battle, u, `bond:${RHODES}:heal`, { healingTakenMul: healMul });
        const spIv = num(bb.sp_interval, 2), spN = num(bb.sp_per_interval, 1);
        if (spIv > 0 && spN > 0) {
          battle.every(spIv, () => {
            for (const u of members) if (onField(u) && u.skill) u.skill.gainSp(spN, 'bond');
          });
        }
        const hpPct = num(bb.regen_hp_scale), elPct = num(bb.regen_element_scale);
        // regen_hp_scale is 生命回复速度, not 治疗 (PRTS: "增减生命回复速度…不会被识别为治疗类能力"): an hpRegenRatio
        // buff the engine ticks itself (checklist 11) — 治疗加成 never scales it and 禁疗 does not stop it.
        for (const u of members) if (hpPct > 0) passiveBuff(battle, u, `bond:${RHODES}:regen`, { hpRegenRatio: hpPct });
        if (elPct > 0) {
          battle.every(1, () => {
            for (const u of members) if (onField(u)) battle.reduceElement(u, elPct * ELEMENT_GAUGE_MAX);
          });
        }
      }
    }

    // ---- bond items (提卡兹之根 / 抑制环 / 源石弧) ----------------------------------------------------------------
    installBondItems(battle, pid, ops);
  }
}

/** Has `pid` reached `cnt` distinct members (count, else the tier index) — mirrors bonds/core.js `reached`. */
function reachedCount(battle, pid, bondId, cnt) {
  const st = battle.getPlayer(pid)?.bonds?.[bondId];
  if (!st || !st.active) return false;
  const need = num(cnt, 0);
  if (!(need > 0)) return true;
  if (num(st.count, 0) >= need) return true;
  const th = bondRecord(bondId)?.thresholds;
  const idx = Array.isArray(th) ? th.indexOf(need) : -1;
  return idx >= 0 && num(st.tier, 0) >= idx + 1;
}

// =====================================================================================================================

function installBondItems(battle, pid, ops) {
  const has = (u, key) => hasItemKey(u, key);

  // 提卡兹之根: the 卡兹戴尔 conditional bonus
  for (const u of ops) {
    if (!has(u, EYE_KEY) || !isMember(battle, u, KAZDEL)) continue;
    const p = itemParams(itemIdOf(u, EYE_KEY), 'act2autochess_equip_custom_kazdel_eye');
    if (!p) continue;
    const mods = directMods({ atk: num(p.atk_scale) });
    const aspd = num(p.attack_speed_scale);
    if (aspd) mods.aspd = aspd;
    passiveBuff(battle, u, `bond:${KAZDEL}:eye`, mods);
  }

  // 断角 combo: 提卡兹之根 + 萨卡兹的断角 on a 卡兹戴尔 member → 20% ATK/s true damage to controlled enemies in range.
  // The tier-1 `hit` handler boosts every damage instance of a member against a controlled enemy, so this combo also
  // pays 0.2 × ATK × (1 + 20 % + 0.9 %×L) (owner 2026-10-11).
  for (const u of ops) {
    if (!has(u, EYE_KEY) || !has(u, HORN_KEY) || !isMember(battle, u, KAZDEL)) continue;
    battle.every(1, () => {
      if (!onField(u) || !u.canAct) return;
      const keys = Array.isArray(u.rangeKeys) ? u.rangeKeys : [];
      if (!keys.length) return;
      let hit = 0;
      for (const e of battle.enemiesInKeys(keys, u, u.profile)) {
        if (!isEnemy(e) || !controlled(e)) continue;
        battle.dealDamage(u, e, { amount: COMBO_DPS_SCALE * u.s.atk, type: 'true', canDodge: false, tags: [`bond:${KAZDEL}:combo`] });
        hit++;
      }
      if (hit) fxOn(battle, 'bondProc', u, `bond:${KAZDEL}:combo`, 'dot', { n: hit });
    });
  }

  // 罗德岛抑制环: 元素损伤 reduction
  for (const u of ops) {
    if (!has(u, RING_KEY)) continue;
    const p = itemParams(itemIdOf(u, RING_KEY), 'act2autochess_equip_custom_rhodes_ring');
    const cut = num(p?.elem_taken);
    if (cut > 0) passiveBuff(battle, u, `bond:${RHODES}:ring`, { elemTakenMul: Math.max(0.05, 1 - cut) });
  }

  // 罗德岛特制源石弧
  for (const u of ops) {
    if (!has(u, ARC_KEY)) continue;
    const id = itemIdOf(u, ARC_KEY);
    const p = itemParams(id, 'act2autochess_equip_custom_rhodes_arc');
    if (!p) continue;
    const taken = num(p.damage_taken);
    if (taken > 0) passiveBuff(battle, u, `bond:${RHODES}:arc:taken`, { dmgTakenMul: Math.max(0.05, 1 - taken) });
    const member = isMember(battle, u, RHODES);
    const share = num(p.field_sum_share);
    // [ASSUMED] "攻击力和生命总和的X%加成" = X% of the on-field operators' summed ATK / max HP, granted as flat stats.
    // Σ 只开局记录一次（业主裁决 2026-10-15）：每 0.25 s 重读会让「携带者当前属性 → 它发给友军的鼓舞 → 友军当前属性
    // → Σ → 携带者的弧 grant → 携带者当前属性」闭成环（浊心斯卡蒂 / 魔王 / 三角初华）。一次性读值没有回边；
    // 代价：中途部署的干员不计入 Σ，阵亡 / 复活也不重算。
    if (member && share > 0) {
      const apply = () => {
        if (!onField(u)) return;
        let atk = 0, hp = 0;
        for (const o of battle.allies()) {
          if (o === u || o.kind !== 'op' || !onField(o)) continue;
          atk += num(o.s.atk); hp += num(o.s.maxHp);
        }
        passiveBuff(battle, u, `bond:${RHODES}:arc:sum`, { atkFlat: share * atk, hpFlat: share * hp });
      };
      battle.on('battleStart', apply, { once: true });
    }
    // 抑制环 synergy: the arc's whole "属性提升效果" — its atk / max HP part AND its 受到的伤害减少 — is shared
    // with the field (user 2026-10-06). The carrier already has the taken part itself, so that one only goes to the
    // others: dmgTakenMul multiplies, a second copy on the carrier would read −19 % / −36 % instead of −10 % / −20 %.
    if (member && has(u, RING_KEY)) {
      const base = itemParams(id, 'attr_common_global_buff');
      const atk = num(base?.atk), hp = num(base?.max_hp);
      if (atk > 0 || hp > 0 || taken > 0) {
        const mods = directMods({ atk, hp });
        const shared = taken > 0 ? { ...mods, dmgTakenMul: Math.max(0.05, 1 - taken) } : mods;
        const apply = () => { for (const o of ops) if (onField(o)) passiveBuff(battle, o, `bond:${RHODES}:arc:share`, o === u ? mods : shared); };
        apply();
        battle.on('battleStart', apply);
        battle.on('deploy', () => battle.after(0, apply));
        battle.every(POLL, apply);
      }
    }
  }

  // M3利爪 (custom) + M3茧甲 / M3护甲 (official, chess_item_4_12_e): attacks carry atk_scale x ATK as true damage
  // (PRTS 装置:M3利爪 技能1/2). Item-driven, no bond condition.
  for (const u of ops) {
    if (!has(u, CLAW_KEY) || !has(u, CARAPACE_KEY)) continue;
    const p = itemParams(itemIdOf(u, CLAW_KEY), 'act2autochess_equip_custom_m3_claw');
    const scale = num(p?.atk_scale);
    if (!(scale > 0)) continue;
    battle.on('damaged', (c) => {
      const s = c.source, t = c.target, dmg = c.dmg;
      if (s !== u || !dmg || !dmg.isAttack || !isEnemy(t)) return;
      if (tagged(dmg, 'item:m3claw')) return;
      battle.dealDamage(u, t, { amount: scale * u.s.atk, type: 'true', canDodge: false, tags: ['item:m3claw'] });
    });
  }
}

// =====================================================================================================================
// prep side

const C_PAID = 'bondcustom:kazdel:paid';

/** Every `layer` layers grant `count` copies of the bond's reward item (the 维多利亚 hammer-milestone pattern). */
export function payKazdelReward(ctx) {
  if (!ctx.bondActive(KAZDEL)) return 0;
  const p = buffParams(ctx.data?.bonds?.[KAZDEL] ?? bondRecord(KAZDEL), 'bond_layer_added_reward_equip');
  const step = Math.floor(num(p?.layer, 0));
  const itemId = typeof p?.reward_item === 'string' && p.reward_item ? p.reward_item : 'chess_item_c_01_e_a';
  if (!(step > 0)) return 0;
  const due = Math.floor(ctx.layers(KAZDEL) / step);
  const count = Math.max(1, Math.floor(num(p.count, 1)));
  let granted = 0;
  for (let guard = 0; guard < 100; guard++) {
    const paid = ctx.counter(C_PAID);
    if (paid >= due) break;
    ctx.setCounter(C_PAID, paid + 1);
    for (let i = 0; i < count; i++) {
      // onPrepEnd: grantItem stows the copy and merges it at the next prep start (effectsMeta _deferItemMerge)
      if (ctx.grantItem(itemId, { source: `bond:${KAZDEL}` })) granted++;
    }
  }
  if (granted && typeof ctx.toast === 'function') ctx.toast(`【卡兹戴尔】获得${granted}件萨卡兹的断角`, 'info');
  return granted;
}

const REWARD_HOOKS = Object.freeze(['onLayers', 'onRoundStart', 'onPrepStart', 'onPrepEnd', 'onBuy', 'onGain', 'onSold', 'onMerge']);

export function registerMeta(registry) {
  const handler = {};
  for (const hook of REWARD_HOOKS) {
    handler[hook] = function kazdelReward(ctx, ev) {
      if (hook === 'onLayers' && !(ev && ev.bondId === KAZDEL)) return;
      payKazdelReward(ctx);
    };
  }
  registry.bond(KAZDEL, handler);
}
