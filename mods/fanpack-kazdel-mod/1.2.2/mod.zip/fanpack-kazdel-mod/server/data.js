// server/data.js — loads the generated game data (data/*.json, produced by tools/build-data.mjs) once.
//
// Every `*.json` file in the data directory becomes a top-level key named after its basename
// (config, chess, bonds, garrisons, items, bands, effects, choices, enemies, factions, waves, stages,
// bosses, tokens, assets, backups, …). The result is deep-frozen so no module can mutate shared data by accident.
// Missing or unparsable files are tolerated with a warning (data is generated in parallel with the
// server); consumers must cope with an absent key.
//
// `packs/<id>/` is the optional fan-made content pack (a `data` pack — shared/packs.js, docs/PACKS.md): its
// `records` / `chess` / `tokens` / `variants` roles are loaded as the same keys the single-file pack used
// (`data/custom.json`, `data/custom-chess.json`, `data/custom-tokens.json`, `data/official-custom.json`), and merged
// over the official sections at load time — only when the caller asks for it (`{ custom: true }`); the server does,
// the data tests and the match harness do not, so the official counts stay exactly as the build wrote them. The
// single-file files are still read as a fallback (a pack wins on a collision).
//
// Index getters (DESIGN §2; same names as public/js/data.js): getChess, getBond, getGarrison, getItem, getBand,
// getEffect, getEnemy, getWave, getStage, getBoss, getToken, getConfig, getMode. The id-keyed files are already
// `{ [id]: record }` maps (docs/DATA.md), so a getter is an OWN-property lookup: ids that come from client
// intents (e.g. `g.band {bandId: "constructor"}`) can never resolve to inherited Object.prototype members.
// Every getter returns null for unknown ids / missing files and takes an optional data object (default:
// the process-wide getData() singleton).

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { mergeCustomContent, DATA_PACK_SECTIONS } from '../shared/customContent.js';
import { scanPacks } from './packs.js';

/** Repository root (…/Stronghold-Protocol). */
export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

/** Default data directory. */
export const DATA_DIR = path.join(ROOT, 'data');

/** Default pack folder (…/packs), a sibling of the data directory. */
export const PACKS_DIR = path.join(ROOT, 'packs');

/** Files the game expects (a warning lists the missing ones). */
export const DATA_FILES = Object.freeze([
  'config', 'chess', 'bonds', 'garrisons', 'items', 'bands', 'effects', 'choices',
  'enemies', 'factions', 'waves', 'stages', 'bosses', 'tokens', 'assets', 'backups',
]);

/**
 * Recursively freeze an object graph (iterative; safe for deep JSON). Returns the same object.
 * @template T
 * @param {T} root
 * @returns {Readonly<T>}
 */
export function deepFreeze(root) {
  const stack = [root];
  const seen = new Set();
  while (stack.length) {
    const o = stack.pop();
    if (o === null || typeof o !== 'object' || seen.has(o)) continue;
    seen.add(o);
    for (const v of Object.values(o)) if (v !== null && typeof v === 'object') stack.push(v);
    Object.freeze(o);
  }
  return root;
}

/**
 * Read every `*.json` in `dir` into `{ [basename]: parsed }`, deep-frozen.
 * Never throws: an unreadable directory yields `{}`; bad files are skipped with an error log.
 * @param {string} [dir] data directory (default ROOT/data)
 * @param {{ log?: { warn: Function, error: Function, info?: Function }, expected?: readonly string[],
 *   custom?: boolean, packsDir?: string }} [opts]
 *   `custom: true` loads the fan content pack: every supported `data` pack of `packsDir` (default: a `packs` folder
 *   next to `dir`), plus `data/custom*.json` as a fallback (shared/customContent.js)
 * @returns {Readonly<Record<string, any>>}
 */
export function loadData(dir = DATA_DIR, { log = console, expected = DATA_FILES, custom = false, packsDir = path.join(dir, '..', 'packs') } = {}) {
  /** @type {Record<string, any>} */
  const out = {};
  let names = [];
  try {
    names = fs.readdirSync(dir, { withFileTypes: true })
      .filter((d) => d.isFile() && d.name.toLowerCase().endsWith('.json'))
      .map((d) => d.name)
      .sort();
  } catch (e) {
    log.warn(`[data] cannot read ${dir}: ${e.code || e.message} — running without game data`);
  }
  for (const file of names) {
    const key = file.slice(0, -'.json'.length);
    try {
      out[key] = JSON.parse(fs.readFileSync(path.join(dir, file), 'utf8'));
    } catch (e) {
      log.error(`[data] skipping ${file}: ${e.message}`);
    }
  }
  const missing = expected.filter((k) => !(k in out));
  if (missing.length) log.warn(`[data] missing data files: ${missing.map((k) => k + '.json').join(', ')}`);
  if (!custom) return deepFreeze(out);
  readDataPacks(out, packsDir, log);
  const merged = mergeCustomContent(out, [out.custom, out['custom-chess'], out['custom-tokens']]);
  if (merged !== out) {
    const counts = Object.entries(merged)
      .filter(([k, v]) => k !== 'custom' && v && typeof v === 'object' && !Array.isArray(v))
      .map(([k, v]) => `${k}:${Object.keys(v).length}`);
    log.info?.(`[data] custom content pack merged (${counts.join(' ')})`);
  }
  return deepFreeze(merged);
}

/**
 * Put the fan content pack on `out`, under the keys the pack's sections load as (DATA_PACK_SECTIONS): `out.custom`,
 * `out['custom-chess']`, `out['custom-tokens']`, `out['official-custom']`. The single-file pack of 0.2.0
 * (`data/custom*.json`, already in `out`) is the fallback — a pack's record wins. Mutates `out`; quiet about a
 * missing pack folder, loud about a pack that is there and broken.
 * @param {Record<string, any>} out the loaded `data/*.json`
 * @param {string} packsDir the `packs` folder
 * @param {{ warn: Function, error: Function, info?: Function }} log
 */
function readDataPacks(out, packsDir, log) {
  /** @type {ReturnType<typeof scanPacks>} */
  let scan;
  try {
    scan = scanPacks({ packsDir });
  } catch (e) {
    log.warn(`[data] cannot read ${packsDir}: ${e.code || e.message} — no content pack`);
    return;
  }
  const { packs, skipped } = scan;
  for (const s of skipped) {
    // only what could be a data pack: a broken folder (its type is unknown) or one that says `data`; a language or
    // resource pack the registry skips is its own loader's business
    if (s.where.startsWith('packs/') && (s.type === undefined || s.type === 'data')) log.error(`[data] pack ${s.where} ignored: ${s.problems.join('; ')}`);
  }
  const ids = [];
  /** @type {Set<string>} */
  const seen = new Set(Object.values(DATA_PACK_SECTIONS).filter((k) => out[k] && typeof out[k] === 'object'));
  for (const pack of packs.filter((p) => p.type === 'data')) {
    let used = false;
    for (const [role, key] of Object.entries(DATA_PACK_SECTIONS)) {
      const json = pack.json?.[role];
      if (!json) continue;
      out[key] = seen.has(key) ? mergePatches(out[key], json) : json;   // the single-file fallback first, then packs
      seen.add(key);
      used = true;
    }
    if (used) ids.push(pack.id);
  }
  if (ids.length) log.info?.(`[data] content pack: ${ids.join(', ')}`);
}

/**
 * Merge two parsed pack files, `b` winning per record (a section that is a map of records is merged by id; anything
 * else — a list, a scalar, `_doc` — is replaced).
 * @param {any} a @param {any} b
 */
function mergePatches(a, b) {
  if (!a || typeof a !== 'object' || Array.isArray(a)) return b;
  const out = { ...a };
  for (const [k, v] of Object.entries(b || {})) {
    const base = out[k];
    out[k] = v && typeof v === 'object' && !Array.isArray(v) && base && typeof base === 'object' && !Array.isArray(base)
      ? { ...base, ...v } : v;
  }
  return out;
}

/** @type {Readonly<Record<string, any>> | null} */
let singleton = null;
/** Whether the singleton was loaded with the custom content pack merged in. */
let singletonCustom = false;

/**
 * Process-wide data singleton; loads on first call.
 *
 * `custom: true` (server) loads the content packs (packs/<id>/, its single-file ancestors included). It also **upgrades** a singleton that was
 * already loaded without the pack: server/sim/simdata.js loads the default data in its module body (top-level await,
 * before the server asks for anything), so by the time startServer calls `getData({ custom: true })` the official data
 * is usually already cached — silently returning it left the whole pack out of the running server.
 * @param {{ dir?: string, log?: object, custom?: boolean }} [opts]
 * @returns {Readonly<Record<string, any>>}
 */
export function getData({ dir = DATA_DIR, log = console, custom = false } = {}) {
  if (!singleton) {
    singleton = loadData(dir, { log, custom });
    singletonCustom = !!custom;
  } else if (custom && !singletonCustom) {
    singleton = loadData(dir, { log, custom: true });
    singletonCustom = true;
  }
  return singleton;
}

/** Drop the singleton so the next getData() reloads (tests / hot reload). */
export function resetData() { singleton = null; singletonCustom = false; }

// ---------------------------------------------------------------------------------------------------
// Index getters
// ---------------------------------------------------------------------------------------------------

/** Data files that are `{ [id]: record }` maps, with the getter name exported for each. */
export const INDEXED_FILES = Object.freeze({
  chess: 'getChess', bonds: 'getBond', garrisons: 'getGarrison', items: 'getItem', bands: 'getBand',
  effects: 'getEffect', enemies: 'getEnemy', waves: 'getWave', stages: 'getStage', bosses: 'getBoss', tokens: 'getToken',
});

/** Own-property record lookup in a plain-object map; null for anything else. */
function ownRecord(map, id) {
  if (typeof id !== 'string' || id.length === 0) return null;
  if (!map || typeof map !== 'object' || Array.isArray(map) || !Object.hasOwn(map, id)) return null;
  const rec = map[id];
  return rec !== null && typeof rec === 'object' ? rec : null;
}

/**
 * Record by id from an id-keyed data file (own properties only; never throws).
 * @param {string} file data file basename, e.g. 'chess'
 * @param {unknown} id record id
 * @param {Readonly<Record<string, any>>} [data] data object (default: getData())
 * @returns {any | null}
 */
export function lookup(file, id, data = getData()) {
  if (!data || typeof data !== 'object' || typeof file !== 'string' || !Object.hasOwn(data, file)) return null;
  return ownRecord(data[file], id);
}

/** @param {unknown} id chess id (normal `_a` or elite `_b`) @param {object} [data] */
export const getChess = (id, data) => lookup('chess', id, data);
/** @param {unknown} id bond id, e.g. 'yanShip' @param {object} [data] */
export const getBond = (id, data) => lookup('bonds', id, data);
/** @param {unknown} id garrison (特质) id @param {object} [data] */
export const getGarrison = (id, data) => lookup('garrisons', id, data);
/** @param {unknown} id item chess id @param {object} [data] */
export const getItem = (id, data) => lookup('items', id, data);
/** @param {unknown} id band (strategy) id @param {object} [data] */
export const getBand = (id, data) => lookup('bands', id, data);
/** @param {unknown} id effect id @param {object} [data] */
export const getEffect = (id, data) => lookup('effects', id, data);
/** @param {unknown} key enemy key @param {object} [data] */
export const getEnemy = (key, data) => lookup('enemies', key, data);
/** @param {unknown} id wave template id @param {object} [data] */
export const getWave = (id, data) => lookup('waves', id, data);
/** @param {unknown} id stage id @param {object} [data] */
export const getStage = (id, data) => lookup('stages', id, data);
/** @param {unknown} id boss id @param {object} [data] */
export const getBoss = (id, data) => lookup('bosses', id, data);
/** @param {unknown} id token id @param {object} [data] */
export const getToken = (id, data) => lookup('tokens', id, data);

/**
 * data/config.json, or null when missing.
 * @param {Readonly<Record<string, any>>} [data]
 * @returns {any | null}
 */
export function getConfig(data = getData()) {
  const cfg = data && typeof data === 'object' && Object.hasOwn(data, 'config') ? data.config : null;
  return cfg !== null && typeof cfg === 'object' && !Array.isArray(cfg) ? cfg : null;
}

/**
 * Mode record `config.modes[modeId]` (e.g. 'mode_multi_hard'), or null.
 * @param {unknown} modeId
 * @param {Readonly<Record<string, any>>} [data]
 * @returns {any | null}
 */
export function getMode(modeId, data = getData()) {
  const cfg = getConfig(data);
  return cfg ? ownRecord(cfg.modes, modeId) : null;
}
