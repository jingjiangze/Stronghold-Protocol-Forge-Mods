// server/index.js — process entry & boot (DESIGN §1, §2). Plain node:http + ws, no framework: startServer() below
// wires the modules under server/http/, in this order —
//
//   http/config.js     ROOT, the served directories, the environment (PORT 3000, HOST '::' dual-stack, TRUST_PROXY auto, DEBUG),
//                      which startServer() options go to net.js / lobby.js, the console logger
//   http/websocket.js  session wiring (SessionRegistry → Lobby → Network) and the WebSocket at /ws (maxPayload 64 KB;
//                      refused at upgrade with 404 / 429 per network / 503)
//   http/static.js     the static mounts (/ → public/, /data/, /shared/, /sim/ `.js` only), the /data.js browser stand-in,
//                      the content packs (/packs/index.json, /packs/<id>/<file> — the registry is packs.js)
//   http/media.js      /media/bgm/act1 → public/assets/audio/bgm/act1.mp3 (audio addressed without its extension)
//   http/files.js      one file → response: MIME, gzip + memory cache, ETag / Last-Modified / 304, Cache-Control, ranges
//   http/buildTag.js   the build tag of the served browser runtime (/healthz `build`, public/js/ui/buildGuard.js)
//   http/routes.js     the request listener: security headers, 414 / 400 / 405, GET /healthz → JSON status, else static
//   http/common.js     what every answer shares: security headers, URL split, error page, JSON replies, bare 400
//   http/boot.js       a pending update package first (update.js: old files deleted, the install verified against
//                      MANIFEST.json), banner (Local / LAN / tunnel URLs), port-in-use hint, graceful shutdown on SIGINT /
//                      SIGTERM
//
// Per-network limits for internet clients (see net.js clientAddress; local/LAN peers are exempt): open sockets
// (maxConnectionsPerAddr, refused at upgrade with 429), rooms and running matches (lobby.js).
//
// Programmatic use (tests): `const srv = await startServer({ port: 0, quiet: true }); … await srv.close();`
// The server only auto-listens when this file is the process entry point.

import http from 'node:http';
import path from 'node:path';
import { statSync } from 'node:fs';
import { getData, loadData } from './data.js';
import { setSimData } from './sim/simdata.js';
import { setGameData } from './sim/content/support/index.js';
import { CUSTOM_SECTIONS, hasCustomContent } from '../shared/customContent.js';
import { mergePatch, VARIANT_DATA_KEYS } from '../shared/dataVariants.js';
import { ROOT, listenAddress, bindCandidates, serveDirs, makeLogger, parseTrustProxy } from './http/config.js';
import { WS_MAX_PAYLOAD, createSessionStack, attachWebSocket } from './http/websocket.js';
import { DATA_SHIM_JS, createStaticHandler } from './http/static.js';
import { createPackRegistry } from './packs.js';
import { MIME, COMPRESSIBLE, acceptsGzip, parseRange } from './http/files.js';
import { BUILD_INPUTS, computeBuildTag, buildTag, resetBuildTag } from './http/buildTag.js';
import { createRequestHandler } from './http/routes.js';
import { answerClientError } from './http/common.js';
import { lanUrls, displayHost, isProcessEntry, runMain } from './http/boot.js';

// The public API of this module (tests and tools import it from here); the code lives in ./http/.
export {
  ROOT, WS_MAX_PAYLOAD, DATA_SHIM_JS, MIME, COMPRESSIBLE, BUILD_INPUTS, computeBuildTag, buildTag, resetBuildTag,
  acceptsGzip, parseRange, createStaticHandler, lanUrls, parseTrustProxy,
};

// ---------------------------------------------------------------------------------------------------
// The fan content pack's overlay (shared/customContent.js, docs/CUSTOM.md)
// ---------------------------------------------------------------------------------------------------

/**
 * Sections the custom content pack adds, keyed by data-file basename, for `createStaticHandler`'s overlay.
 * Null when no pack is loaded (the handler then serves the generated files untouched).
 * @param {Readonly<Record<string, any>>} data
 * @param {string} [publicDir] the served `public/` — when given, the pack's own art URLs carry a `?v=<size>-<mtime>`
 *   stamp (see stampPackArt)
 */
export function customOverlay(data, publicDir) {
  const packs = data && typeof data === 'object' ? [data.custom, data['custom-chess'], data['custom-tokens']] : null;
  const out = {};
  if (packs && hasCustomContent(packs)) {
    for (const section of CUSTOM_SECTIONS) {
      const merged = data[section];
      if (merged && typeof merged === 'object' && !Array.isArray(merged)) out[section] = merged;
    }
    const art = packArtManifest(data, publicDir);
    if (art) out.assets = art;
    // The pack's chess records also take their operators out of the 自选 data (shared/customContent.js
    // stripPackOperators): the browser runs the 自选 rules on the file it downloads, so it must see the filtered pool
    // too — otherwise it offers a pick the server (which reads the merged data) refuses.
    const pieces = packs.some((p) => p && p.chess && typeof p.chess === 'object' && Object.keys(p.chess).length);
    if (pieces && data.backups && typeof data.backups === 'object') out.backups = data.backups;
  }
  // the runtime 口径 switches' OFF data (DESIGN §23.42): the fan pack's own records are patched by
  // its own 口径 patch, so the browser must receive BOTH as one `official` section
  const official = mergedVariantFiles(data);
  if (official) out.official = official;
  return Object.keys(out).length ? out : null;
}

/**
 * `data/official.json` + the content pack's `variants.json` as one variant file (`null` when neither is loaded). The two
 * patch the same sections (`chess`, `tokens`), each for its own records — the applier merges them per section.
 * @param {Readonly<Record<string, any>>} data
 */
export function mergedVariantFiles(data) {
  const a = data && typeof data === 'object' ? data.official : null;
  const b = data && typeof data === 'object' ? data['official-custom'] : null;
  if (!a || typeof a !== 'object') return b && typeof b === 'object' ? b : null;
  if (!b || typeof b !== 'object') return a;
  const out = { ...a };
  for (const key of VARIANT_DATA_KEYS) {
    const sections = b[key];
    if (!sections || typeof sections !== 'object') continue;
    out[key] = { ...(a[key] || {}) };
    for (const [section, patch] of Object.entries(sections)) out[key][section] = mergePatch(out[key][section], patch);
  }
  return out;
}

/**
 * `data/assets.json` with the pack's own art merged in (`records.json` → `assets`): the icons of its goods and
 * its two core-bond glyphs. The file on disk keeps the official mapping — the pack is opt-in, so the browser only
 * sees these while the pack is loaded (the files themselves are copied to `public/assets/pack/` by
 * tools/fetch-assets.mjs from the sources in the pack's `art/`). Null when the pack ships no art or no manifest loaded.
 * @param {Readonly<Record<string, any>>} data
 */
function packArtManifest(data, publicDir) {
  const art = data && typeof data.custom === 'object' && data.custom ? data.custom.assets : null;
  const manifest = data && typeof data === 'object' ? data.assets : null;
  if (!art || !manifest || typeof manifest !== 'object') return null;
  return {
    ...manifest,
    items: stampPackArt({ ...(manifest.items || {}), ...(art.items || {}) }, publicDir),
    bonds: stampPackArt({ ...(manifest.bonds || {}), ...(art.bonds || {}) }, publicDir),
  };
}

/**
 * The pack's own art URLs with a `?v=<size>-<mtime>` stamp (`/assets/pack/…` only, when `publicDir` is known and the
 * file is on disk): the glyph and item icons are the one thing under `assets/` a running server cannot count on being
 * content-stable — the owner replaces an `art/*.png` and copies it in — and a browser that stored the plain URL keeps
 * showing the old picture (`Cache-Control` on those URLs is `no-cache` anyway, server/http/files.js: the stamp only
 * makes it a *new* URL, so a copy already cached is not consulted at all). Immutable is then the right policy: the URL
 * names the content. A missing file keeps the plain URL (the client falls back to its glyph).
 * @param {Record<string, string | object>} map url per asset key
 * @param {string} [publicDir]
 */
function stampPackArt(map, publicDir) {
  if (!publicDir || !map || typeof map !== 'object') return map;
  const out = { ...map };
  for (const [key, value] of Object.entries(out)) {
    if (typeof value !== 'string' || !value.startsWith('/assets/pack/')) continue;
    const rel = value.split('?')[0].slice(1).split('/');
    try {
      const s = statSync(path.join(publicDir, ...rel));
      if (s.isFile()) out[key] = `${value.split('?')[0]}?v=${s.size.toString(16)}-${Math.floor(s.mtimeMs).toString(16)}`;
    } catch { /* not downloaded / not this pack's file: keep the plain URL */ }
  }
  return out;
}
/**
 * Build and start the HTTP + WebSocket server.
 * @param {{
 *   port?: number, host?: string, quiet?: boolean, log?: object,
 *   publicDir?: string, dataDir?: string, sharedDir?: string, packsDir?: string,
 *   MatchClass?: Function, seedFn?: () => number,
 *   lobbyGraceMs?: number, reconnectWindowMs?: number, heartbeatMs?: number, helloTimeoutMs?: number,
 *   ratePerSec?: number, rateBurst?: number, maxConnections?: number, maxRooms?: number,
 *   maxConnectionsPerAddr?: number, maxRoomsPerAddr?: number, maxMatchesPerAddr?: number, resyncMinGapMs?: number,
 *   heavyPerSec?: number, heavyBurst?: number, trustProxy?: 'auto' | boolean, soloReconnectWindowMs?: number,
 * }} [opts]
 * @returns {Promise<{ port: number, host: string, url: string, server: http.Server, wss: import('ws').WebSocketServer,
 *                     lobby: import('./lobby.js').Lobby, network: import('./net.js').Network,
 *                     registry: import('./net.js').SessionRegistry, packs: ReturnType<typeof createPackRegistry>,
 *                     close: () => Promise<void> }>}
 */
export async function startServer(opts = {}) {
  const { port, host } = listenAddress(opts);
  const log = opts.log || makeLogger(!!opts.quiet);
  const { publicDir, dataDir, sharedDir, packsDir } = serveDirs(opts);

  // The process-wide singleton serves the default data dir; a custom dir (tests) gets its own copy.
  // custom: true merges the optional fan-made pack (packs/<id>/, docs/PACKS.md) — see server/data.js.
  const data = opts.dataDir
    ? loadData(dataDir, { log, custom: true, packsDir })
    : getData({ dir: dataDir, log, custom: true });
  // Both readers cache their own view of the data: server/sim/simdata.js resolves the default data in its module body
  // (top-level await) and sim/content/support/index.js caches it on first use. Either one may have taken the *official*
  // singleton before the pack was merged above, so hand them the merged object explicitly — otherwise the server would
  // simulate on the pack's records while the content modules still answer from the official tables (and the browser,
  // which fetches /data/*.json, would be the only place the pack shows up).
  setSimData(data);
  setGameData(data);
  const { registry, lobby, network } = createSessionStack(opts, { data, log });
  // content packs (docs/PACKS.md): scanned now — the start log names them — and again whenever their folders change
  const packs = createPackRegistry({ publicDir, dataDir, packsDir }, { log });
  packs.refresh(true);
  const serveStatic = createStaticHandler({ publicDir, dataDir, sharedDir, packsDir, packs, log, overlay: customOverlay(data, publicDir) });
  const startedAt = Date.now();
  // The tag is per process (see buildTag): read the browser runtime once, here, not on every /healthz.
  resetBuildTag();
  buildTag();

  const server = http.createServer(createRequestHandler({ serveStatic, health: { startedAt, network, registry, lobby }, log }));
  server.on('clientError', answerClientError);
  const wss = attachWebSocket(server, { network, log });

  // The address actually bound. The default may fall back to IPv4; the returned host and url follow that.
  let boundHost;
  try {
    // A host with IPv6 switched off refuses '::'. Fall back to IPv4 rather than not booting. Only the default is
    // retried: an explicit HOST is literal (server/http/config.js bindCandidates).
    let bound = null;
    let lastError = null;
    const candidates = bindCandidates(host);
    for (let i = 0; i < candidates.length; i++) {
      const candidate = candidates[i];
      try {
        await new Promise((resolve, reject) => {
          const onError = (e) => { server.off('listening', onListening); reject(e); };
          const onListening = () => { server.off('error', onError); resolve(); };
          server.once('error', onError);
          server.once('listening', onListening);
          server.listen(port, candidate);
        });
        bound = candidate;
        break;
      } catch (e) {
        lastError = e;
        const retry = ['EAFNOSUPPORT', 'EADDRNOTAVAIL', 'EINVAL'].includes(e.code) && i < candidates.length - 1;
        if (!retry) break;
        log.warn(`[boot] cannot bind ${candidate} (${e.code}) — falling back to IPv4 only`);
      }
    }
    if (bound === null) throw lastError;
    boundHost = bound;
  } catch (e) {
    network.close(); // stop heartbeat/sweep timers of the half-built server
    throw e;
  }
  server.on('error', (e) => log.error('[http] server error', e));

  const addr = server.address();
  const actualPort = typeof addr === 'object' && addr ? addr.port : port;
  const url = `http://${displayHost(boundHost)}:${actualPort}`;

  let closing = null;
  async function close() {
    if (closing) return closing;
    closing = (async () => {
      try { lobby.shutdown('shutdown'); } catch (e) { log.error('[shutdown] lobby', e); }
      network.close();
      await new Promise((resolve) => {
        server.close(() => resolve());
        server.closeIdleConnections?.();
        setTimeout(() => { server.closeAllConnections?.(); }, 500).unref();
      });
      try { wss.close(); } catch { /* ignore */ }
    })();
    return closing;
  }

  return { port: actualPort, host: boundHost, url, server, wss, lobby, network, registry, packs, close };
}

// `node server/index.js` / npm start: listen, print the banner, stop on SIGINT / SIGTERM (http/boot.js).
if (isProcessEntry(import.meta.url)) runMain(startServer);
