// server/match/pool.js — the SHARED chess pool (copies per base chess, across all players), per-match bans,
// copy-weighted shop rolls (research 00-INDEX §3, §6; DESIGN §6.2).
//
// Model:
//   * Every visible (non-hidden, non-DIY) base chess that is not banned this match has `cap` copies
//     (config.economy.poolCopies[tier], overrides e.g. 缪尔赛思 4). `left[baseId]` = copies not owned by anyone.
//   * Owning a piece takes copies: a normal piece holds 1, an elite holds 3 (merge of 3 normals). Shop displays
//     do NOT reserve copies; buying fails (SOLD_OUT) when left = 0.
//   * Pieces remember how many copies they hold (`piece.poolCopies`), so selling / elimination / temp wipes return
//     exactly what was taken — chess granted by effects while the pool is empty (or hidden/banned chess) hold 0.
//   * Invariant (tests): 0 ≤ left ≤ cap and left + Σ held copies == cap for every base chess.
//
// Rolls: each chess slot draws ONE copy uniformly from all remaining copies of eligible chess with tier ≤ shop level
// ("copy-weighted"; duplicates within a roll allowed). The item slot picks a tier with the same tier shares, then a
// uniform shop-eligible item of that tier (falling back to lower tiers). A roll may add entries outside the pool
// (`extra`, after its own): one player's 自选 stock (0.2.0, player/diy.js diyRollEntries) — weighted by its copies like
// any chess, drawn by that player's shop only.

/**
 * Per-match disabled bond set D and banned chess (research 01 A2): D = uniform sample of `core` core bonds and `addon`
 * add-on bonds among weight > 0 bonds that are active in the mode. A visible chess is banned iff every one of its
 * bonds is in D ∪ mode.inactiveBondIds.
 * @param {import('./gamedata.js').GameData} gd
 * @param {Function} rng seeded rng (createRng)
 * @returns {{ drawn: string[], staticOff: string[], banned: string[] }}
 */
export function drawDisabledBonds(gd, rng) {
  const { core: nCore, addon: nAddon } = gd.bans(gd.difficulty);
  const staticOff = [...gd.modeInactiveBonds].filter((b) => gd.bond(b)).sort();
  const eligible = gd.bondIds.filter((b) => {
    const bond = gd.bond(b);
    return bond && Number(bond.weight) > 0 && !gd.modeInactiveBonds.has(b);
  });
  const core = eligible.filter((b) => gd.bond(b).isCore);
  const addon = eligible.filter((b) => !gd.bond(b).isCore);
  const drawn = [...sample(core, nCore, rng), ...sample(addon, nAddon, rng)].sort();
  const off = new Set([...drawn, ...staticOff]);
  const banned = [];
  for (const id of gd.visibleChess) {
    const c = gd.chess(id);
    const bonds = Array.isArray(c.bonds) ? c.bonds : [];
    if (bonds.length > 0 && bonds.every((b) => off.has(b))) banned.push(id);
  }
  return { drawn, staticOff, banned };
}

function sample(arr, n, rng) {
  const a = arr.slice();
  rng.shuffle(a);
  return a.slice(0, Math.max(0, Math.min(n, a.length)));
}

export class SharedPool {
  /**
   * @param {import('./gamedata.js').GameData} gd
   * @param {{ banned?: Iterable<string> }} [opts]
   */
  constructor(gd, { banned = [] } = {}) {
    this.gd = gd;
    const ban = new Set(banned);
    /** @type {Map<string, { cap: number, left: number, tier: number }>} */
    this.entries = new Map();
    for (const id of gd.visibleChess) {
      if (ban.has(id)) continue;
      const cap = gd.poolCopies(id);
      if (cap <= 0) continue;
      this.entries.set(id, { cap, left: cap, tier: gd.tierOf(id) });
    }
    this.banned = [...ban].sort();
  }

  /** Whether a base chess is part of this match's pool (visible, not banned). */
  has(baseId) { return this.entries.has(baseId); }
  cap(baseId) { return this.entries.get(baseId)?.cap ?? 0; }
  left(baseId) { return this.entries.get(baseId)?.left ?? 0; }

  /** Take up to n copies; returns the number actually taken (0 when not in the pool / empty). */
  take(baseId, n = 1) {
    const e = this.entries.get(baseId);
    if (!e || !(n > 0)) return 0;
    const k = Math.min(e.left, Math.floor(n));
    e.left -= k;
    return k;
  }

  /** Return n copies (clamped at the cap). Returns the number actually returned. */
  give(baseId, n = 1) {
    const e = this.entries.get(baseId);
    if (!e || !(n > 0)) return 0;
    const k = Math.min(e.cap - e.left, Math.floor(n));
    e.left += k;
    return k;
  }

  /**
   * Remaining copies of eligible chess (tier ≤ maxTier, or exactly `tier`): the pool's entries, then `extra` ([id, entry]
   * pairs of the same shape — a player's 自选 stock) under the same filters.
   */
  _eligible({ maxTier = 6, tier = null, filter = null, extra = null } = {}) {
    const out = [];
    const scan = (list) => {
      for (const [id, e] of list) {
        if (e.left <= 0) continue;
        if (tier != null ? e.tier !== tier : e.tier > maxTier) continue;
        if (filter && !filter(id, e)) continue;
        out.push([id, e.left]);
      }
    };
    scan(this.entries);
    if (extra) scan(extra);
    return out;
  }

  /**
   * Copy-weighted roll: one copy uniformly among remaining copies of eligible chess. Returns a base id or null.
   * @param {Function} rng
   * @param {{ maxTier?: number, tier?: number|null, filter?: (id: string, e: object) => boolean,
   *   extra?: Iterable<[string, { left: number, tier: number }]>|null }} [opts]
   */
  roll(rng, opts = {}) {
    const el = this._eligible(opts);
    let total = 0;
    for (const [, n] of el) total += n;
    if (total <= 0) return null;
    let r = rng() * total;
    for (const [id, n] of el) { r -= n; if (r < 0) return id; }
    return el[el.length - 1][0];
  }

  /** Tier shares of a copy-weighted roll at shop level `maxTier` (current remaining copies). */
  tierShares(maxTier) {
    const t = {};
    let total = 0;
    for (const [, e] of this.entries) {
      if (e.tier > maxTier || e.left <= 0) continue;
      t[e.tier] = (t[e.tier] || 0) + e.left;
      total += e.left;
    }
    const out = {};
    for (const k of Object.keys(t)) out[k] = total > 0 ? t[k] / total : 0;
    return out;
  }

  /**
   * Item roll for the shop's item slot: tier by the chess tier shares at this level, uniform item within the tier,
   * falling back to lower tiers when a tier has no item. Returns an item id or null.
   *
   * `opts.prefer` / `opts.chance` bias the roll toward the bond the player is stacking (user request 2026-10-06, the
   * "B" variant): with probability `chance` the slot is filled from that bond's shop items of tier ≤ maxTier instead
   * of the whole pool. Every one of those goods now has the SAME share of that biased roll (owner 2026-10-11: 高阶盟约
   * 装 and 低阶盟约装备 — the latter are the ones a 变形同构体 can pair with — together take the 50 %, and with one of
   * each they are 25 % + 25 %): the old tier-first pick made a low-tier good much likelier than a 6 阶 one because the
   * chess tier shares decide how often its tier comes up. A bond that owns no shop item there (协防 … the add-on bonds
   * with no equipment at all, or a bond whose goods are all still above the shop level) yields nothing, and the slot
   * falls back to the plain roll — so the bias never invents an item the shop could not sell.
   */
  rollItem(rng, maxTier, { prefer = null, chance = 0 } = {}) {
    const inTier = (t, filter) => {
      const list = this.gd.shopItemsByTier[t] || [];
      return filter ? list.filter(filter) : list;
    };
    const tier = this._itemTier(rng, maxTier);
    if (prefer && chance > 0 && rng() < chance) {
      // every bond good the shop could sell, across tiers, one uniform draw (the tier roll above is kept so the RNG
      // sequence of a roll that falls through is unchanged)
      const mine = [];
      for (let t = 1; t <= Math.max(1, Math.min(6, maxTier)); t++) {
        for (const id of this.gd.shopItemsByTier[t] || []) if (this.gd.item(id)?.giveBondId === prefer) mine.push(id);
      }
      if (mine.length) return mine[Math.floor(rng() * mine.length)];
    }
    return this._itemOfTier(rng, tier, (t) => inTier(t), 6);
  }

  /** Tier of an item roll: the chess tier shares at `maxTier`, else a uniform tier ≤ maxTier. */
  _itemTier(rng, maxTier) {
    const shares = this.tierShares(maxTier);
    const tiers = Object.keys(shares).map(Number).sort((a, b) => a - b);
    if (!tiers.length) return 1 + Math.floor(rng() * Math.max(1, maxTier));
    let r = rng();
    for (const t of tiers) { r -= shares[t]; if (r < 0) return t; }
    return tiers[tiers.length - 1];
  }

  /** Uniform item of `tier`, walking down to tier 1 first, then up to `maxUp`; null when nothing is available. */
  _itemOfTier(rng, tier, listOf, maxUp) {
    for (let t = tier; t >= 1; t--) {
      const list = listOf(t);
      if (list.length) return list[Math.floor(rng() * list.length)];
    }
    for (let t = tier + 1; t <= maxUp; t++) {
      const list = listOf(t);
      if (list.length) return list[Math.floor(rng() * list.length)];
    }
    return null;
  }

  /** { baseId: left } snapshot (tests / diagnostics). */
  snapshot() {
    const o = {};
    for (const [id, e] of this.entries) o[id] = e.left;
    return o;
  }

  totalLeft() {
    let n = 0;
    for (const e of this.entries.values()) n += e.left;
    return n;
  }
}
