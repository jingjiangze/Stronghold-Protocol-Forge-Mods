// tools/fetch-tables.mjs — download the official tables the custom-content builder needs into
// `.cache/gamedata/<repo path>` (the same cache tools/build-data.mjs uses). Only the excel tables are fetched;
// the level files the official build also needs are not required to build custom operators.
//
//   node tools/fetch-tables.mjs            # download what is missing
//   node tools/fetch-tables.mjs --refresh  # re-download everything
//
// Source: Kengxxiao/ArknightsGameData (zh_CN), the same mirror build-data.mjs reads.
// Large files (character_table ~40 MB) are streamed to disk with retries — a plain fetch().arrayBuffer()
// hits undici's body timeout on them.

import { readFileSync, createWriteStream } from 'node:fs';
import { mkdir, stat, rename } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const CACHE = join(ROOT, '.cache', 'gamedata');
const GH = 'https://raw.githubusercontent.com/Kengxxiao/ArknightsGameData/master/zh_CN/gamedata/';
/** Mirrors tried in order — the raw GitHub host times out often; the proxies serve the same paths. */
const BASES = [
  `https://ghfast.top/${GH}`,
  `https://gh-proxy.com/${GH}`,
  `https://raw.gitmirror.com/Kengxxiao/ArknightsGameData/master/zh_CN/gamedata/`,
  GH,
];

/** Tables the custom builder reads (build-data.mjs downloads these plus the level files). */
const FILES = [
  'excel/character_table.json',
  'excel/skill_table.json',
  'excel/range_table.json',
  'excel/uniequip_table.json',
  'excel/battle_equip_table.json',
  'excel/activity_table.json',
];

const refresh = process.argv.includes('--refresh');
const ATTEMPTS = 4;

async function exists(p) {
  try { return (await stat(p)).size > 0; } catch { return false; }
}

/** Stream one URL into `dest` (temp file + rename), rotating mirrors and retrying on a network error. */
async function download(rel) {
  const dest = join(CACHE, rel);
  const tmp = `${dest}.part`;
  await mkdir(dirname(dest), { recursive: true });
  for (let attempt = 1; attempt <= ATTEMPTS; attempt++) {
    const base = BASES[(attempt - 1) % BASES.length];
    const host = base.replace(/^https?:\/\//, '').split('/')[0];
    const t0 = Date.now();
    try {
      const res = await fetch(base + rel, { redirect: 'follow' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      await pipeline(Readable.fromWeb(res.body), createWriteStream(tmp));
      const size = (await stat(tmp)).size;
      JSON.parse(readFileSync(tmp, 'utf8')); // validate before publishing
      await rename(tmp, dest);
      console.log(`ok     ${rel}  ${(size / 1048576).toFixed(1)} MB  ${Date.now() - t0} ms  via ${host}`);
      return true;
    } catch (e) {
      const cause = e && e.cause ? ` (${e.cause.code || e.cause.message || e.cause})` : '';
      console.error(`retry${attempt} ${rel} via ${host}: ${e && e.message}${cause}`);
      if (attempt < ATTEMPTS) await new Promise((r) => setTimeout(r, 1000 * attempt));
    }
  }
  return false;
}

let failed = 0;
for (const rel of FILES) {
  const dest = join(CACHE, rel);
  if (!refresh && (await exists(dest))) {
    console.log(`skip   ${rel} (cached)`);
    continue;
  }
  if (!(await download(rel))) { console.error(`FAIL   ${rel}`); failed++; }
}
if (failed) { console.error(`${failed} file(s) failed`); process.exitCode = 1; }
else console.log(`cache ready at ${CACHE}`);
