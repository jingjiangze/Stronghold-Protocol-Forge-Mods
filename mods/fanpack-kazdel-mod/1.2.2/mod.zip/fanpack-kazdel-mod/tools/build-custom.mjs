#!/usr/bin/env node
// tools/build-custom.mjs — build the chess records of the fan-made content pack (`packs/fanpack/`).
//
// Input:  docs/research/custom-operators.json  (name / tier / bonds per piece)
//         .cache/gamedata/excel/*.json         (official tables — run tools/fetch-tables.mjs once)
// Output: packs/<id>/chess.json    ({ chess: { <chessId>: Chess } }), merged at load time over data/chess.json
//         packs/<id>/tokens.json   its summons
//         packs/<id>/variants.json the pack's own 口径 patch (the browser receives it inside `official`)
//         packs/<id>/records.json  patched in place: bond member lists and 特质 owners from the roster
//         by server/data.js when the pack is loaded (shared/customContent.js, docs/PACKS.md).
//
// The records are produced by build-data.mjs's own `buildChess` (imported), fed synthetic `charShopChessDatas` /
// `charChessDataDict` entries — so stats, ranges, traits, skills, talents and module choices follow exactly the
// same rules as the official pool. Custom pieces are NOT written into data/chess.json: the official build and the
// data integrity tests stay untouched.
//
//   node tools/build-custom.mjs [--refresh | --offline]
//
// Chess ids: `chess_char_9_<NN>_a` / `_b`, NN = the entry's `nn` (or its 1-based position when `nn` is absent) — an
// explicit `nn` keeps every other id stable when an entry is added or removed.
//
// A SIDE build (`SP_PACK_SIDE=kazdel|rhodes SP_PACK_OUT=<dir>`, or `main({ side, outDir, packId })` — the split mods of
// mods/split/*, tools/mod-split.mjs) writes the pack of ONE of the two core bonds: the roster entries whose FIRST bond
// is that side's core bond (`kazdelShip` / `rhodesShip`), each with the other core bond dropped from its `bonds` list.
// records.json is pruned to the side too — the other core bond, its goods, its 特质 and its art leave the folder — and
// everything is written to `outDir` instead of packs/fanpack/. `packId` names the pack the folder holds (the folder
// name decides it in the end, server/packs.js): each side gets its own id so two of them can sit in one target
// (docs/MOD.md §6). The full build (no side) behaves exactly as before.
//
// An entry with `extend: true` gets **no** piece of its own: the season already ships that operator at that tier, so
// the pack extends the official piece instead (its `bonds` + `garrison` are merged into the official record, which
// then counts for the pack's bonds). One operator = one piece in the roster, and a piece may carry several core bonds.
// `garrisonReplace: true` turns that merge into a REPLACEMENT for the traits: the extended piece carries the pack's
// 特质 only, not the season's own beside them (休谟斯 — the owner's decision of 2026-10-07).

import { readFileSync, copyFileSync, existsSync } from 'node:fs';
import { mkdir, writeFile, rename } from 'node:fs/promises';
import { dirname, join, basename, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { SEASON, ROOT, loadGamedata, loadResearch, buildChess, buildTokens, naturalCmp, OPTS } from './build-data.mjs';
import { FULL_RANK } from '../shared/potential.js';
import { diffVariant } from '../shared/dataVariants.js';

const SPEC = join(ROOT, 'docs', 'research', 'custom-operators.json');
/** The repository's own content pack (docs/CUSTOM.md): the files below are its generated roles. */
const PACK_ID = 'fanpack';
const PACK_DIR = join(ROOT, 'packs', PACK_ID);
/** The two core bonds the pack introduces, by the `--side` name a split build uses. */
const SIDE_BOND = Object.freeze({ kazdel: 'kazdelShip', rhodes: 'rhodesShip' });
const ID_PREFIX = 'chess_char_9_';
const ID_START = 900; // identifier of the first custom piece

/** Strip the `PHASE_` prefix of an evolvePhase. */
const phaseIdx = (p) => (typeof p === 'number' ? p : Number(String(p ?? '').replace('PHASE_', '')) || 0);

/** Official tier row of `shopCharChessInfoData` (normal / golden). */
function tierRow(act, tier, golden) {
  return (act.shopCharChessInfoData[String(tier)] || []).find((p) => !!p.isGolden === golden) || {};
}

/** The tier's training status, clamped to the phases/levels the operator actually has (4★ cap at E1 …). */
function statusOf(act, char, tier, golden) {
  const row = tierRow(act, tier, golden);
  const maxPhase = Math.max(0, (char.phases?.length || 1) - 1);
  const phase = Math.min(phaseIdx(row.evolvePhase), maxPhase);
  const ph = char.phases?.[phase] || {};
  const frame = Array.isArray(ph.attributesKeyFrames) ? ph.attributesKeyFrames[ph.attributesKeyFrames.length - 1] : null;
  const maxLevel = ph.maxLevel || frame?.level || 1;
  return {
    evolvePhase: `PHASE_${phase}`,
    charLevel: Math.min(row.charLevel || 1, maxLevel),
    skillLevel: row.skillLevel || 7,
    equipLevel: 0,
  };
}

/** The operator's default module = its first ADVANCED module (the season's `defaultUniEquipId` convention). */
function defaultModule(uniequip, charId) {
  for (const id of uniequip.charEquip?.[charId] || []) {
    const meta = uniequip.equipDict?.[id];
    if (meta && meta.type !== 'INITIAL') return id;
  }
  return null;
}

/** Resolve an operator name to its `char_*` id (character_table also holds traps/tokens with the same name). */
function resolveCharId(charTable, name) {
  const hits = Object.keys(charTable).filter((id) => id.startsWith('char_') && charTable[id]?.name === name);
  if (hits.length === 1) return hits[0];
  if (!hits.length) throw new Error(`operator "${name}" not found in character_table`);
  throw new Error(`operator "${name}" is ambiguous: ${hits.join(', ')}`);
}

/** `garrison` may be one base id or a list; the normal piece takes `_a`, the elite `_b`. */
const garrisonIdsOf = (garrison, suffix) => {
  if (typeof garrison === 'string') return [`${garrison}_${suffix}`];
  if (Array.isArray(garrison)) return garrison.map((g) => `${g}_${suffix}`);
  return null;
};

/**
 * The 原型干员 a pack piece falls back to when the player marks it 未持有 (干员持有, shared/standIn.js isDroppableChess +
 * data/backups.json forms) — the owner's request of 2026-10-07 ("干员持有这里把卡兹戴尔和罗德岛也加上").
 *
 * The season's own 补位 pieces are tiers 3–6 only: its tiers 1–2 are 预设 (PRESET, "always field their own operator") and
 * `data/backups.json` therefore holds NO stand-in form at a tier-1 / tier-2 status — so the pack's tier-1 / tier-2 pieces
 * stay 预设 like the season's, and tier 3 and up get a stand-in.
 *
 * Which one: the 预备干员 of the piece's own profession (char_600–607, the 4★ reserves) at tiers 3–4, and the 6★
 * 罗德岛特派高级资深干员 of that profession (char_608–615) at tiers 5–6 — the two professions always match the piece, so
 * a 补位 piece keeps its class, and only the 特派 carry the `2/60/7/3` form a tier-6 精锐 needs. The skill is the
 * stand-in's last one (S3) and it carries no module [ASSUMED — the season's own pairs pick per piece, sometimes with a
 * module, sometimes S2; the reserves' and 特派's modules are the ones the official rows name, which the pack has no
 * equivalent for]. `tools/build-data.mjs` builds the forms for every (stand-in, status) pair an official piece uses, so
 * these assignments only reuse what is already in data/backups.json.
 */
const STANDIN_BY_PROFESSION = Object.freeze({
  PIONEER: ['char_600_cpione', 'char_608_acpion'],
  WARRIOR: ['char_601_cguard', 'char_609_acguad'],
  TANK: ['char_602_cdfend', 'char_610_acfend'],
  SNIPER: ['char_603_csnipe', 'char_611_acnipe'],
  CASTER: ['char_604_ccast', 'char_612_accast'],
  MEDIC: ['char_605_cmedic', 'char_613_acmedc'],
  SUPPORT: ['char_606_csuppo', 'char_614_acsupo'],
  SPECIAL: ['char_607_cspec', 'char_615_acspec'],
});
const STANDIN_SKILL = 2; // S3 — the stand-in's strongest skill, like most of the season's own pairs

/** The stand-in `charId` of a piece (profession + tier), or null when the piece stays 预设. */
function standInFor(profession, tier) {
  const pair = STANDIN_BY_PROFESSION[profession];
  if (!pair || !Number.isInteger(tier) || tier < 3) return null;
  return tier >= 5 ? pair[1] : pair[0];
}

/**
 * The official piece a roster entry extends: same operator (charId) and same shop tier among the visible, non-elite
 * records of data/chess.json. Throws when there is no such piece or the tier is ambiguous — an `extend` entry that
 * silently created a second piece again would be exactly the bug this mode exists to prevent.
 * @param {Record<string, any>} official data/chess.json
 * @param {string} charId
 * @param {number} tier
 * @param {string} label for the error message
 * @returns {Record<string, any>}
 */
function officialPiece(official, charId, tier, label) {
  // `tier: null` = the operator's own visible piece whatever tier it ships at (the `override` mode below).
  const hits = Object.values(official).filter((c) => c && c.visible && !c.isGolden && c.charId === charId && (tier == null || c.tier === tier));
  if (hits.length !== 1) {
    throw new Error(`${label}: expected exactly one visible official piece for ${charId}${tier == null ? '' : ` at tier ${tier}`}, found ${hits.length}` +
      (hits.length ? ` (${hits.map((c) => c.chessId).join(', ')})` : '') + ' — set the tier of the roster entry to the shipped one');
  }
  return hits[0];
}

/** Order-preserving union of two id lists. */
function unionIds(a, b) {
  const out = [];
  for (const id of [...(a || []), ...(b || [])]) if (typeof id === 'string' && id && !out.includes(id)) out.push(id);
  return out;
}

async function main({ side = process.env.SP_PACK_SIDE || null, outDir = process.env.SP_PACK_OUT || null, packId = null } = {}) {
  if (side && !SIDE_BOND[side]) throw new Error(`unknown side ${side} (expected ${Object.keys(SIDE_BOND).join(' | ')})`);
  if (side && !outDir) throw new Error(`a side build needs an output directory (SP_PACK_OUT, or main({ side, outDir }))`);
  const OUT_PACK = side ? resolve(outDir) : PACK_DIR;
  const OUT = join(OUT_PACK, 'chess.json');
  const OUT_TOKENS = join(OUT_PACK, 'tokens.json');
  const OUT_VARIANT = join(OUT_PACK, 'variants.json');
  const spec = JSON.parse(readFileSync(SPEC, 'utf8'));
  const core = side ? SIDE_BOND[side] : null;
  const otherCore = side ? (core === 'kazdelShip' ? 'rhodesShip' : 'kazdelShip') : null;
  // a side build keeps the entries whose FIRST core bond is this side's: one operator, one side (a piece naming both
  // core bonds — 阿斯卡纶, 逻各斯, 华法琳, 魔王 — belongs to the one its roster entry names first)
  const operators = side
    ? spec.operators
      .filter((op) => (Array.isArray(op.bonds) ? op.bonds : []).find((b) => Object.values(SIDE_BOND).includes(b)) === core)
      .map((op) => ({ ...op, bonds: op.bonds.filter((b) => b !== otherCore) }))
    : spec.operators;
  if (side && !operators.length) throw new Error(`no roster entry starts with ${core}`);
  const activity = await loadGamedata('excel/activity_table.json');
  const ac = activity?.autoChessData;
  const act = activity?.activity?.AUTOCHESS_SEASON?.[SEASON];
  if (!act || !ac) throw new Error('activity_table has no act2autochess / autoChessData section');

  const charTable = await loadGamedata('excel/character_table.json');
  const skillTable = await loadGamedata('excel/skill_table.json');
  const rangeTable = await loadGamedata('excel/range_table.json');
  const uniequip = await loadGamedata('excel/uniequip_table.json');
  const battleEquip = await loadGamedata('excel/battle_equip_table.json');
  const assets = await loadResearch('07-assets.json');

  const ctx = { act, ac, charTable, skillTable, rangeTable, uniequip, battleEquip, research: { assets } };
  // the pack's records ship the FULL-potential values, like data/chess.json (0.2.2: buildChess composes at ctx.potRank,
  // and the runtime's 干员练度 / 潜能 settings lower them via the record's own values — the pack has no potDown, so its
  // pieces are always fielded at what they ship)
  ctx.potRank = FULL_RANK;

  // The official build output: an `extend` entry is applied to the piece of the same operator and tier that ships
  // with the season (never a second copy), and operators the season shipped reuse its artwork (§ art below).
  const official = JSON.parse(readFileSync(join(ROOT, 'data', 'chess.json'), 'utf8'));

  const wanted = new Set();
  const meta = new Map(); // chessId -> { name, charId, tier, bonds, key, extend? }
  const entryId = new Map(); // roster index -> the chess id the entry stands for
  const extensions = []; // entries that extend an official piece
  /** The chess id of a roster entry: `nn` (or its position) for a new piece. */
  const idAt = (op, i) => `${ID_PREFIX}${String(op.nn ?? i + 1).padStart(2, '0')}_a`;

  operators.forEach((op, i) => {
    const charId = resolveCharId(charTable, op.name);
    const char = charTable[charId];

    if (op.extend) {      const record = officialPiece(official, charId, op.tier, `${op.name} (nn ${op.nn ?? i + 1})`);
      entryId.set(i, record.chessId);
      extensions.push({ op, record });
      meta.set(record.chessId, { name: op.name, charId, tier: op.tier, bonds: op.bonds, key: op.key, extend: true });
      return;
    }

    // `override`: the season ships this operator at a DIFFERENT tier. The pack's record is written on the season's
    // own chess ids so it replaces that record wholesale — one operator, one piece (迷迭香 T3 over its T6).
    const shipped = op.override ? officialPiece(official, charId, null, `${op.name} (nn ${op.nn ?? i + 1})`) : null;
    const nn = shipped ? null : String(op.nn ?? i + 1).padStart(2, '0');
    const normalId = shipped ? shipped.chessId : `${ID_PREFIX}${nn}_a`;
    const goldenId = shipped ? (shipped.goldenId || String(shipped.chessId).replace(/_a$/, '_b')) : `${ID_PREFIX}${nn}_b`;
    const modId = defaultModule(uniequip, charId);

    const normalStatus = statusOf(act, char, op.tier, false);
    const goldenStatus = statusOf(act, char, op.tier, true);
    // a module needs E2; the golden's equipLevel is the tier's (1, or 3 at tier 6)
    goldenStatus.equipLevel = goldenStatus.evolvePhase === 'PHASE_2' && modId ? (tierRow(act, op.tier, true).equipLevel || 1) : 0;

    const defaultSkillIndex = Number.isInteger(op.defaultSkillIndex)
      ? op.defaultSkillIndex
      : Math.min(2, Math.max(0, (char.skills?.length || 1) - 1));

    // 干员持有: a tier-3+ piece is a 补位 piece like the season's own (NORMAL + a stand-in), a tier-1/2 one stays 预设
    // (a PRESET chess's backup is itself, the official convention)
    const standIn = standInFor(char.profession, op.tier);

    act.charShopChessDatas[normalId] = {
      chessId: normalId,
      charId,
      chessLevel: op.tier,
      chessType: standIn ? 'NORMAL' : 'PRESET',
      isHidden: false,
      shopLevelSortId: ID_START + i,
      defaultSkillIndex,
      defaultUniEquipId: modId,
      goldenChessId: goldenId,
      backupCharId: standIn || charId,
      backupCharSkillIndex: standIn ? STANDIN_SKILL : defaultSkillIndex,
      backupCharUniEquipId: standIn ? null : modId,
      backupCharPotRank: 0,
    };
    act.charChessDataDict[normalId] = {
      chessId: normalId, identifier: ID_START + i, isGolden: false, upgradeNum: 3, upgradeChessId: goldenId,
      status: normalStatus, bondIds: op.bonds || [], garrisonIds: garrisonIdsOf(op.garrison, 'a') ?? op.garrisonIds ?? [],
    };
    act.charChessDataDict[goldenId] = {
      chessId: goldenId, identifier: ID_START + i, isGolden: true, upgradeNum: 0, upgradeChessId: null,
      status: goldenStatus, bondIds: op.bonds || [], garrisonIds: garrisonIdsOf(op.garrison, 'b') ?? op.garrisonIds ?? [],
    };
    act.chessNormalIdLookupDict[goldenId] = normalId;

    wanted.add(normalId);
    wanted.add(goldenId);
    entryId.set(i, normalId);
    meta.set(normalId, { name: op.name, charId, tier: op.tier, bonds: op.bonds, key: op.key });
    meta.set(goldenId, { name: op.name, charId, tier: op.tier, bonds: op.bonds, key: op.key });
  });

  const { chess, tokenOwners } = buildChess(ctx);

  /**
   * The pack's own chess records as `buildChess` writes them for the CURRENT 口径 flags: the records of the ids the pack
   * adds, the `extend` entries' official pieces (the pack's bonds merged in) and the official artwork of operators the
   * season already shipped. Called twice — for the official build `data/` ships and with the 满练度 status on; the
   * difference between the two is what the 干员练度 switch applies to the pack's pieces (DESIGN §23.42).
   * @param {Record<string, any>} built a buildChess() output (all ids)
   * @returns {{ out: Record<string, any>, art: number }} the records, and how many reused official artwork
   */
  /**
   * Give a piece the season ships as 预设 (or with no stand-in of its own) a 补位 stand-in, so 干员持有 lists it like the
   * season's own pieces (shared/standIn.js isDroppableChess: NORMAL + a stand-in). A piece the official data already
   * assigns a stand-in to keeps that assignment untouched.
   */
  const withStandIn = (rec) => {
    const own = rec.backup && rec.backup.charId;
    if (own && own !== rec.charId) return rec;
    const charId = standInFor(rec.profession, rec.tier);
    if (!charId) return rec;
    return { ...rec, chessType: 'NORMAL', backup: { charId, tmplId: null, skillIndex: STANDIN_SKILL, uniEquipId: null, potRank: 0 } };
  };

  const packRecords = (built) => {
    const out = {};
    let art = 0;
    for (const id of Object.keys(built).sort(naturalCmp)) if (wanted.has(id)) out[id] = built[id];
    const missing = [...wanted].filter((id) => !out[id]);
    if (missing.length) throw new Error(`buildChess produced no record for: ${missing.join(', ')}`);

    // `extend` entries: hand the official piece of that operator and tier the pack's bonds (+ its trait). The override
    // replaces the record as a whole (shared/customContent.js merges section → id), so it carries every official field.
    // `garrisonReplace: true` gives the piece the pack's traits INSTEAD of the official ones (an operator whose season
    // trait the pack does not want it to keep — 休谟斯, the owner's decision of 2026-10-07: its 罗德岛 trait is a 整备能力
    // 特质, and the official 突袭 one beside it made the card read as if the discount were a bonus of 突袭).
    for (const { op, record } of extensions) {
      const goldenId = record.goldenId || String(record.chessId).replace(/_a$/, '_b');
      const golden = official[goldenId] || null;
      const traits = (ids, suffix) => {
        const pack = garrisonIdsOf(op.garrison, suffix) ?? op.garrisonIds ?? [];
        return op.garrisonReplace ? [...pack] : unionIds(ids, pack);
      };
      out[record.chessId] = withStandIn({
        ...record,
        bonds: unionIds(record.bonds, op.bonds),
        garrisonIds: traits(record.garrisonIds, 'a'),
      });
      if (golden) {
        out[goldenId] = withStandIn({
          ...golden,
          bonds: unionIds(golden.bonds, op.bonds),
          garrisonIds: traits(golden.garrisonIds, 'b'),
        });
      }
    }

    // Reuse the official artwork of operators the season already shipped: their asset ids resolve in data/assets.json,
    // so the piece draws its real avatar / portrait / Spine. Operators the season never shipped keep buildChess's ids
    // (the client falls back until their art is fetched — docs/CUSTOM.md §6). Extended pieces already are official
    // records: their art is whatever the official build wrote.
    for (const rec of Object.values(out)) {
      const m = meta.get(rec.chessId);
      if (!m || m.extend) continue;
      const assets = artByChar.get(m.charId);
      if (assets) { rec.assets = { ...assets }; art++; }
    }
    return { out, art };
  };

  const artByChar = new Map();
  for (const c of Object.values(official)) {
    if (c && !c.isGolden && c.visible && c.charId && c.assets) artByChar.set(c.charId, c.assets);
  }
  const { out, art } = packRecords(chess);

  /** The pack's summons as `buildTokens` writes them (its own pieces' owners only) for the current 口径 flags. */
  const packTokens = (built, owners) => {
    const allTokens = buildTokens({ ...ctx, levels: {}, stageIds: [] }, built, owners, {});
    const out = {};
    for (const [id, t] of Object.entries(allTokens)) {
      if ((t.owners || []).some((owner) => wanted.has(owner))) out[id] = t;
    }
    return out;
  };
  const extended = extensions.length;

  // Patch the hand-authored records of the pack (packs/<id>/records.json) from the roster: the bond member lists, and
  // the `owners` of every custom 特质 record (which piece carries it — an `extend` entry moves its trait onto the
  // official piece). A SIDE build always reads the FULL file (the canonical hand-authored one) and writes the pruned
  // result to its own folder — the repository's pack is never touched.
  const packPath = join(PACK_DIR, 'records.json');
  const packDoc = JSON.parse(readFileSync(packPath, 'utf8'));
  const members = {};
  const owners = {};
  operators.forEach((op, i) => {
    const chessId = entryId.get(i);
    if (!chessId) return;
    for (const bondId of op.bonds || []) (members[bondId] ??= []).push(chessId);
    for (const g of garrisonIdsOf(op.garrison, 'a') ?? op.garrisonIds ?? []) (owners[g] ??= []).push(chessId);
    for (const g of garrisonIdsOf(op.garrison, 'b') ?? []) (owners[g] ??= []).push(String(chessId).replace(/_a$/, '_b'));
  });
  // The pack's own bonds (卡兹戴尔 / 罗德岛) exist only in the pack: their members ARE the pack's roster. An OFFICIAL bond
  // a pack piece joins (红豆 / 赫德雷 → 不屈, 煌 → 维多利亚 / 炎 …) instead keeps the season's own record — copied from
  // data/bonds.json with the pack's pieces APPENDED to members / visibleMembers. A hand-written entry of the pack's
  // records.json for such a bond only carries what the pack changes (e.g. a threshold), so its member list must never
  // replace the official one: the merge replaces a bond record wholesale (shared/customContent.js), and a short list
  // would make the 盟约总览 show 维多利亚 with its one pack member instead of the season's ten. Members hold the NORMAL
  // ids, like the official build writes them, and every pack piece is visible.
  const officialBonds = JSON.parse(readFileSync(join(ROOT, 'data', 'bonds.json'), 'utf8'));
  if (!packDoc.bonds) packDoc.bonds = {};
  let officialBondRows = 0;
  for (const [bondId, ids] of Object.entries(members)) {
    const sorted = [...new Set(ids)].sort(naturalCmp);
    const rec = packDoc.bonds?.[bondId];
    const src = officialBonds[bondId];
    if (!src) { // a bond only the pack introduces: its own record, its own member list
      if (rec) {
        rec.members = sorted;
        rec.visibleMembers = sorted;
      }
      continue;
    }
    const union = (a) => [...new Set([...(Array.isArray(a) ? a : []), ...sorted])].sort(naturalCmp);
    packDoc.bonds[bondId] = { ...src, ...(rec || {}), members: union(src.members), visibleMembers: union(src.visibleMembers) };
    officialBondRows++;
  }
  let ownerRows = 0;
  for (const [garrisonId, ids] of Object.entries(owners)) {
    const rec = packDoc.garrisons?.[garrisonId];
    if (!rec) continue;
    rec.owners = [...ids].sort(naturalCmp);
    ownerRows++;
  }
  // A SIDE build prunes the records to its side: the other core bond leaves with its goods, its 特质 and its art, and
  // the pieces of the other side leave the piece names. Everything is driven by the patched member / owner lists above:
  // a bond no entry of this side joins is gone, a 特质 no piece of this side carries is gone, and an item is kept when
  // the side's OWN core bond sells it, or when a kept 特质 / piece names it (M3利爪: granted by Mon3tr's `<获得时>`
  // trait, no `giveBondId`). An add-on bond's own goods stay out even when this side's roster joins that bond
  // (灵巧钩索): they are that bond's equipment, and they travel in their own mod (mods/split/fanpack-skillful).
  if (side) {
    const sideIds = new Set();
    for (const id of entryId.values()) { sideIds.add(id); sideIds.add(String(id).replace(/_a$/, '_b')); }
    const keptBonds = new Set(Object.keys(members));
    for (const id of Object.keys(packDoc.bonds || {})) if (!keptBonds.has(id)) delete packDoc.bonds[id];
    for (const [id, rec] of Object.entries(packDoc.garrisons || {})) {
      const own = Array.isArray(rec.owners) ? rec.owners : [];
      if (!own.some((o) => sideIds.has(o))) delete packDoc.garrisons[id];
    }
    const granted = JSON.stringify({ garrisons: packDoc.garrisons, chess: out });
    for (const [id, rec] of Object.entries(packDoc.items || {})) {
      const family = id.replace(/_[ab]$/, '');
      if (rec.giveBondId !== core && !granted.includes(family)) delete packDoc.items[id];
    }
    const keptTraps = new Set(Object.values(packDoc.items || {}).map((it) => it && it.trapId).filter(Boolean));
    const art = packDoc.assets && typeof packDoc.assets === 'object' ? packDoc.assets : {};
    packDoc.assets = {
      ...art,
      items: Object.fromEntries(Object.entries(art.items || {}).filter(([, url]) => keptTraps.has(basename(String(url), '.png')))),
      bonds: Object.fromEntries(Object.entries(art.bonds || {}).filter(([k]) => k === core)),
    };
    packDoc._doc = `${packDoc._doc}\n\n本文件由 tools/build-custom.mjs 的 side 构建生成（SP_PACK_SIDE=${side}）：只含 ${core} 一侧的盟约、\n干员、装备与特质；另一侧从名册里整体去掉。`;
  }
  const recordsOut = side ? join(OUT_PACK, 'records.json') : packPath;
  if (side) await mkdir(OUT_PACK, { recursive: true });
  await writeFile(recordsOut, `${JSON.stringify(packDoc, null, 2)}\n`);

  const doc = {
    _doc: `Generated by tools/build-custom.mjs from docs/research/custom-operators.json — the ${PACK_ID} pack's own chess. Do not edit by hand: edit the roster and rebuild. Merged over data/chess.json at load time (shared/customContent.js, docs/PACKS.md).`,
    version: 1,
    roster: operators.map((op, i) => ({ chessId: entryId.get(i), ...meta.get(entryId.get(i)) })),
    chess: out,
  };
  const text = JSON.stringify(doc);
  await mkdir(dirname(OUT), { recursive: true });
  const tmp = `${OUT}.tmp-${process.pid}`;
  await writeFile(tmp, text);
  await rename(tmp, OUT);

  // Summons: the pack's own pieces bring their tokens (凯尔希's Mon3tr, Mon3tr's 重构体 …). buildChess already
  // collected the owners of every token — keep only the ones a pack piece makes, so the official data/tokens.json
  // (22 records, pinned by test/data.test.js) stays exactly as the build wrote it. buildTokens also reads the stage
  // predefines for the season's band map characters; the pack ships none, so it gets an empty stage list.
  const allTokens = packTokens(chess, tokenOwners);
  const tokens = allTokens;
  const tokenDoc = {
    _doc: `Generated by tools/build-custom.mjs — the summons of the ${PACK_ID} pack's pieces (tokenId → record, same shape as data/tokens.json, variants keyed by the pack chess id). Merged over data/tokens.json at load time (shared/customContent.js).`,
    version: 1,
    tokens,
  };
  const tokenText = JSON.stringify(tokenDoc);
  const tmpT = `${OUT_TOKENS}.tmp-${process.pid}`;
  await writeFile(tmpT, tokenText);
  await rename(tmpT, OUT_TOKENS);

  // The LOCAL revision of the pack's own records (DESIGN §23.42): the same records built with --max-training on,
  // diffed against the official ones the pack's chess.json ships (the build writes the official tables as the base).
  // data/official.json holds the same patch for the official pieces; the server merges both into the `official`
  // section it serves (server/index.js), so the browser switches the pack's pieces too.
  const flags = { maxTraining: OPTS.maxTraining };
  OPTS.maxTraining = true;
  const onBuild = buildChess(ctx);
  const onChess = packRecords(onBuild.chess).out;
  const onTokens = packTokens(onBuild.chess, onBuild.tokenOwners);
  OPTS.maxTraining = flags.maxTraining;
  const variantDoc = {
    _doc: `Generated by tools/build-custom.mjs — the OFF 口径 of the ${PACK_ID} pack's own records (DESIGN §23.42), in the format of data/official.json. Served as one \`official\` section with data/official.json (server/index.js) and applied by the runtime 干员练度 switch.`,
    shipped: flags,
    training: {},
  };
  const dChess = diffVariant(onChess, out);
  const dTokens = diffVariant(onTokens, tokens);
  if (dChess) variantDoc.training.chess = dChess;
  if (dTokens) variantDoc.training.tokens = dTokens;
  const variantText = JSON.stringify(variantDoc);
  const tmpV = `${OUT_VARIANT}.tmp-${process.pid}`;
  await writeFile(tmpV, variantText);
  await rename(tmpV, OUT_VARIANT);

  // The rest of the pack folder (pack.json / README.md / art/), copied for a side build: only the side's own art
  // travels — its core-bond glyph and the icons of the goods its records kept (`assets.items` above).
  if (side) {
    const packJson = JSON.parse(readFileSync(join(PACK_DIR, 'pack.json'), 'utf8'));
    packJson.name = `${packJson.name} · ${side === 'kazdel' ? '卡兹戴尔' : '罗德岛'}`;
    // The folder a split mod installs the side under decides the pack id (server/packs.js), and each side gets its own
    // so two of them can sit in one target (docs/MOD.md §6). The library name stays `fanpack`. Correcting `id` here
    // keeps the pack log quiet ("the folder or file name decides" otherwise).
    if (packId) packJson.id = packId;
    packJson._doc = `${packJson._doc}\n\n本目录是 ${core} 一侧的构建（tools/build-custom.mjs 的 side 构建，mods/split/）：\n只含该侧名册的干员、装备与特质。`;
    await writeFile(join(OUT_PACK, 'pack.json'), `${JSON.stringify(packJson, null, 2)}\n`);
    if (existsSync(join(PACK_DIR, 'README.md'))) copyFileSync(join(PACK_DIR, 'README.md'), join(OUT_PACK, 'README.md'));
    const artIndex = JSON.parse(readFileSync(join(PACK_DIR, 'art', 'index.json'), 'utf8'));
    const keep = new Set([`bond_${core}`, ...Object.values(packDoc.assets.items || {}).map((u) => basename(String(u), '.png'))]);
    const outIndex = { _doc: artIndex._doc };
    await mkdir(join(OUT_PACK, 'art'), { recursive: true });
    for (const [key, rel] of Object.entries(artIndex)) {
      if (key.startsWith('_') || !keep.has(key)) continue;
      outIndex[key] = rel;
      copyFileSync(join(PACK_DIR, ...String(rel).split('/')), join(OUT_PACK, ...String(rel).split('/')));
    }
    await writeFile(join(OUT_PACK, 'art', 'index.json'), `${JSON.stringify(outIndex, null, 2)}\n`);
    console.log(`wrote the ${side} pack to ${OUT_PACK} (${Object.keys(packDoc.bonds || {}).length} bonds, ` +
      `${Object.keys(packDoc.items || {}).length} items, ${Object.keys(packDoc.garrisons || {}).length} 特质, ` +
      `${Object.keys(outIndex).length - 1} art file(s))`);
  }
  console.log(`wrote ${Object.keys(out).length} chess records to ${OUT} ` +
    `(${(Buffer.byteLength(text) / 1024).toFixed(0)} KB): ${wanted.size} new ids + ${extended} extended official pieces, ` +
    `${art} reusing official artwork, ${ownerRows} 特质 owner lists patched`);
  console.log(`wrote ${Object.keys(tokens).length} token records to ${OUT_TOKENS} (${Object.keys(tokens).join(' ') || 'none'})`);
  console.log(`wrote the local revision of ${Object.keys(dChess || {}).length} chess / ${Object.keys(dTokens || {}).length} token records to ${OUT_VARIANT} (${(Buffer.byteLength(variantText) / 1024).toFixed(0)} KB)`);
}

const invoked = (() => { try { return fileURLToPath(import.meta.url) === (process.argv[1] || ''); } catch { return false; } })();
if (invoked) {
  main().catch((e) => {
    console.error('build-custom failed:', e && e.stack ? e.stack : e);
    process.exitCode = 1;
  });
}
export { main };
