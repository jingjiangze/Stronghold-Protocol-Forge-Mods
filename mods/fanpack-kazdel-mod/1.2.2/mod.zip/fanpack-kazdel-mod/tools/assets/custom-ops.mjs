// tools/assets/custom-ops.mjs — operator art for the fan content pack (docs/CUSTOM.md).
//
// The pack's chess (packs/<id>/chess.json) can name any operator of the game, but docs/research/07-assets.json only
// covers the operators the official season shipped (its ids come from act2autochess). The pack's roster includes 12
// operators the season never shipped, so without this module the client would draw placeholders for them (and
// `data/assets.json` would have no avatar / portrait / battle Spine to serve).
//
// This module turns the pack's own chess records into 07-style research entries, using the URL patterns recorded in
// 07-assets.json `meta.patterns` (all four sources are community dumps of the official client; every pattern was
// HEAD-checked by research 07). fetch-assets.mjs merges the result into `assets07.operators`, so the plan, the
// downloads and data/assets.json then treat those operators exactly like the season's own — nothing rewrites
// docs/research/07-assets.json, which stays exactly as generated.

import { RAW, joinUrl, mirrorUrl } from './sources.mjs';

/** Normal chess of the pack grouped by charId (a charId may carry several chess — 阿斯卡纶 has two tiers). */
function byChar(packChess) {
  /** @type {Map<string, any[]>} */
  const out = new Map();
  for (const rec of Object.values(packChess?.chess ?? {})) {
    if (!rec || typeof rec.charId !== 'string' || !rec.charId) continue;
    if (rec.isGolden) continue; // the elite shares its operator's art
    const list = out.get(rec.charId);
    if (list) list.push(rec); else out.set(rec.charId, [rec]);
  }
  return out;
}

/** `avatar/{charId}.png` (E2: `_2`), research 07 `meta.patterns.avatar`. */
const avatarOf = (charId, e2 = false) => ({ url: `${RAW.yuanyan}avatar/${charId}${e2 ? '_2' : ''}.png` });
/** `portrait/{charId}_1.png` (E2: `_2`), `meta.patterns.portrait`. */
const portraitOf = (charId, e2 = false) => ({ url: `${RAW.yuanyan}portrait/${charId}_${e2 ? '2' : '1'}.png` });

/** `spine/{charId}/{charId}/{Front|Back}/{charId}.{skel|atlas|png}`, `meta.patterns.opSpine`. */
function battleSpineOf(charId) {
  const side = (s) => {
    const base = `${RAW.fexli}spine/${charId}/${charId}/${s}/${charId}`;
    const skel = { url: `${base}.skel` };
    const rec = { skel, atlas: { url: `${base}.atlas` }, png: { url: `${base}.png` } };
    const mirror = mirrorUrl(skel.url);
    if (mirror) rec.jsdelivrSkel = mirror;
    return rec;
  };
  return { front: side('Front'), back: side('Back'), note: null };
}

/** Every selectable skill of the operator, as research 07 lists them (`icon` under `skill/`, `meta.patterns.skillIcon`). */
function skillsOf(records) {
  const seen = new Map();
  for (const rec of records) {
    for (const s of rec.skills ?? []) {
      if (!s || !Number.isInteger(s.index) || seen.has(s.index)) continue;
      const skillId = typeof s.skillId === 'string' ? s.skillId : null;
      const iconId = typeof s.iconId === 'string' && s.iconId ? s.iconId : skillId;
      seen.set(s.index, {
        index: s.index,
        skillId,
        iconId,
        icon: iconId ? { url: joinUrl(RAW.yuanyan, `skill/skill_icon_${iconId}.png`) } : {},
        sfx: {},
      });
    }
  }
  return [...seen.values()].sort((a, b) => a.index - b.index);
}

/**
 * 07-style operator entries for every pack operator whose charId `have` does not cover yet.
 * @param {any} packChess packs/<id>/chess.json
 * @param {Record<string, any>} have assets07.operators (the season's operators)
 * @returns {{ entries: Record<string, any>, ids: string[], missing: string[] }}
 *   entries: merge into assets07.operators; ids: the charIds added; missing: charIds the pack needs but this could not
 *   build (no chess record / no skills — should stay empty)
 */
export function customOperatorAssets(packChess, have = {}) {
  const entries = {};
  const ids = [];
  const missing = [];
  for (const [charId, records] of [...byChar(packChess)].sort(([a], [b]) => a.localeCompare(b))) {
    if (have && Object.hasOwn(have, charId)) continue; // the season shipped this operator: research 07 already lists it
    const first = records[0];
    const skills = skillsOf(records);
    if (!skills.length) { missing.push(charId); continue; }
    entries[charId] = {
      name: first.name ?? null,
      rarity: Number.isInteger(first.rarity) ? `TIER_${first.rarity}` : null,
      profession: first.profession ?? null,
      subProfessionId: first.subProfessionId ?? null,
      nationId: first.nationId ?? null,
      // informational, like research 07: which chess of the pack use this operator
      chess: records.map((r) => ({
        chessId: r.chessId,
        chessLevel: Number.isInteger(r.tier) ? r.tier : null,
        chessType: r.chessType ?? 'PRESET',
        defaultSkillIndex: Number.isInteger(r.skill?.index) ? r.skill.index : 0,
        evolvePhase: r.status === 2 ? 'PHASE_2' : 'PHASE_1',
      })),
      avatar: { e0e1: avatarOf(charId), e2: avatarOf(charId, true) },
      portrait: { e0e1: portraitOf(charId), e2: portraitOf(charId, true) },
      skills,
      battleSpine: battleSpineOf(charId),
      sfx: {},
    };
    ids.push(charId);
  }
  return { entries, ids, missing };
}

/**
 * 07-style entries for the pack's summoned tokens (its `tokens.json`), so the same `node tools/fetch-assets.mjs`
 * run also downloads their avatar / 立绘 / battle Spine (docs/CUSTOM.md §6, §7).
 *
 * Tokens are shaped differently from operators in research 07: `name`, `avatar`, a Spine model and `sfx` — never a
 * portrait. The community dumps carry only a token's *skin* models (the default-skin folder is absent: fexli has
 * `spine/token_10050_monstr_prosts/token_10050_monstr_prosts_boc_11/…` and no `…/token_10050_monstr_prosts/…`), which
 * is exactly why research 07 lists the season's skin-only tokens as `battleSpineSkinVariantsOnly` too. `plan.mjs` then
 * builds `spine/{id}/{variant}/{Spine|Front}/{variant}.{skel|atlas|png}` and takes the first that resolves.
 *
 * Verified facts (2026-10-06, HEAD-checked) live in `docs/research/custom-assets.json` `tokens`:
 * - avatars exist for all three (yuanyan `avatar/{tokenId}.png`);
 * - 凯尔希 的 Mon3tr has a 立绘 (`skin/token_10002_kalts_mon3tr_1b.png`), the 重构体 / 魂灵之影 have none anywhere
 *   (yuanyan `portrait/` and `skin/`, fexli `charpor/` and `charpack/` all 404 for them) — a token's art *is* its avatar.
 * @param {Record<string, any>} packTokens packs/<id>/tokens.json `tokens`
 * @param {Record<string, any>} have assets07.tokens (the season's 20 tokens)
 * @param {Record<string, any>} [overrides] docs/research/custom-assets.json `tokens`
 * @returns {{ entries: Record<string, any>, ids: string[], missing: string[] }} missing: no Spine found in the dumps
 */
export function customTokenAssets(packTokens, have = {}, overrides = {}) {
  const entries = {};
  const ids = [];
  const missing = [];
  const size = (x) => (Number.isFinite(x) ? { bytes: x } : {});
  for (const [tokenId, rec] of [...Object.entries(packTokens || {})].sort(([a], [b]) => a.localeCompare(b))) {
    if (!/^token_\d+_[a-z0-9_]+$/i.test(tokenId)) continue;
    if (have && Object.hasOwn(have, tokenId)) continue; // research 07 already plans it
    const over = overrides?.[tokenId] || {};
    const skins = (Array.isArray(over.spineSkins) ? over.spineSkins : []).filter((s) => typeof s === 'string' && s);
    entries[tokenId] = {
      name: rec?.name ?? null,
      avatar: { url: over.avatar?.url || `${RAW.yuanyan}avatar/${tokenId}.png`, ...size(over.avatar?.bytes) },
      // 立绘 — present only where a dump carries the token's full art (07's tokens have none)
      ...(over.portrait?.url ? { portrait: { url: over.portrait.url, ...size(over.portrait.bytes) } } : {}),
      battleSpineDefault: null,
      battleSpineSkinVariantsOnly: skins,
      sfx: {},
    };
    ids.push(tokenId);
    if (!skins.length) missing.push(tokenId);
  }
  return { entries, ids, missing };
}
