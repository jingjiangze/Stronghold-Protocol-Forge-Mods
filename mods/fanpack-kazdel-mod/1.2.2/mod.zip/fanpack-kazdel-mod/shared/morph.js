// shared/morph.js — 变形同构体 (`items.json` `canGiveBond`): the one item whose carrier gains an extra bond, implemented
// over this module by the prep server (server/match/bondsMeta.js pieceBonds), the battle itself
// (server/sim/content/support/index.js unitBonds and its meta twin meta.js withGrants) and the client
// (public/js/ui/gameLogic/bonds.js grantedBonds) — the four must agree (test/match/morph-bonds.test.js,
// test/ui/morph-bonds.test.js).
//
// Official rule (band 变形者集群 "与特定装备一同装备时装备者将视为特定盟约成员"; the item's talent, character_table
// trap_1073_acarm073, lists the 14 pairings) — plus the owner's revision of 2026-10-10, a deliberate deviation of this
// project (mod 变形同构体加强, docs/MOD.md §6):
//
//   * it takes NO equipment slot: a carrier whose two slots are used can still take it, and equipping a third item
//     replaces one of the two real ones — never the morph (server/match/player/items.js, gamedata.equipPerChess);
//   * a carrier holds at most one of it, either quality;
//   * it grants the bond of the FIRST bond item in the carrier's equipment row — not every bond item's
//     (变形同构体 + 炎国短刀 + 谢拉格不融冰 grants 炎 only, and the leftmost 炎国短刀 is the one that decides).
//
// Everything else is the official rule: the granted bond counts like any member (BOARD bonds on the board only, once
// per operator), and a 盟约签名装配 (`giveBondBiasOnly`, tools/build-data.mjs ITEM_BOND_BINDINGS) never pairs.

/** Is `rec` the 变形同构体 — the data flag `canGiveBond`? */
export const isMorphItem = (rec) => !!(rec && rec.canGiveBond === true);

/**
 * Does `rec` hand its bond to a 变形同构体 carrier? A real bond id, and not a 盟约签名装配 (`giveBondBiasOnly`) — those
 * belong to their bond for the shop bias / the codex, they REQUIRE a member.
 * @param {any} rec an items.json record
 * @param {(bondId: string) => boolean} [hasBond] whether the bond exists in the data (server / sim); client: any
 */
export const morphGrants = (rec, hasBond = () => true) => !!(rec && !rec.canGiveBond && !rec.giveBondBiasOnly
  && typeof rec.giveBondId === 'string' && rec.giveBondId && hasBond(rec.giveBondId));

/**
 * The extra bond a carrier's equipment grants through its 变形同构体: the `giveBondId` of the FIRST item that grants one
 * (the leftmost in the equipment row), or null — no 变形同构体 carried, or nothing to pair with.
 * @param {Iterable<any>} recs the carrier's item records, in equipment-row order
 * @param {(bondId: string) => boolean} [hasBond]
 * @returns {string|null}
 */
export function morphBond(recs, hasBond = () => true) {
  const list = Array.isArray(recs) ? recs : [...(recs || [])];
  if (!list.some(isMorphItem)) return null;
  for (const rec of list) if (morphGrants(rec, hasBond)) return rec.giveBondId;
  return null;
}

/**
 * How many equipment slots a carrier's `items` use: the 变形同构体 takes none, so they count up to
 * `gamedata.equipPerChess` (2) without it.
 * @param {Iterable<any>} items item records, or pieces (`{ id }` / id strings) when `getItem` is given
 * @param {(id: string) => any} [getItem] resolves a piece's item id to its record (only ids are handed to it)
 */
export function equipSlotsUsed(items, getItem = null) {
  let n = 0;
  for (const it of items || []) {
    const rec = getItem ? getItem(typeof it === 'string' ? it : it?.id) : it;
    if (!isMorphItem(rec)) n += 1;
  }
  return n;
}
