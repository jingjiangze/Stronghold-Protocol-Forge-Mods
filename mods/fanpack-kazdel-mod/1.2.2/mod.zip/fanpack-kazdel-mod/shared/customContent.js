// shared/customContent.js — the optional fan-made content pack: `packs/<id>/` (a `data` pack, shared/packs.js,
// docs/PACKS.md) or the single-file `data/custom.json` + `data/custom-chess.json` + `data/custom-tokens.json` that
// came before it (server/data.js reads both).
//
// The pack is merged into the generated official data (`data/*.json`, produced by tools/build-data.mjs) *at load
// time*, never on disk: the official files and every integrity test that reads them stay exactly as the build wrote
// them. It is OFF by default — `loadData` / `getData` return the official data unless the caller asks for the pack
// (`{ custom: true }`). The server turns it on (server/index.js); the data tests and the match harness do not, so the
// official counts stay 266 chess / 112 visible / 23 bonds.
//
// Pack shape (every section optional):
//
//   { "version": 1, "notes": "…",
//     "bonds":     { "<bondId>": BondRecord },      // → data/bonds.json
//     "items":     { "<itemId>": ItemRecord },      // → data/items.json
//     "chess":     { "<chessId>": ChessRecord },    // → data/chess.json
//     "garrisons": { "<garrisonId>": GarrisonRecord }, // → data/garrisons.json
//     "effects":   { "<effectId>": EffectRecord } } // → data/effects.json
//
// A section is merged over the same-named data file, the pack's record winning on an id collision.
//
// The pack's new chess records also take their operators OUT of the 自选 data (data/backups.json `diy`): a 自选 slot
// fields "the owned 6★ outside the chess pool" (shared/diy.js), and an operator the pack turns into a chess piece is
// fielded as that piece — offering it in 自选 as well would field it twice and bypass the piece's own 盟约.

/** Data sections the pack may add to (the generated file basenames). */
export const CUSTOM_SECTIONS = Object.freeze(['bonds', 'items', 'chess', 'tokens', 'garrisons', 'effects']);

/**
 * The `data` pack type's file roles (shared/packs.js PACK_TYPES.data) → the key each one is loaded as. Keeping these
 * keys exactly the ones the single-file pack of 0.2.0 used (`data/custom.json` and its two generated halves) means
 * every consumer — mergeCustomContent below, server/index.js customOverlay / packArtManifest / mergedVariantFiles —
 * takes a pack's records with no change.
 */
export const DATA_PACK_SECTIONS = Object.freeze({
  records: 'custom',            // bonds / items / garrisons / effects / assets (packs/<id>/records.json)
  chess: 'custom-chess',        // the pack's own pieces (its chess.json)
  tokens: 'custom-tokens',      // its summons (its tokens.json)
  variants: 'official-custom',  // its 口径 patch (its variants.json, shared/dataVariants.js)
});

/** True for a plain (non-array, non-null) object. */
const isMap = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

/** A copy of `o` without `keys`. @param {Record<string, any>} o @param {Set<string>} keys */
const omit = (o, keys) => Object.fromEntries(Object.entries(o).filter(([k]) => !keys.has(k)));

/** A copy of `o` with every value run through `fn`. @param {Record<string, any>} o @param {(v: any) => any} fn */
const mapValues = (o, fn) => Object.fromEntries(Object.entries(o).map(([k, v]) => [k, fn(v)]));

/**
 * The operators a pack adds to the chess pool: the `charId` of every chess record whose id the official data does not
 * have yet (a record that overrides an official chess keeps that chess's operator and changes nothing here).
 * @param {Record<string, any>} data the official sections, before the merge
 * @param {any} pack parsed pack file
 * @returns {Set<string>}
 */
export function packOperators(data, pack) {
  const add = isMap(pack) && isMap(pack.chess) ? pack.chess : null;
  const official = isMap(data) && isMap(data.chess) ? data.chess : {};
  const ids = new Set();
  for (const [id, rec] of Object.entries(add || {})) {
    if (isMap(rec) && typeof rec.charId === 'string' && rec.charId && !official[id]) ids.add(rec.charId);
  }
  return ids;
}

/**
 * Take the pack's operators out of the 自选 data: `diy.ownedPool` (the picks the picker offers, shared/diy.js diyPool),
 * their records (`diy.operators`), a prototype's locked selection if one of them is a 原型干员, and the units / summons
 * only a pick referenced (an operator a 补位 row still stands in for keeps its unit). `diy.excluded` is left alone: it
 * is the build's own list of excluded collab operators, not a place to add reasons.
 * @param {Record<string, any>} data merged sections
 * @param {Set<string>} ops the pack's operators (packOperators)
 * @returns {Record<string, any>} `data`, or a copy with the 自选 data filtered
 */
function stripPackOperators(data, ops) {
  const backups = isMap(data.backups) ? data.backups : null;
  const diy = isMap(backups?.diy) ? backups.diy : null;
  if (!ops.size || !diy) return data;
  const keep = (id) => !ops.has(id);
  const ownedPool = Array.isArray(diy.ownedPool) ? diy.ownedPool.filter(keep) : diy.ownedPool;
  const prototypes = isMap(diy.prototypes)
    ? mapValues(diy.prototypes, (l) => (Array.isArray(l) ? l.filter(keep) : l)) : diy.prototypes;
  const locked = isMap(diy.locked) ? mapValues(diy.locked, (t) => (isMap(t) ? omit(t, ops) : t)) : diy.locked;
  const operators = isMap(diy.operators) ? omit(diy.operators, ops) : diy.operators;
  const picked = new Set([
    ...(Array.isArray(ownedPool) ? ownedPool : []),
    ...Object.values(prototypes || {}).flatMap((l) => (Array.isArray(l) ? l : [])),
  ]);
  const soldUnit = (id) => ops.has(id) && !picked.has(id) && !(backups.units?.[id]?.standsIn?.length > 0);
  const units = isMap(backups.units) ? omit(backups.units, new Set(Object.keys(backups.units).filter(soldUnit))) : backups.units;
  // a summon survives while any of its owner forms does: `owners` are `<charId>@<statusKey>`
  const soldToken = (t) => {
    const owners = Array.isArray(t?.owners) ? t.owners : [];
    return owners.length > 0 && owners.every((k) => ops.has(String(k).split('@')[0]));
  };
  const tokens = isMap(backups.tokens) ? omit(backups.tokens, new Set(Object.keys(backups.tokens).filter((id) => soldToken(backups.tokens[id])))) : backups.tokens;
  return { ...data, backups: { ...backups, units, tokens, diy: { ...diy, ownedPool, prototypes, locked, operators } } };
}

/**
 * Shallow-merge the pack's sections into a copy of `data` (the caller freezes the result).
 * @param {Record<string, any>} data data loaded from `data/*.json`
 * @param {any | any[]} packs parsed pack file(s) (falsy entries are skipped)
 * @returns {Record<string, any>} a new object when a pack adds something, else `data`
 */
export function mergeCustomContent(data, packs) {
  if (!isMap(data)) return data;
  const list = Array.isArray(packs) ? packs : [packs];
  let out = data;
  const ops = new Set();
  for (const pack of list) {
    if (!isMap(pack)) continue;
    for (const section of CUSTOM_SECTIONS) {
      const add = pack[section];
      if (!isMap(add) || !Object.keys(add).length) continue;
      const base = isMap(out[section]) ? out[section] : {};
      out = out === data ? { ...data } : out;
      out[section] = { ...base, ...add };
    }
    for (const id of packOperators(data, pack)) ops.add(id);
  }
  return stripPackOperators(out, ops);
}

/**
 * Ids the pack adds to a section (empty array without the pack).
 * @param {any} pack parsed pack file
 * @param {typeof CUSTOM_SECTIONS[number]} section
 * @returns {string[]}
 */
export function customIds(pack, section) {
  const add = isMap(pack) ? pack[section] : null;
  return isMap(add) ? Object.keys(add) : [];
}

/** True when a pack (or any of several) adds at least one record (drives the server's data overlay). */
export function hasCustomContent(packs) {
  const list = Array.isArray(packs) ? packs : [packs];
  return list.some((pack) => isMap(pack) && CUSTOM_SECTIONS.some((s) => isMap(pack[s]) && Object.keys(pack[s]).length > 0));
}
