# packs/ — 内容包

把内容包按自己的文件夹放在这里：`packs/<id>/pack.json`（清单）加上它声明的那些文件。服务端会在
`/packs/index.json` 列出它找到的每个包，并在**下一次页面请求**时发现新包或改动 —— 不用重启、不用构建步骤。
`node tools/packs.mjs list` 显示找到了什么、跳过了什么、为什么。

这一版加载两种类型。

## `lang` —— 一种界面语言（可选地含游戏文本）

```json
{
  "id": "ja",
  "type": "lang",
  "lang": "ja",
  "name": "日本語",
  "englishName": "Japanese",
  "version": "1.0.0",
  "app": ">=0.2.0",
  "authors": ["your name"],
  "fallback": ["en"],
  "files": { "ui": "ui.json", "data": "data.json" }
}
```

语言也可以只是一个文件，`public/i18n/<code>.json`，同样的字段写在它的 `_meta` 里 —— 英文就是这样装的。

## `data` —— 同人内容（盟约 / 装备 / 棋子 / 召唤物 + 它们自己的美术）

```json
{
  "id": "fanpack",
  "type": "data",
  "name": "同人内容包",
  "version": "1.0.0",
  "app": ">=0.2.0",
  "credits": "…",
  "files": {
    "records": "records.json",
    "chess": "chess.json",
    "tokens": "tokens.json",
    "variants": "variants.json",
    "art": "art/index.json"
  }
}
```

`records`（必需）是手写的记录集，形状与旧的 `data/custom.json` 一样（`bonds` / `items` / `garrisons` /
`effects` / `assets`）；`chess` / `tokens` / `variants` 是生成的三份（`node tools/build-custom.mjs`）；`art`
把 `<key>` 映射到包里的图，构建时复制到 `public/assets/pack/`。服务端在启动时把它们合并进官方数据
（`server/data.js`，见 `docs/CUSTOM.md`），所以**改完内容要重启服务端**。本仓库自己那个包是
[`packs/fanpack/`](./fanpack/README.md)，一个完整的例子。

打包分享一个包：`node tools/pack-bundle.mjs <id>`（默认写到临时目录，`--out <dir>` 换地方）。

## 其它类型

`assets`（美术 / 音频 / 字体替换，客户端侧）还在规划中：这一版会把它列成 not supported，不会加载。

格式、规则和后来类型怎么接入：[docs/PACKS.md](../docs/PACKS.md)。翻译：[docs/I18N.md](../docs/I18N.md)。