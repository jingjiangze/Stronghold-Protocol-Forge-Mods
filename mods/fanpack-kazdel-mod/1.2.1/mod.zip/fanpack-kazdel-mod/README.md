# 卡兹戴尔盟约mod（fanpack-kazdel-mod 1.2.1，为上游 v0.2.4 制作）

卡兹戴尔盟约（同人内容包的内容切片）：卡兹戴尔阵营的干员、装备与其盟约效果。按 0.2.4 重新打包（原包是 0.2.2）。

## 安装

```
node fanpack-kazdel-mod\install.mjs <上游项目目录>             安装（先备份每个被覆盖的文件）
node fanpack-kazdel-mod\install.mjs <上游项目目录> --dry-run   只看要做什么，不写文件
node fanpack-kazdel-mod\install.mjs <上游项目目录> --verify    校验已装好的目标
node fanpack-kazdel-mod\install.mjs <上游项目目录> --uninstall 还原成装之前的样子
```

不需要 `--assets`：本包不带任何美术资源。装完重启上游服务（npm start）。

## 注意

* 只适用于 0.2.4。
* **一次只装一个**：本包与其它拆分包、整包 mod 会改到同一批文件，第二个装上去会被安装器的
  「目标不是 release 原文」检查拦住。

共 43 个文件（33 个覆盖发布原文，10 个新增），载荷 3208.8 KB。

## 更新日志

* **1.2.1**（2026-10-19）
  * 修复：源石弧的「场上总和」原本每 0.25 s 重读一次全场（`apply(); on('deploy'); on('death'); every(POLL, apply)`），
    于是「携带者当前属性 → 它发给友军的鼓舞 → 友军当前属性 → Σ → 携带者的弧 grant → 携带者当前属性」闭成了环，
    浊心斯卡蒂 / 魔王 / 三角初华 这类「把自身当前属性发给友军」的干员会数值指数膨胀。
    改为**只开局记录一次**（`battle.on('battleStart', apply, { once: true })`）；抑制环共享腿不读场上任何数值，仍是原节奏。
    代价（字面结果）：中途部署的干员不计入 Σ；阵亡 / 复活也不重算。
