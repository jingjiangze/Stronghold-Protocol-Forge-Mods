import test from 'node:test';
import assert from 'node:assert/strict';
import { usableRank, usableMirrors, mergeSources, RANK_URL, MIRRORS_URL, PREF_KEY } from '../client/cdn.js';
test('usableRank 过滤被排除/不可用的源并保留发布延迟', () => {
  const rows = usableRank({ rank: [
    { id: 'a', host: 'a.example', measured: true, ttfbMs: { 电信: 200 } },
    { id: 'b', host: 'b.example', excluded: true },
    { id: 'c', host: 'c.example', usable: false },
  ] });
  assert.deepEqual(rows.map((r) => r.id), ['a']);
  assert.equal(rows[0].measured, true);
});
test('常量固定（发布契约）', () => {
  assert.match(RANK_URL, /^https:\/\/speedcdn\.jiangjiangze\.icu\/cdn\/v1\/rank\.json$/);
  assert.equal(PREF_KEY, 'source');
});

test('usableMirrors 读 flat 清单并抽出 host / probe 路径', () => {
  const rows = usableMirrors({ flat: [
    { id: 'x', root: 'https://x.example', probe: '/p.bin', coverage: 'full' },
    { id: 'y', root: 'https://y.example/' },
    { root: 'https://z.example' },
  ]});
  assert.deepEqual(rows.map((r) => r.id), ['x', 'y']);
  assert.equal(rows[0].host, 'x.example');
  assert.equal(rows[0].probePath, '/p.bin');
  assert.equal(rows[1].probePath, '');
});

test('mergeSources 以 rank 优先，补上 mirrors 独有的源', () => {
  const merged = mergeSources(
    { rank: [{ id: 'a', host: 'a.example', measured: true, ttfbMs: { 电信: 100 } }] },
    { flat: [{ id: 'a', root: 'https://a.example' }, { id: 'b', root: 'https://b.example' }] },
  );
  assert.deepEqual(merged.map((r) => r.id), ['a', 'b']);
  assert.equal(merged[0].measured, true);
  assert.equal(merged[1].measured, false);
});

test('MIRRORS_URL 指向 downcdn', () => {
  assert.match(MIRRORS_URL, /^https:\/\/downcdn\.jiangjiangze\.icu\/cdn\/v1\/mirrors\.json$/);
});
