// 空实现：本插件只做客户端覆盖 + data 覆盖，没有服务端入口。
// plugin.lock.json 钉定需要它存在。
export async function activate() {}
