# 国家图书馆联动皮肤 mod

**三款皮肤**（2026-10-16 官方上架，`国家图书馆/I` 系列）：

| 干员 | 皮肤 | skinId |
|---|---|---|
| 黍 | **源远流长** | `char_2025_shu@nlc#1` |
| 烛煌 | **夜行烛火** | `char_1040_blaze2@nlc#1` |
| 琳琅诗怀雅 | **盛世之象** | `char_1033_swire2@nlc#1` |

## 素材来源

全部**从国服客户端（鹰角启动器）直接解包**，未依赖任何第三方镜像：

| 用途 | 客户端 AB 包 | 对象 |
|---|---|---|
| 战斗模型 front/back | `skinpack/char_<id>.ab` | Spine 三件套（skel/atlas/png），**从 fexli 镜像补全** |
| 头像 180x180 | `spritepack/ui_char_avatar_18.ab` | Texture2D `char_*_nlc#1` |
| 商店立绘 292x552 | `spritepack/arts_shop_skin_portrait_14.ab` | Texture2D `char_*_nlc#1` |

解包工具：**UnityPy**（Python）。

> Spine 三件套来自 `fexli/ArknightsResource` 镜像（该镜像与客户端内容一致，已逐字节核对尺寸）；
> 头像与商店立绘**只存在于客户端**，镜像站均无（已穷尽排查 yuanyan / fexli / ArknightsAssets 系列）。

## 安装

在项目根目录运行：

```powershell
pwsh -File Install-NLC-Skins.ps1
```

或手动：把 `public/` 与 `data/` 覆盖到项目根目录（先备份那 4 个 json）。

**安装后必须重启服务**（`data/assets.json` 是进程级单例，不重启不生效）。

## 数据文件改动

| 文件 | 改动 |
|---|---|
| `data/assets.json` | `chars[<charId>].skins[<skinId>]` 新增 3 条（含 `spine.front/back` 的 `anims`/`animations`/`bounds`、`avatar`、`portrait`）；`hash` 重算 |
| `data/skins.json` | 目录新增 3 条；`counts.skins` 274 → 277 |
| `data/avatars.json` | `items` 新增 6 条（`skin:` 与 `skinportrait:` 各 3）；`count` 919 → 925 |
| `data/skins-installed.json` | 176 → 179 条 |

**格式已严格保持原生风格**（`assets.json`/`skins.json` 紧凑与 indent=1，`avatars.json`/`skins-installed.json` indent=2 + 尾换行），
无整文件重排，diff 只含新增内容。

## 验证

- 端到端核对 **39/39 通过**（目录 / 素材清单 / 盘上文件 / 头像映射 / 已装清单）
- 服务器实测取件：头像 200 · Spine 200 · 商店立绘 200
- 每个模型的 `anims` 均含 `idle/deploy/attack/attackDown/skill/die/move/stun/skills`，
  `animations` 10~16 条（**缺 `anims` 会导致模型不加载、永久显示占位头像**）

## 回滚

```powershell
foreach ($f in @('skins.json','assets.json','avatars.json','skins-installed.json')) {
  Move-Item "data/$f.bak-before-nlc-mod" "data/$f" -Force
}
```

（素材文件留着无害：不被清单引用就不会被加载。）
