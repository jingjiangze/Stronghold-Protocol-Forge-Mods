﻿# 引擎修复：惊变「追忆」回到第 10 回合不出怪 / 卡死

## 现象（玩家反馈 2026-10-16）

使用传说惊变「追忆」（第 13 回合结束不进第 14 回合，改为进入第 10 回合整备阶段）之后：
**回到的第 10 回合不出怪，然后直接卡死。**

## 根因

`server/match/match/phases.js` 的 `startRound(r)`：

```js
startRound(r) {
  this.phase = PHASE.ROUND_START;
  this.round = r;                                   // r = 14
  ...
  for (const p of this.alivePlayers()) {
    const jump = this.dispatch(p, 'onRoundWouldStart', { round: r });   // 「追忆」把 ev.round 改成 10
    const to = jump && Number.isFinite(jump.round) ? Math.trunc(jump.round) : null;
    if (to != null && to !== r && to >= 1) { this.round = to; break; }  // this.round = 10
  }
  // ↓↓↓ 下面每一处都用**局部变量 r**，而它还是 14 ↓↓↓
  const isBoss = r === this.gd.bossRound || r === this.gd.hiddenRound;               // 误判为 boss 轮
  this.jibianPlan = matchJibianPlan(this.rngWaves, r, this.enemyJibianCards);        // 按 14
  this.wave = buildNormalWave(this.gd, this.rngWaves, this.factions, r, {...});      // 按 14 建波次
  for (const ps of alive) ps.startRound(r);                                          // 玩家回合号也成 14
  for (const ps of alive) this.dispatch(ps, 'onRoundStart', { round: r });           // 回合开始效果按 14
}
```

**只改了 `this.round`，没改局部 `r`。**

而 **第 14 回合是 boss 轮**（`mode_*_zhajing.bossRound = 14`），它的 `roundCfg` 是：

```
R10  template=act1autochess_h03   combatTimeLimit=115   ← 正常的普通波次
R14  template=None                combatTimeLimit=None  ← boss 轮，没有普通波次模板
```

于是 `buildNormalWave(gd, …, 14, …)` 走到 `if (!tpl) return { spawns: [], … }` —— **`spawns` 是空数组**，
一！只！怪！都！不！出！同时 `ps.startRound(14)` 让玩家自己的回合号变成 14、与 `match.round = 10` 不一致，
后续按回合号的判定全部错位 → **卡死**。

## 修复

`server/match/match/phases.js`，在改写回合号之后**同步局部变量 `r`**：

```js
    for (const p of this.alivePlayers()) {
      const jump = this.dispatch(p, 'onRoundWouldStart', { round: r });
      const to = jump && Number.isFinite(jump.round) ? Math.trunc(jump.round) : null;
      if (to != null && to !== r && to >= 1) { this.round = to; break; }
    }
+   // 把 r 同步成改写后的回合号，下面每一处（isBoss / buildNormalWave / ps.startRound / onRoundStart）都自动跟着走
+   r = this.round;
    this.fields = [];
```

**为什么改这一处就够**：`r` 在本函数里共 7 处使用（`this.round = r`、派发、`isBoss`、`matchJibianPlan`、
`buildNormalWave`、`ps.startRound`、两处 `onRoundStart` 派发），其中 `this.round = r` 与派发在同步点**之前**
（必须用旧值判定），其余 5 处全在**之后** —— 所以一处赋值全部修正。

**等价于 `startRound` 一开始就收到新回合号。**

修好后「追忆」回第 10 回合：不按 boss 轮走、按 `act1autochess_h03` / 115 秒正常出怪、玩家回合号也是 10。

## 影响面

- 只有 `onRoundWouldStart` 改写了回合号时才会走到（目前只有「追忆」）。
- 不会改写回合号的路径（「死亡回归」的 `startRound(同一回合)`、正常的 `startRound(round+1)`、
  boss 轮的 `startRound(hiddenRound)`）行为**完全不变**（此时 `r === this.round`，那行赋值是 no-op）。
- 语法检查通过。

## 安装

覆盖 `server/match/match/phases.js` 后**重启服务**。
