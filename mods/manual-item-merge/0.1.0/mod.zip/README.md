# 手动合成与拖拽堆叠（前向兼容参考包）

来源：`原版增强安装.zip` 里 `files/` 分支的相关改动。
本包**当前不能在 mod 管理器引擎上生效**，原因（审计结论，2026-10-20）：

- 卸下装备：✅ 已由引擎 `rules.unequip` 开关支持（两树 `shared/plugins/rules.js:40-43` 一致），vanilla-plus 插件 `rules:{unequip:"allow"}` 即生效。
- 手动合成 / 拖拽堆叠：❌ 引擎缺以下项（mod 管理器 `Server-Deploy` 树 grep 全空）。

## 引擎补面清单（补完即生效）

| 改动 | 位置（包内分支行号） |
|---|---|
| `gamedata.js` 暴露 `manualItemMerge` getter | `server/match/gamedata.js:302` |
| `acquire.js` 新增 `_autoItemMerge()` 并在 `acquireItem`/`checkItemMerges` 门控 | `server/match/player/acquire.js:323,289,327` |
| `items.js` 新增 `stackItem(itemUid,targetUid)` | `server/match/player/items.js:175` |
| `g.itemStack` 协议键 + intent 路由 | `shared/protocol.js:593`、`server/match/match/intents.js:47` |
| 客户端拖拽合成：`placement.js` mergePair/wornMergeCopy/dropIntent stack | `public/js/ui/gameLogic/placement.js:406,417,517` |
| 客户端 `gameActions.itemStack` | `public/js/ui/gameActions.js:94` |
| 各 mode 在 `modes.json` 设 `manualItemMerge:true` | `data/modes.json`（包内 vanilla-plus） |

## 目录

- `src/`：包内实现片段（原样提取，未改动），引擎补面时并入对应文件。
- `plugin.json`：manifest 2，仅声明存在。
