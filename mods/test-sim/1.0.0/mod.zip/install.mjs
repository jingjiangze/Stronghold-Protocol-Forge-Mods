#!/usr/bin/env node
// install.mjs — 测试模拟（训练房）· Forge 工坊包安装器
//
// A. 命令行
//    node install.mjs <Forge 游戏目录>            安装（丢进 workshop/ + 给面板桥打一行补丁）
//    node install.mjs <Forge 游戏目录> --dry-run   只检查
//    node install.mjs <Forge 游戏目录> --verify    核对
//    node install.mjs <Forge 游戏目录> --uninstall 卸载（移除本包 + 还原 extensions.js）
//
// B. 专属 mod 管理器（如果它收录这个包）：导出 install / uninstall / verify(target, { log })。
//
// 要装的东西只有两样：
//   1. workshop/test-sim/            纯工坊包（pack.json + server/train.mjs + ui/train.js + ui/train.css）
//   2. public/js/ui/extensions.js    **一行**：面板桥原来把整条消息对象传给 Net.send，
//                                    而这个引擎的签名是 (type, fields) —— 通道消息被 validateC2S 当
//                                    "unknown type [object Object]" 拒掉。改成 net.send('pack.msg', {...})。
//                                    原件备份在 backup-original/。
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PACK = path.join(HERE, 'pack');
const PATCH_REL = 'public/js/ui/extensions.js';
const PATCH_BACKUP = path.join(HERE, 'backup-original', 'extensions.js');
const PACK_ID = 'test-sim';

const FIND = "        return net.send({ t: 'pack.msg', pack: rec.pack, channel, ...(data === undefined ? {} : { data }) });";
const REPL = "        return net.send('pack.msg', { pack: rec.pack, channel, ...(data === undefined ? {} : { data }) });";

const say = (log) => (s) => (typeof log === 'function' ? log(s) : console.log('  ' + s));
const exists = (p) => { try { return fs.statSync(p).isFile(); } catch { return false; } };

export function isForgeDir(dir) {
  return !!dir && exists(path.join(dir, 'server', 'index.js')) && exists(path.join(dir, 'shared', 'workshop.js'));
}

function patchState(target) {
  const abs = path.join(target, PATCH_REL);
  if (!exists(abs)) return 'missing';
  const src = fs.readFileSync(abs, 'utf8');
  if (src.includes(REPL)) return 'patched';
  if (src.includes(FIND)) return 'pristine';
  return 'unknown';
}

export function install(target, opts = {}) {
  const log = say(opts.log);
  const t = path.resolve(String(target || ''));
  if (!isForgeDir(t)) throw new Error('不是 Forge 版游戏目录（缺 server/index.js / shared/workshop.js）：' + t);
  const dest = path.join(t, 'workshop', PACK_ID);
  fs.rmSync(dest, { recursive: true, force: true });
  fs.mkdirSync(dest, { recursive: true });
  for (const rel of walk(PACK)) {
    const dst = path.join(dest, ...rel.split('/'));
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(path.join(PACK, ...rel.split('/')), dst);
  }
  log('[OK] 工坊包已放到 workshop/' + PACK_ID + '/（' + walk(PACK).length + ' 个文件）');

  const state = patchState(t);
  if (state === 'patched') log('[OK] 面板桥补丁已存在（' + PATCH_REL + '）');
  else if (state === 'pristine') {
    fs.mkdirSync(path.dirname(PATCH_BACKUP), { recursive: true });
    if (!exists(PATCH_BACKUP)) fs.copyFileSync(path.join(t, PATCH_REL), PATCH_BACKUP);
    const src = fs.readFileSync(path.join(t, PATCH_REL), 'utf8');
    fs.writeFileSync(path.join(t, PATCH_REL), src.replace(FIND, REPL));
    log('[OK] 面板桥补丁：net.send(\'pack.msg\', {...})（原件备份在 backup-original/extensions.js）');
  } else if (state === 'unknown') {
    log('[!] ' + PATCH_REL + ' 的版本与本包预期不同，没有打补丁 —— 通道消息可能发不出去');
  } else {
    log('[!] 找不到 ' + PATCH_REL + '，跳过错补丁');
  }
  log('[i] 重启 Forge 服务器后生效；房间屏左侧会出现「测试模拟」把手。');
  return 0;
}

export function uninstall(target, opts = {}) {
  const log = say(opts.log);
  const t = path.resolve(String(target || ''));
  fs.rmSync(path.join(t, 'workshop', PACK_ID), { recursive: true, force: true });
  log('[OK] 已移除 workshop/' + PACK_ID);
  if (exists(PATCH_BACKUP)) {
    fs.copyFileSync(PATCH_BACKUP, path.join(t, PATCH_REL));
    log('[OK] 已还原 ' + PATCH_REL);
  }
  log('[i] 重启 Forge 服务器后生效。');
  return 0;
}

export function verify(target, opts = {}) {
  const log = say(opts.log);
  const t = path.resolve(String(target || ''));
  if (!isForgeDir(t)) throw new Error('不是 Forge 版游戏目录：' + t);
  let bad = 0;
  for (const rel of walk(PACK)) {
    const dst = path.join(t, 'workshop', PACK_ID, ...rel.split('/'));
    const src = path.join(PACK, ...rel.split('/'));
    if (!exists(dst) || sha(fs.readFileSync(dst)) !== sha(fs.readFileSync(src))) { log('[X] 不一致：workshop/' + PACK_ID + '/' + rel); bad++; }
  }
  const state = patchState(t);
  if (state !== 'patched') { log('[X] 面板桥补丁状态：' + state); bad++; }
  if (bad) throw new Error(bad + ' 处不一致');
  log('[OK] 包与补丁都在位（' + walk(PACK).length + ' 个文件）');
  return 0;
}

function walk(dir, base = '') {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
    const rel = base ? base + '/' + e.name : e.name;
    return e.isDirectory() ? walk(path.join(dir, e.name), rel) : [rel];
  });
}
const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');

// ---- 命令行 ----
const SELF = fileURLToPath(import.meta.url).split('?')[0];
const ARGV = process.argv.slice(2);
if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(SELF)) {
  const target = path.resolve(ARGV.find((a) => !a.startsWith('--')) || process.cwd());
  try {
    if (ARGV.includes('--uninstall')) uninstall(target);
    else if (ARGV.includes('--verify')) verify(target);
    else if (ARGV.includes('--dry-run')) {
      console.log('游戏目录：' + target);
      console.log('  面板桥：' + patchState(target));
      console.log('  [dry-run] 不写任何文件');
    } else install(target);
    process.exit(0);
  } catch (e) {
    console.error('[X] ' + ((e && e.message) || e));
    process.exit(1);
  }
}
