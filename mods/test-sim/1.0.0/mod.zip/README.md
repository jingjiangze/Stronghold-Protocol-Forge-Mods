# 测试模拟（训练房）· Forge 工坊包 v1.0.0

这是 `测试模拟` 的 **Forge 版**：不再改引擎文件，而是做成一个**工坊包**（`workshop/test-sim/`），
用 Forge 自己的 mod 表面（`client.panels` + `server.modules[].uses:["matchClass"]` + 包通道 `pack.msg`）实现。
装一次，房间屏左侧多一个「测试模拟」把手，配置好之后开始模拟就进训练房。

![面板](screenshots/01-panel.png)
![对局](screenshots/02-in-game.png)

## 它做什么

1. **房间屏**（还没开始）：点左侧「测试模拟」→ 选 **干员 / 装备 / 盟约（层数） / 地图 / 开局资金** → 「应用」。
2. **开始模拟**：第一帧 `m.public` 到了，面板把配置发给对局（包通道 `train`）；
   服务端的 Match 包装器收到后：跳过「本局信息」与「策略」→ 直接进第 1 回合休整期，并换上选定的**地图**、把干员 / 装备 / 盟约 / 资金发到手上。
3. **局内**：左侧把手变成「训练房（局内）」，再改一批东西点「应用到本局」立刻生效（换图从下一回合起）。

## 装法

```bat
node install.mjs "D:\卫戍协议创意工坊\Stronghold-Protocol-Forge-0.18.6-0.2.6-win-x64\app"
```

装两样东西：

| 装什么 | 为什么 |
|---|---|
| `workshop/test-sim/`（4 个文件） | 包本体：`pack.json` + `server/train.mjs` + `ui/train.js` + `ui/train.css` |
| `public/js/ui/extensions.js` 的**一行** | 这个引擎的面板桥有个 bug：它把整条消息对象传给 `Net.send`，而这个引擎的签名是 `(type, fields)`，于是包通道消息被 `validateC2S` 当 `unknown type [object Object]` 拒掉（`ctx.net.send()` 永远返回 false）。改成 `net.send('pack.msg', {...})` 就好了；原件备份在 `backup-original/extensions.js`，`--uninstall` 会还原 |

装完**重启 Forge 服务器**（`node server/index.js`），刷新页面。之后：

- `node install.mjs <目录> --verify`：核对包与补丁
- `node install.mjs <目录> --uninstall`：移除包并还原那一行

> 这份 Forge 安装（目录名 0.18.6-0.2.6、`package.json` 写 0.19.0）是**半套更新**：启动时更新器报
> `1 files differ from v0.19.0 (e.g. package.json)` 并拒绝启动。测试时把 `UPDATE.json` 移到
> `UPDATE.json.applied-0.19.0`，服务器就能按现有 0.19.0 文件起来（更新器读不到更新包就跳过）。想恢复自动更新，
> 重新下一次完整 v0.19.0 包再把它改回来。

## 边界（Forge 包 ABI 决定的）

1. **包不能建房**：`PANEL_SEND_TYPES` 是闭枚举（只有 `room.appearance` / `room.mods`），`room.create` 永远不在里面。
   所以训练房不是在「大厅那一格」开的，而是**先由引擎自己的界面建房，再在房间里启用**。
2. **模式与难度**由建房时决定，训练房不改它；**地图**只影响下一回合（首领 / 隐秘核心回合仍用首领自己的战场）。
3. 干员 / 装备 / 盟约在**作战、联防、首领战**期间不发（服务端拒绝），与 0.3.0 那版同一条规则。
4. 面板只认房主：配置与局内调整都只对房主生效（服务端校验 `hostId`）。
5. 配置存在浏览器 `localStorage`（`test-sim.config.v1`），刷新还在；「应用」后本次对局只发一次。

## 文件

```
测试模拟-forge工坊包-v1.0.0/
  install.mjs                 安装器（命令行 + 可被 mod 管理器 import）
  pack/                       这就是要放进 workshop/ 的包
    pack.json                 client.panels + server.modules + 通道声明
    server/train.mjs          Match 包装器：跳过本局信息/策略、发干员/装备/盟约/资金、下一回合换图
    ui/train.js               面板：房间屏把手 + 全屏配置台 + 局内调整（含干员头像 / 装备图标 / 盟约徽记）
    ui/train.css              样式（左侧竖排把手、深色配置台）
  backup-original/            补丁前的 extensions.js（卸载时还原）
  screenshots/                界面截图
```
