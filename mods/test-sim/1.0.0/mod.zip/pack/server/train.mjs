// server/train.mjs — 测试模拟（训练房）的服务端一半（工坊包，不改引擎文件）。
//
// 面板（ui/train.js）在自己的通道 'train' 上发两类消息：
//
//   { kind: 'setup', config }   房主在开局前点「应用」→ 对局一开始就把这一局变成训练房
//   { kind: 'live',  patch }    局内「训练房」按钮 → 再发一批干员 / 装备 / 盟约 / 资金 / 换图
//
// 这一层只做三件事，全部走引擎本来就有的原语（不新增协议、不碰引擎源码）：
//
//   1. 跳过「本局信息」与「策略」：给每个座位定默认策略后直接 enterBattleCheck()（与正常对局同一条路）；
//   2. 把选好的干员 / 装备 / 盟约 / 资金发下去：PlayerState 的 acquireChess / acquireItem / addLayers；
//   3. 换图：面板发来的战场在**下一回合**的 startRound 里换上（本回合的部署与出怪不变）。
//
// 边界：只有房主发的 setup 生效；干员 / 装备 / 盟约在作战、联防与首领战期间不发（与引擎「玩家改不了战果」同一条线）。
// 任何一步出错都只记一条日志，绝不让对局挂掉。

/** 战斗中的相位：这些相位不发干员 / 装备 / 盟约（跳回合也不在战斗里跳）。 */
const BATTLE = new Set(['COMBAT', 'UNITE', 'FINAL_ASSAULT', 'HIDDEN_CORE', 'RESULT', 'LOBBY']);

export function registerServer(host) {
  host.matchClass((Base) => class TestSimMatch extends Base {
    constructor(opts) {
      super(opts);
      /** 训练房的状态：只活在这一局的内存里。 */
      this.__ts = { owner: null, stage: null, preset: null, applied: false };
    }

    /** 面板通道：引擎在限流之后、转发之前调一次；true = 已消费。 */
    handlePackMsg(playerId, msg) {
      try {
        if (!msg || msg.channel !== 'train') return false;
        const d = msg.data;
        if (!d || typeof d !== 'object') return false;
        if (d.kind === 'setup') return this.__tsSetup(playerId, d.config) ? true : true;
        if (d.kind === 'live') { this.__tsLive(playerId, d); return true; }
        return false;
      } catch (e) {
        try { this.log && this.log.warn && this.log.warn('[test-sim] ' + ((e && e.stack) || e)); } catch { /* 忽略 */ }
        return false;
      }
    }

    /** 房主点「应用」：把这一局变成训练房。 */
    __tsSetup(playerId, cfg) {
      if (!cfg || typeof cfg !== 'object') return false;
      if (this.hostId && playerId !== this.hostId) return false;
      const ts = this.__ts;
      ts.owner = playerId;
      if (cfg.stage) ts.stage = String(cfg.stage);
      if (cfg.preset) ts.preset = cfg.preset;
      if (ts.applied) { this.__tsLive(playerId, { preset: cfg.preset, stage: cfg.stage }); return true; }
      ts.applied = true;
      const phase = String(this.phase || '');
      // 还停在选策略之前：直接给每个座位定默认策略，跳过后面的草稿
      if (phase === 'INFO_CHECK' || phase === 'BAND_DRAFT' || phase === 'LOBBY' || phase === 'BATTLE_CHECK') {
        const order = Array.isArray(this.order) ? this.order : [];
        for (const ps of order) {
          if (!ps || ps.bandId) continue;
          try {
            const id = typeof this.defaultBand === 'function' ? this.defaultBand(ps.playerId) : null;
            if (id) { ps.bandId = id; ps.lp = this.gd.startLp(id); }
            ps.infoReady = true;
          } catch { /* 一个座位失败不影响其它人 */ }
        }
        if (phase === 'INFO_CHECK' || phase === 'BAND_DRAFT' || phase === 'LOBBY') {
          try { if (typeof this.enterBattleCheck === 'function') this.enterBattleCheck(); } catch { /* 忽略 */ }
        }
      }
      try { if (typeof this.markPublic === 'function') this.markPublic(); } catch { /* 忽略 */ }
      return true;
    }

    /** 局内调整：资金 / 生命 / 回合 / 干员 / 装备 / 盟约 / 换图。 */
    __tsLive(playerId, d) {
      if (this.hostId && playerId !== this.hostId) return false;
      const ps = this.players && this.players.get ? this.players.get(playerId) : null;
      if (!ps) return false;
      if (d.stage) this.__ts.stage = String(d.stage);
      if (d.preset) this.__tsGrant(ps, d.preset);
      if (Number.isInteger(d.funds)) { try { ps.funds = Math.max(0, d.funds); ps.dirty(); } catch { /* 忽略 */ } }
      if (Number.isInteger(d.lp)) { try { ps.lp = Math.max(0, d.lp); ps.dirty(); } catch { /* 忽略 */ } }
      if (Number.isInteger(d.round) && d.round >= 1) {
        const phase = String(this.phase || '');
        if (!BATTLE.has(phase) && typeof this.startRound === 'function') {
          try { this.startRound(d.round); } catch { /* 忽略 */ }
        }
      }
      try { if (typeof this.markPublic === 'function') this.markPublic(); } catch { /* 忽略 */ }
      try { if (typeof this.markPrivate === 'function') this.markPrivate(ps); } catch { /* 忽略 */ }
      return true;
    }

    /** 发一批东西给某个座位（与引擎的 acquire / addLayers 同一条路）。 */
    __tsGrant(ps, p) {
      const phase = String(this.phase || '');
      if (BATTLE.has(phase)) return 0;
      if (!ps || !p) return 0;
      let n = 0;
      for (const id of Array.isArray(p.chess) ? p.chess : []) {
        try { if (ps.acquireChess(String(id), { source: 'grant', silent: true })) n++; } catch { /* 忽略 */ }
      }
      for (const id of Array.isArray(p.items) ? p.items : []) {
        try { if (ps.acquireItem(String(id), { source: 'grant', silent: true })) n++; } catch { /* 忽略 */ }
      }
      for (const b of Array.isArray(p.bonds) ? p.bonds : []) {
        if (!b || !b.id || !Number.isInteger(b.layers)) continue;
        try { if (ps.addLayers(String(b.id), b.layers, { reason: 'grant' }) > 0) n++; } catch { /* 忽略 */ }
      }
      if (Number.isInteger(p.funds)) { try { ps.funds = Math.max(0, p.funds); ps.dirty(); n++; } catch { /* 忽略 */ } }
      try { if (typeof ps.recompute === 'function') ps.recompute(); } catch { /* 忽略 */ }
      return n;
    }

    /** 换图落在下一回合：回合开始时先换 stage，再走引擎原来的 startRound。 */
    startRound(r) {
      try {
        const stage = this.__ts && this.__ts.stage;
        if (stage && this.gd && typeof this.gd.stage === 'function' && this.gd.stage(stage)) {
          this.stageId = stage;
          this.stage = this.gd.stage(stage);
          this.__ts.stage = null;
        }
      } catch { /* 忽略 */ }
      const out = super.startRound(r);
      try {
        const preset = this.__ts && this.__ts.preset;
        if (preset && r === 1) {
          this.__ts.preset = null;
          const owner = this.__ts.owner;
          const ps = owner && this.players && this.players.get ? this.players.get(owner) : null;
          if (ps) this.__tsGrant(ps, preset);
        }
      } catch { /* 忽略 */ }
      return out;
    }
  });
}
