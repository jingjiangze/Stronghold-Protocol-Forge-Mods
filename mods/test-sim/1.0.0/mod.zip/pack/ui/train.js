// ui/train.js — 测试模拟（训练房）的客户端一半（工坊面板，root.overlays）。
//
// 面板拿到的是引擎冻结的注入面：ctx.host（DOM 宿主）、ctx.net.on(engineType) 读引擎帧、
// ctx.net.send('train', data) 走本包自己的通道、ctx.data.get('<表>') 读只读数据快照。
// 没有 store / net.request —— 所以本面板**不建房、不开赛**：房间与对局仍由引擎自己的界面开。
//
// 流程（DESIGN「不改引擎文件」那条线）：
//   1. 在房间屏（还没开）点「训练房」→ 选地图 / 干员 / 装备 / 盟约 / 资金 → 「应用」；
//   2. 「开始模拟」后第一帧 m.public 到了 → 自动把配置发给对局（pack.msg 通道 'train'，服务端 server/train.mjs 接）；
//   3. 对局里左下角还有「训练房」：再发一批东西（kind:'live'）。
//
// 所有中文文案直接写在这里（工坊包不强制 i18n）。

const CSS_CLS = 'ts-train';

/** 面板状态（只活在这个页面里；配置最后一版写进 localStorage，刷新还记得）。 */
const state = {
  cfg: { stage: '', funds: '', chess: [], items: [], bonds: {} },
  tab: 'ops',
  q: '',
  room: null,     // 最后一帧 room.state
  pub: null,      // 最后一帧 m.public
  sent: false,    // 本次对局是否已经把 setup 发出去
  open: false,
};

const LS = 'test-sim.config.v1';
const loadCfg = () => {
  try {
    const j = JSON.parse(localStorage.getItem(LS) || 'null');
    if (j && typeof j === 'object') state.cfg = { ...state.cfg, ...j };
  } catch { /* 忽略 */ }
};
const saveCfg = () => { try { localStorage.setItem(LS, JSON.stringify(state.cfg)); } catch { /* 忽略 */ } };

const el = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined && text !== null) n.textContent = String(text);
  return n;
};
const clear = (n) => { while (n.firstChild) n.removeChild(n.firstChild); };
const txt = (rec, fallback) => {
  const s = rec && typeof rec.name === 'string' && rec.name ? rec.name : '';
  if (!s) return fallback || '';
  try { return (typeof window !== 'undefined' && window.__spLocaleName && window.__spLocaleName(s)) || s; } catch { return s; }
};

export async function mount(ctx) {
  const doc = (ctx.host && ctx.host.ownerDocument) || (typeof document !== 'undefined' ? document : null);
  if (!doc || !ctx.host) return { unmount() {} };
  const host = ctx.host;
  const net = ctx.net;
  // ctx.data 只交「引擎已经抓过的那几张」：房间屏上通常只有 chess 与 assets，items / bonds / stages 还是空的。
  // 缺的那几张按同一份 /data/<表>.json 自己取一次（与引擎抓的是同一份字节），拿到就缓存。
  const tables = { chess: {}, items: {}, bonds: {}, stages: {}, assets: {} };
  const ensure = async (name) => {
    const got = (() => { try { return ctx.data.get(name); } catch { return null; } })();
    if (got && Object.keys(got).length) { tables[name] = got; return; }
    try {
      const res = await fetch('/data/' + name + '.json', { cache: 'no-cache' });
      tables[name] = res.ok ? await res.json() : {};
    } catch { tables[name] = {}; }
  };
  await Promise.all(['chess', 'assets', 'items', 'bonds', 'stages'].map(ensure));
  loadCfg();

  const me = () => (typeof ctx.me?.snapshot === 'function' ? ctx.me.snapshot() : ctx.me) || {};
  const myId = () => (ctx.me && ctx.me.playerId) || null;
  const roomOf = () => state.room || (me().room || null);
  const inRoom = () => !!roomOf();
  const isHost = () => { const r = roomOf(); return !!r && r.hostId === myId(); };
  const inMatch = () => !!state.pub && ['INFO_CHECK', 'BAND_DRAFT', 'BATTLE_CHECK', 'ROUND_START', 'SP_DRAFT', 'PREP', 'COMBAT', 'UNITE', 'SETTLE', 'FINAL_ASSAULT', 'HIDDEN_CORE'].includes(String(state.pub.phase));

  // ---- 数据视图 -------------------------------------------------------------
  const avatarOf = (rec) => {
    const chars = tables.assets && tables.assets.chars;
    const id = rec && (rec.charId || (rec.assets && rec.assets.avatar));
    if (!chars || !id) return null;
    const c = chars[id];
    return (c && (c.avatar || c.avatarE2)) || null;
  };
  const itemIcon = (rec) => {
    const items = tables.assets && tables.assets.items;
    if (!items || !rec) return null;
    return items[rec.iconId] || items[rec.trapId] || null;
  };
  const bondIcon = (id) => (tables.assets && tables.assets.bonds && tables.assets.bonds[id]) || null;

  const opList = () => {
    const out = [];
    for (const rec of Object.values(tables.chess)) {
      if (!rec || rec.isGolden || rec.isDiy) continue;
      if (rec.chessType && rec.chessType !== 'PRESET' && rec.chessType !== 'NORMAL') continue;
      if (rec.isHidden || rec.visible === false) continue;
      out.push(rec);
    }
    out.sort((a, b) => (a.tier || 0) - (b.tier || 0) || (a.shopSortId || 0) - (b.shopSortId || 0));
    return out;
  };
  const itemList = () => {
    const out = Object.values(tables.items).filter((r) => r && !r.isGolden);
    out.sort((a, b) => (a.tier || 0) - (b.tier || 0) || (a.shopSortId || 0) - (b.shopSortId || 0));
    return out;
  };
  const bondList = () => {
    const out = Object.values(tables.bonds).filter(Boolean);
    out.sort((a, b) => (b.isCore ? 1 : 0) - (a.isCore ? 1 : 0) || (a.bondOrder || 0) - (b.bondOrder || 0));
    return out;
  };
  const stageList = () => {
    const out = Object.values(tables.stages).filter(Boolean);
    out.sort((a, b) => (a.active === false ? 1 : 0) - (b.active === false ? 1 : 0) || String(a.id).localeCompare(String(b.id)));
    return out;
  };
  const hit = (...fields) => {
    const q = String(state.q || '').trim().toLowerCase();
    if (!q) return true;
    for (const f of fields) if (typeof f === 'string' && f.toLowerCase().includes(q)) return true;
    return false;
  };

  // ---- 外观：一个左下角的把手 -------------------------------------------------
  const handle = el('button', CSS_CLS + '__handle', '训练房');
  handle.type = 'button';
  handle.title = '测试模拟 · 训练房';
  handle.style.display = 'none';
  host.appendChild(handle);

  const overlay = el('div', CSS_CLS + '__overlay');
  overlay.style.display = 'none';
  host.appendChild(overlay);
  let body = null;
  let footerNote = null;

  const closeOverlay = () => { state.open = false; overlay.style.display = 'none'; };
  const openOverlay = () => { state.open = true; overlay.style.display = ''; render(); };

  handle.addEventListener('click', () => (state.open ? closeOverlay() : openOverlay()));

  // ---- 渲染 ------------------------------------------------------------------
  const chip = (label, cls) => el('span', CSS_CLS + '__chip ' + (cls || ''), label);

  const tabBar = (tabs, onPick) => {
    const bar = el('div', CSS_CLS + '__tabs');
    for (const t of tabs) {
      const b = el('button', CSS_CLS + '__tab' + (state.tab === t.id ? ' is-on' : ''), t.label);
      b.type = 'button';
      b.addEventListener('click', () => { state.tab = t.id; state.q = ''; render(); });
      bar.appendChild(b);
    }
    return bar;
  };

  const searchRow = (placeholder, count) => {
    const row = el('div', CSS_CLS + '__searchrow');
    const inp = el('input', CSS_CLS + '__search');
    inp.type = 'search';
    inp.placeholder = placeholder;
    inp.value = state.q;
    inp.addEventListener('input', () => { state.q = inp.value; renderList(); });
    row.appendChild(inp);
    row.appendChild(el('span', CSS_CLS + '__count', count));
    return { row, inp };
  };

  let listBox = null;
  function renderList() {
    if (!listBox) return;
    clear(listBox);
    if (state.tab === 'ops') return renderOps(listBox);
    if (state.tab === 'items') return renderItems(listBox);
    if (state.tab === 'bonds') return renderBonds(listBox);
    if (state.tab === 'stage') return renderStages(listBox);
  }

  function renderOps(box) {
    const all = opList();
    const rows = all.filter((r) => hit(r.name, r.chessId, r.charId, r.subProfessionName, r.profession));
    for (const rec of rows) {
      const id = rec.chessId;
      const on = state.cfg.chess.includes(id);
      const row = el('button', CSS_CLS + '__row' + (on ? ' is-on' : ''));
      row.type = 'button';
      const av = el('span', CSS_CLS + '__thumb');
      const url = avatarOf(rec);
      if (url) { const img = el('img'); img.src = url; img.alt = ''; img.loading = 'lazy'; av.appendChild(img); }
      else av.appendChild(el('span', CSS_CLS + '__glyph', (txt(rec, id) || '?').slice(0, 1)));
      row.appendChild(av);
      const meta = el('span', CSS_CLS + '__meta');
      meta.appendChild(el('b', null, txt(rec, id)));
      meta.appendChild(el('small', null, (rec.tier || 1) + ' 阶' + (rec.subProfessionName ? ' · ' + rec.subProfessionName : '')));
      row.appendChild(meta);
      row.appendChild(el('span', CSS_CLS + '__tick', on ? '✓' : ''));
      row.addEventListener('click', () => {
        const i = state.cfg.chess.indexOf(id);
        if (i >= 0) state.cfg.chess.splice(i, 1);
        else if (state.cfg.chess.length < 24) state.cfg.chess.push(id);
        saveCfg();
        renderList();
        updateFooter();
      });
      box.appendChild(row);
    }
    if (!rows.length) box.appendChild(el('p', CSS_CLS + '__empty', '没有匹配的项'));
  }

  function renderItems(box) {
    const rows = itemList().filter((r) => hit(r.name, r.id, r.effectName, r.desc));
    for (const rec of rows) {
      const id = rec.id;
      const on = state.cfg.items.includes(id);
      const row = el('button', CSS_CLS + '__row' + (on ? ' is-on' : ''));
      row.type = 'button';
      const av = el('span', CSS_CLS + '__thumb');
      const url = itemIcon(rec);
      if (url) { const img = el('img'); img.src = url; img.alt = ''; img.loading = 'lazy'; av.appendChild(img); }
      row.appendChild(av);
      const meta = el('span', CSS_CLS + '__meta');
      meta.appendChild(el('b', null, txt(rec, id)));
      const desc = String(rec.descRaw || rec.desc || '').replace(/<[^>]*>/g, '');
      meta.appendChild(el('small', null, desc));
      row.appendChild(meta);
      row.appendChild(el('span', CSS_CLS + '__tick', on ? '✓' : ''));
      row.addEventListener('click', () => {
        const i = state.cfg.items.indexOf(id);
        if (i >= 0) state.cfg.items.splice(i, 1);
        else if (state.cfg.items.length < 24) state.cfg.items.push(id);
        saveCfg();
        renderList();
        updateFooter();
      });
      box.appendChild(row);
    }
    if (!rows.length) box.appendChild(el('p', CSS_CLS + '__empty', '没有匹配的项'));
  }

  function renderBonds(box) {
    const rows = bondList().filter((r) => hit(r.name, r.bondId, r.desc));
    for (const rec of rows) {
      const id = rec.bondId;
      const n = state.cfg.bonds[id] || 0;
      const row = el('div', CSS_CLS + '__bond' + (n > 0 ? ' is-on' : ''));
      const icon = el('span', CSS_CLS + '__thumb __thumb--bond');
      const url = bondIcon(id);
      if (url) { const img = el('img'); img.src = url; img.alt = ''; icon.appendChild(img); }
      else icon.appendChild(el('span', CSS_CLS + '__glyph', (txt(rec, id) || '?').slice(0, 1)));
      row.appendChild(icon);
      const meta = el('span', CSS_CLASS_META());
      meta.appendChild(el('b', null, txt(rec, id)));
      meta.appendChild(el('small', null, (rec.isCore ? '核心盟约' : '附加盟约') + ' · ' + id));
      row.appendChild(meta);
      const step = el('span', CSS_CLS + '__step');
      const bump = (d) => { const v = Math.max(0, Math.min(999, (state.cfg.bonds[id] || 0) + d)); if (v) state.cfg.bonds[id] = v; else delete state.cfg.bonds[id]; saveCfg(); renderList(); updateFooter(); };
      for (const [label, d] of [['−10', -10], ['−', -1], ['+', 1], ['+10', 10]]) {
        const b = el('button', CSS_CLS + '__stepbtn', label);
        b.type = 'button';
        b.addEventListener('click', () => bump(d));
        step.appendChild(b);
      }
      const num = el('input', CSS_CLS + '__stepnum');
      num.type = 'number';
      num.min = '0'; num.max = '999'; num.value = String(n);
      num.addEventListener('input', () => {
        const v = Math.max(0, Math.min(999, Number.parseInt(num.value, 10) || 0));
        if (v) state.cfg.bonds[id] = v; else delete state.cfg.bonds[id];
        saveCfg(); updateFooter();
      });
      step.appendChild(num);
      row.appendChild(step);
      box.appendChild(row);
    }
    if (!rows.length) box.appendChild(el('p', CSS_CLS + '__empty', '没有匹配的项'));
  }

  const CSS_CLASS_META = () => CSS_CLS + '__meta';

  function renderStages(box) {
    const pub = state.pub;
    const wrap = el('div', CSS_CLS + '__stages');
    const none = el('button', CSS_CLS + '__stage' + (state.cfg.stage === '' ? ' is-on' : ''));
    none.type = 'button';
    none.appendChild(el('b', null, '随机（按模式抽取）'));
    none.appendChild(el('small', null, 'AUTO'));
    none.addEventListener('click', () => { state.cfg.stage = ''; saveCfg(); renderList(); updateFooter(); });
    wrap.appendChild(none);
    for (const rec of stageList()) {
      const id = rec.id;
      const on = state.cfg.stage === id;
      const b = el('button', CSS_CLS + '__stage' + (on ? ' is-on' : ''));
      b.type = 'button';
      b.appendChild(el('b', null, txt(rec, id)));
      b.appendChild(el('small', null, id + (rec.active === false ? ' · 隐藏' : '')));
      if (pub && pub.stageId === id) b.appendChild(el('i', CSS_CLS + '__now', '当前'));
      b.addEventListener('click', () => { state.cfg.stage = on ? '' : id; saveCfg(); renderList(); updateFooter(); });
      wrap.appendChild(b);
    }
    box.appendChild(wrap);
    // 开局资金
    const funds = el('label', CSS_CLS + '__field');
    funds.appendChild(el('span', null, '开局资金（留空 = 按收入发）'));
    const inp = el('input');
    inp.type = 'number'; inp.min = '0'; inp.max = '99999';
    inp.value = state.cfg.funds;
    inp.placeholder = '默认';
    inp.addEventListener('input', () => { state.cfg.funds = inp.value.replace(/[^0-9]/g, '').slice(0, 5); saveCfg(); updateFooter(); });
    funds.appendChild(inp);
    box.appendChild(funds);
  }

  function updateFooter() {
    if (!footerNote) return;
    const bonds = Object.keys(state.cfg.bonds).length;
    const layers = Object.values(state.cfg.bonds).reduce((a, b) => a + b, 0);
    footerNote.textContent = '已选：干员 ' + state.cfg.chess.length + ' · 装备 ' + state.cfg.items.length +
      ' · 盟约 ' + bonds + '（' + layers + ' 层）' + (state.cfg.stage ? ' · 地图 ' + state.cfg.stage : '') +
      (state.cfg.funds ? ' · 资金 ' + state.cfg.funds : '');
  }

  function render() {
    clear(overlay);
    const box = el('div', CSS_CLS + '__box');
    const head = el('header', CSS_CLS + '__head');
    head.appendChild(el('b', null, '测试模拟 · 训练房'));
    head.appendChild(el('small', null, inMatch() ? '局内调整（改动立刻生效）' : '开局前配置（开始模拟后自动应用）'));
    const close = el('button', CSS_CLS + '__close', '×');
    close.type = 'button';
    close.addEventListener('click', closeOverlay);
    head.appendChild(close);
    box.appendChild(head);

    const room = roomOf();
    if (!isHost()) {
      box.appendChild(el('p', CSS_CLS + '__warn', '只有房主可以配置训练房。'));
    }
    box.appendChild(tabBar([
      { id: 'ops', label: '干员' }, { id: 'items', label: '装备' }, { id: 'bonds', label: '盟约' }, { id: 'stage', label: '地图 / 资金' },
    ]));
    if (state.tab === 'ops') {
      const { row } = searchRow('搜索干员（名称 / 职业 / id）', '已选 ' + state.cfg.chess.length + ' / 24');
      box.appendChild(row);
    } else if (state.tab === 'items') {
      const { row } = searchRow('搜索装备（名称 / 效果 / id）', '已选 ' + state.cfg.items.length + ' / 24');
      box.appendChild(row);
    } else if (state.tab === 'bonds') {
      const { row } = searchRow('搜索盟约（名称 / id）', '已选 ' + Object.keys(state.cfg.bonds).length + ' 项');
      box.appendChild(row);
    }
    listBox = el('div', CSS_CLS + '__list' + (state.tab === 'stage' ? ' ' + CSS_CLS + '__list--stages' : ''));
    box.appendChild(listBox);
    renderList();

    const foot = el('footer', CSS_CLS + '__foot');
    footerNote = el('span', CSS_CLS + '__note');
    foot.appendChild(footerNote);
    updateFooter();
    const apply = el('button', CSS_CLS + '__apply', inMatch() ? '应用到本局' : '应用');
    apply.type = 'button';
    apply.addEventListener('click', () => {
      if (!isHost()) return;
      const cfg = {
        stage: state.cfg.stage || undefined,
        preset: {
          ...(state.cfg.chess.length ? { chess: state.cfg.chess.slice() } : {}),
          ...(state.cfg.items.length ? { items: state.cfg.items.slice() } : {}),
          ...(Object.keys(state.cfg.bonds).length ? { bonds: Object.entries(state.cfg.bonds).map(([id, layers]) => ({ id, layers })) } : {}),
          ...(state.cfg.funds ? { funds: Number(state.cfg.funds) } : {}),
        },
      };
      if (inMatch()) {
        ctx.net.send('train', { kind: 'live', stage: cfg.stage, preset: cfg.preset });
        apply.textContent = '已发送 ✓';
        setTimeout(() => { apply.textContent = '应用到本局'; }, 1200);
      } else {
        pendingSetup = cfg;
        state.sent = false;
        try { sessionStorage.setItem('test-sim.pending', JSON.stringify(cfg)); } catch { /* 忽略 */ }
        apply.textContent = '已应用 · 开始模拟后生效 ✓';
        setTimeout(() => { apply.textContent = '应用'; }, 1600);
      }
    });
    foot.appendChild(apply);
    box.appendChild(foot);

    overlay.appendChild(box);
  }

  // ---- 与对局的联动 -----------------------------------------------------------
  let pendingSetup = null;
  try { pendingSetup = JSON.parse(sessionStorage.getItem('test-sim.pending') || 'null'); } catch { pendingSetup = null; }

  const offState = net.on('room.state', (msg) => {
    state.room = msg || null;
    if (msg && msg.inMatch === false) { state.sent = false; state.pub = null; }
    refreshHandle();
    if (state.open) updateFooter();
    // 恢复会话时 m.public 可能比 room.state 早到：房间状态里看到「对局中」再补一次
    if (msg && msg.inMatch === true && !state.sent && pendingSetup) {
      state.sent = true;
    }
  });
  const offPub = net.on('m.public', (msg) => {
    state.pub = msg || null;
    refreshHandle();
    // 训练房的配置在对局开始后送达（此刻房间里已经有 Match 了）。房主判定由服务端做（只认 hostId），
    // 客户端这里乐观发送即可 —— 非房主发的消息会被服务端原样拒掉。
    if (msg && !state.sent && pendingSetup) {
      state.sent = true;
    }
    if (state.open) updateFooter();
  });

  function refreshHandle() {
    const show = inMatch() || (inRoom() && isHost());
    handle.style.display = show ? '' : 'none';
    handle.textContent = inMatch() ? '训练房（局内）' : '测试模拟';
  }

  refreshHandle();

  return {
    unmount() {
      offState();
      offPub();
      handle.remove();
      overlay.remove();
    },
  };
}

export default mount;
