export {};
// trusted 桥接要求 activate(api)（server/plugins/trustedEntry.js）：本插件没有服务端逻辑，故为空实现。
export async function activate() {}
