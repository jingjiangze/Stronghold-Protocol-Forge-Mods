# 玩家间交易（前向兼容参考包）

来源：`原版增强安装.zip` 里 `files/` 分支的 `server/match/player/trade.js` 及相关改动。
本包**当前不能在 mod 管理器引擎上生效**，原因（审计结论，2026-10-20）：

1. `shared/protocol.js` 的 C2S 表是字面量白名单（`net.js` 拒绝未知类型），没有 `g.trade` / `g.tradeAnswer` / `g.tradeCancel` 三键。
2. `server/match/PlayerState` 用硬编码 mixin 列表挂在身上，无「插件注入 PlayerState 方法」的挂点（`code.match` 只能整类替换 `Match`，不能加一个 `PlayerTrade`）。
3. 客户端 `public/js/screens/game.js` 把 `TradePanel` 硬编码 import，mod 管理器只支持 `code.client` 整文件覆盖 / iframe 帧，无法内嵌到 `game.js` 的组件图。

## 引擎补面清单（补完即生效）

| 改动 | 位置（包内分支行号） |
|---|---|
| 在 C2S 表新增 `g.trade`/`g.tradeAnswer`/`g.tradeCancel` | `shared/protocol.js:584-586` |
| `PlayerState` 挂 `PlayerTrade` mixin | `server/match/PlayerState.js:265` |
| `intents._handle` 注册 `case 'g.trade*'` | `server/match/match/intents.js:41-43` |
| `round.js` 回合清 offer | `server/match/player/round.js:48` |
| `views.js` 注入 `tradeView()` | `server/match/player/views.js:119` |
| `Match.tradeSeq` | `server/match/Match.js:460` |
| 客户端 `TradePanel` 挂点 | `public/js/screens/game.js:1721-1730`、`public/js/ui/shopBar.js:305,351-383` |
| ERR 码 + i18n | `shared/constants.js:185-221` |

## 目录

- `src/`：包内实现片段（原样提取，未改动），引擎补面时按上表并入对应文件。
- `plugin.json`：manifest 2，仅声明存在；`data:[]` 因为交易是行为而非数据。
