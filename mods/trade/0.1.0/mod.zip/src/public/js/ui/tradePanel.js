// Prep trade between players. Same tier, one completed exchange per round, two per match.
// The other player accepts from their own panel. Equipment stays with the original owner.

import { useEffect, useState } from '../../vendor/hooks.module.js';
import { html, Modal, Button } from './components.js';
import { bondIconUrl, chessAvatarUrl, chessPortraitUrl } from './assetUrls.js';
import { data, useData } from '../data.js';
import { actions } from './gameActions.js';
import { t } from '../../../shared/i18n.js';

const cx = (...p) => p.flat().filter(Boolean).join(' ');

function chessName(id, golden) {
  const rec = data.lookup('chess', id);
  const name = rec && rec.name ? rec.name : id;
  return golden ? t('{name}（精锐）', { name }) : name;
}

function ownChess(priv) {
  const out = [];
  const push = (p, area) => {
    if (!p || p.kind !== 'chess') return;
    const rec = data.lookup('chess', p.id);
    if (rec && rec.isDiy) return;
    out.push({ uid: p.uid, id: p.id, tier: p.tier, golden: !!p.golden, area });
  };
  (priv?.hand || []).forEach((p) => push(p, 'hand'));
  (priv?.board || []).forEach((p) => push(p, 'board'));
  (priv?.temp || []).forEach((p) => push(p, 'temp'));
  return out;
}

const AREA = { hand: '整备区', board: '战场', temp: '临时整备区' };

/** Eager image: the trade modal sits off the lazy-load path, so a deferred img never arrives. */
function Eager({ src, alt, glyph }) {
  const [bad, setBad] = useState(null);
  if (!src || bad === src) return html`<span class="trade__glyph">${glyph}</span>`;
  return html`<img src=${src} alt=${alt || ''} draggable=${false} onError=${() => setBad(src)} />`;
}

/** Avatar plus the operator's bonds, in one frame. */
function Face({ id, golden, name, area }) {
  const rec = id ? data.lookup('chess', id) : null;
  const m = data.get('assets');
  const elite = !!(golden || rec?.isGolden);
  const drawn = rec ? { ...rec, isGolden: elite } : null;
  const src = chessAvatarUrl(m, drawn) || chessPortraitUrl(m, drawn);
  const label = name || (id ? chessName(id, elite) : '');
  const glyph = [...(label || '?')][0] || '?';
  const bonds = Array.isArray(rec?.bonds) ? rec.bonds.filter((b) => typeof b === 'string') : [];
  return html`<span class="trade__face">
    <span class="trade__ava"><${Eager} src=${src} alt=${label} glyph=${glyph} /></span>
    <span class="trade__meta">
      <b class="trade__name">${label || t('选择干员')}</b>
      ${area ? html`<span class="trade__area">${t(AREA[area] || '')}</span>` : null}
      <span class="trade__bonds">
        ${bonds.map((b) => {
          const bn = data.lookup('bonds', b)?.name || b;
          const icon = bondIconUrl(m, b);
          return html`<span key=${b} class="trade__bond" title=${bn}>
            <span class="bglyph">${icon ? html`<img src=${icon} alt="" draggable=${false} />` : html`<span class="bglyph__txt">${[...bn][0] || ''}</span>`}</span>
            <span>${bn}</span>
          </span>`;
        })}
      </span>
    </span>
  </span>`;
}

function Pair({ left, right, leftLabel, rightLabel }) {
  return html`<div class="trade__match">
    <div class="trade__side">
      <span class="trade__side-label">${leftLabel}</span>
      <${Face} id=${left?.id} golden=${!!left?.golden} name=${left?.name || (left ? chessName(left.id, left.golden) : '')} area=${left?.area} />
    </div>
    <span class="trade__swap">↔</span>
    <div class="trade__side">
      <span class="trade__side-label">${rightLabel}</span>
      <${Face} id=${right?.id} golden=${!!right?.golden} name=${right?.name || (right ? chessName(right.id, right.golden) : t('对方干员'))} />
    </div>
  </div>`;
}

function Pick({ piece, on, onPick }) {
  return html`<button type="button" class=${cx('trade__pick', on && 'is-on')} onClick=${onPick}>
    <${Face} id=${piece.id} golden=${piece.golden} area=${piece.area} />
  </button>`;
}

/**
 * @param {{ open: boolean, priv: any, editable: boolean, onClose: () => void }} props
 */
export function TradePanel({ open, priv, editable, onClose }) {
  useData('assets', 'chess', 'bonds');
  const trade = priv?.trade;
  const [mine, setMine] = useState(null);
  const [partner, setPartner] = useState(null);
  const [theirs, setTheirs] = useState(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (!open) { setMine(null); setPartner(null); setTheirs(null); } }, [open]);

  if (!trade) return null;
  const own = ownChess(priv);
  const minePiece = own.find((p) => p.uid === mine) || null;
  const players = Array.isArray(trade.players) ? trade.players : [];
  const incoming = Array.isArray(trade.incoming) ? trade.incoming : [];
  const outgoing = trade.outgoing || null;
  const onceEach = !!trade.onceEach;
  const roundLeft = Math.max(0, (trade.roundMax ?? 1) - (trade.roundUsed ?? 0));
  const matchLeft = onceEach ? null : Math.max(0, (trade.matchMax ?? 2) - (trade.matchUsed ?? 0));
  const blocked = !editable || roundLeft < 1 || (matchLeft != null && matchLeft < 1);

  const run = async (fn) => {
    if (busy) return;
    setBusy(true);
    try { await fn(); } finally { setBusy(false); }
  };

  const theirList = players.map((pl) => {
    const theirMatchCap = pl.matchMax == null ? null : pl.matchMax;
    const full = (pl.roundUsed ?? 0) >= (trade.roundMax ?? 1)
      || (theirMatchCap != null && (pl.matchUsed ?? 0) >= theirMatchCap);
    const chess = (pl.chess || []).filter((c) => minePiece && c.tier === minePiece.tier);
    return { ...pl, full, chess };
  });
  const chosen = theirList.find((pl) => pl.playerId === partner) || null;
  const theirPiece = (chosen?.chess || []).find((c) => c.uid === theirs) || null;
  const quotaFree = !!(chosen && chosen.onceEach && !onceEach);

  return html`<${Modal} open=${open} class="trade" title=${t('交换干员')} micro="TRADE" width="min(11rem, 96vw)" onClose=${onClose}
    actions=${html`<${Button} variant="secondary" onClick=${onClose}>${t('关闭')}<//>`}>
    <p class="trade__quota">${onceEach
      ? t('同阶才能交换。本回合还可交换 {round} 次，不受每局次数限制，同一名玩家下一回合还能再换。装备和召唤物留在原主人处。', { round: roundLeft })
      : t('同阶才能交换。本回合还可交换 {round} 次，本局还可交换 {match} 次。装备和召唤物留在原主人处。', { round: roundLeft, match: matchLeft })}</p>
    ${incoming.map((offer) => html`<div key=${offer.id} class="trade__offer">
      <p>${t('{name}想用{mine}交换你的{theirs}', { name: offer.fromName, mine: offer.mine?.name || '', theirs: offer.theirs?.name || '' })}</p>
      <${Pair} left=${offer.mine} right=${offer.theirs} leftLabel=${offer.fromName} rightLabel=${t('你的干员')} />
      <div class="trade__acts">
        <${Button} variant="primary" disabled=${(offer.free ? !editable : blocked) || busy} onClick=${() => run(() => actions.tradeAnswer(offer.id, true))}>${t('同意')}<//>
        <${Button} variant="secondary" disabled=${busy} onClick=${() => run(() => actions.tradeAnswer(offer.id, false))}>${t('拒绝')}<//>
      </div>
      ${offer.free ? html`<p class="trade__hint">${t('这次交换不占用你的次数')}</p>` : null}
      ${(offer.free ? !editable : blocked) ? html`<p class="trade__hint">${!editable ? t('取消准备后才能同意') : t('你本回合或本局的交换次数已用完')}</p>` : null}
    </div>`)}
    ${outgoing ? html`<div class="trade__offer">
      <p>${t('等待{name}确认：你的{mine} ↔ 对方的{theirs}', { name: outgoing.toName, mine: outgoing.mine?.name || '', theirs: outgoing.theirs?.name || '' })}</p>
      <${Pair} left=${outgoing.mine} right=${outgoing.theirs} leftLabel=${t('我的干员')} rightLabel=${outgoing.toName} />
      <${Button} variant="secondary" disabled=${busy || !editable} onClick=${() => run(() => actions.tradeCancel())}>${t('取消交换')}<//>
    </div>` : null}
    ${outgoing ? null : html`<div class="trade__cols">
      <div class="trade__col">
        <h3>${t('我的干员')}</h3>
        <div class="trade__list">
          ${own.map((p) => html`<${Pick} key=${p.uid} piece=${p} on=${mine === p.uid} onPick=${() => { setMine(p.uid); setTheirs(null); }} />`)}
        </div>
      </div>
      <div class="trade__col">
        <h3>${t('选择玩家')}</h3>
        <div class="trade__players">
          ${theirList.map((pl) => html`<button type="button" key=${pl.playerId} class=${cx('trade__player', partner === pl.playerId && 'is-on')}
            disabled=${!minePiece}
            onClick=${() => { setPartner(pl.playerId); setTheirs(null); }}>
            <b>${pl.name}</b>
            ${pl.ready ? html`<span class="trade__hint">${t('已准备')}</span>` : null}
            ${pl.onceEach && !onceEach ? html`<span class="trade__hint">${t('不占你的次数')}</span>` : null}
            ${pl.full ? html`<span class="trade__hint">${t('次数已用完')}</span>` : null}
          </button>`)}
        </div>
        <h3>${!minePiece ? t('先选择自己的干员') : !chosen ? t('再选择要交换的玩家') : t('{name}的{tier}阶干员', { name: chosen.name, tier: minePiece.tier })}</h3>
        <div class="trade__list">
          ${(chosen?.chess || []).map((c) => html`<${Pick} key=${c.uid} piece=${c} on=${theirs === c.uid} onPick=${() => setTheirs(c.uid)} />`)}
          ${chosen && !chosen.chess.length ? html`<p class="trade__hint">${t('没有同阶干员')}</p>` : null}
        </div>
      </div>
    </div>
    ${minePiece ? html`<${Pair} left=${minePiece} right=${theirPiece} leftLabel=${t('我的干员')} rightLabel=${chosen ? chosen.name : t('对方干员')} />` : null}
    <div class="trade__acts">
      <${Button} variant="primary" disabled=${(quotaFree ? !editable : blocked) || busy || !mine || !chosen || !theirs || chosen.ready || chosen.full}
        onClick=${() => { if (!chosen) return; run(() => actions.trade(mine, chosen.playerId, theirs)); }}>${t('提出交换')}<//>
    </div>`}
  <//>`;
}

/** Shop-bar button. Hidden when there is nobody to trade with and nothing pending. */
export function tradeAvailable(priv) {
  const trade = priv?.trade;
  if (!trade) return false;
  const players = Array.isArray(trade.players) ? trade.players.length : 0;
  const incoming = Array.isArray(trade.incoming) ? trade.incoming.length : 0;
  return players > 0 || incoming > 0 || !!trade.outgoing;
}
