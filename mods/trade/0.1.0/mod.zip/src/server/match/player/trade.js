// server/match/player/trade.js — PlayerState methods: swap one operator with another player during prep.
// Same tier only. Each player may complete one exchange per round and two per match. The other player must accept.
// Equipped items and summons stay with the original owner. 自选 pieces are refused (their copies belong to one stock).

import { ERR, PHASE } from '../../../shared/constants.js';
import { msg } from '../../../shared/i18n.js';
import { OK, fail } from './common.js';

const ROUND_MAX = 1;
const MATCH_MAX = 2;

function tradeable(gd, piece) {
  if (!piece || piece.kind !== 'chess') return false;
  const rec = gd.chess(piece.id);
  return !!(rec && !rec.isDiy && Number.isInteger(rec.tier));
}

function roundUsed(ps, round) {
  return ps.tradeRound === round ? ps.tradeRoundCount : 0;
}

export class PlayerTrade {
  proposeTrade(myUid, targetPlayerId, theirUid) {
    const g = this._gate(); if (g) return g;
    const other = this.m.players.get(targetPlayerId);
    if (!other || other === this || other.isBot || !other.alive) return fail(ERR.BAD_TARGET);
    const blocked = this._tradeBlocked(this, other.playerId);
    if (blocked) return blocked;
    if (other.ready) return fail(ERR.TRADE_READY);
    const otherBlocked = this._tradeBlocked(other, this.playerId);
    if (otherBlocked) return otherBlocked;
    const mine = this.find(myUid);
    const theirs = other.find(theirUid);
    if (!mine || !tradeable(this.gd, mine.piece)) return fail(ERR.BAD_TARGET);
    if (!theirs || !tradeable(other.gd, theirs.piece)) return fail(ERR.BAD_TARGET);
    const myRec = this.gd.chess(mine.piece.id);
    const theirRec = other.gd.chess(theirs.piece.id);
    if (myRec.tier !== theirRec.tier) return fail(ERR.TRADE_TIER);
    if (this.tradeOffer) this._voidTradeOffer({ toast: true });
    this.tradeOffer = {
      id: ++this.m.tradeSeq,
      round: this.m.round,
      fromId: this.playerId,
      toId: other.playerId,
      myUid, theirUid,
      myId: mine.piece.id,
      theirId: theirs.piece.id,
      myName: myRec.name,
      theirName: theirRec.name,
      tier: myRec.tier,
    };
    this.dirty();
    other.dirty();
    this.m.toast(this, 'info', msg('已向{name}提出交换', { name: other.name }));
    this.m.toast(other, 'info', msg('{name}想用{mine}交换你的{theirs}', { name: this.name, mine: myRec.name, theirs: theirRec.name }));
    return OK;
  }

  cancelTrade() {
    const g = this._gate(); if (g) return g;
    if (!this.tradeOffer) return fail(ERR.BAD_TARGET);
    this._voidTradeOffer({ toast: true });
    this.dirty();
    return OK;
  }

  answerTrade(offerId, accept) {
    const g = this._gate(); if (g) return g;
    const from = [...this.m.players.values()].find((p) => p.tradeOffer && p.tradeOffer.id === offerId && p.tradeOffer.toId === this.playerId);
    if (!from || from.tradeOffer.round !== this.m.round) return fail(ERR.BAD_TARGET);
    const offer = from.tradeOffer;
    if (!accept) {
      from.tradeOffer = null;
      from.dirty();
      this.dirty();
      this.m.toast(from, 'info', msg('{name}拒绝了交换', { name: this.name }));
      return OK;
    }
    if (from.ready) return fail(ERR.TRADE_READY);
    const mineBlocked = this._tradeBlocked(this, from.playerId);
    if (mineBlocked) return mineBlocked;
    const fromBlocked = this._tradeBlocked(from, this.playerId);
    if (fromBlocked) return fromBlocked;
    const mine = this.find(offer.theirUid);
    const theirs = from.find(offer.myUid);
    if (!mine || !tradeable(this.gd, mine.piece) || mine.piece.id !== offer.theirId) return fail(ERR.BAD_TARGET);
    if (!theirs || !tradeable(from.gd, theirs.piece) || theirs.piece.id !== offer.myId) return fail(ERR.BAD_TARGET);
    const myRec = this.gd.chess(mine.piece.id);
    const theirRec = from.gd.chess(theirs.piece.id);
    if (!myRec || !theirRec || myRec.tier !== theirRec.tier) return fail(ERR.TRADE_TIER);
    const toMe = this._takeTradePiece(from, theirs);
    const toThem = this._takeTradePiece(this, mine);
    from.tradeOffer = null;
    if (this.tradeOffer) this._voidTradeOffer({ toast: true });
    this._receiveTradePiece(toMe);
    from._receiveTradePiece(toThem);
    this._spendTrade(from.playerId);
    from._spendTrade(this.playerId);
    this.recompute();
    from.recompute();
    this.m.toast(this, 'info', msg('已换得{name}', { name: theirRec.name }));
    this.m.toast(from, 'info', msg('已换得{name}', { name: myRec.name }));
    return OK;
  }

  /** Drop a stale outgoing offer after a piece is sold, merged or otherwise gone. */
  _syncTradeOffer() {
    const offer = this.tradeOffer;
    if (!offer) return;
    if (offer.round !== this.m.round || this.m.phase !== PHASE.PREP) {
      this._voidTradeOffer({ toast: false });
      return;
    }
    const other = this.m.players.get(offer.toId);
    const mine = this.find(offer.myUid);
    const theirs = other && other.find(offer.theirUid);
    const mineOk = mine && tradeable(this.gd, mine.piece) && mine.piece.id === offer.myId;
    const theirOk = theirs && tradeable(other.gd, theirs.piece) && theirs.piece.id === offer.theirId;
    if (!mineOk || !theirOk) this._voidTradeOffer({ toast: true });
  }

  /** An incoming offer dies when the piece it names is gone. */
  _syncIncomingTrades() {
    if (!this.m || !this.m.players) return;
    for (const ps of this.m.players.values()) {
      const offer = ps.tradeOffer;
      if (!offer || ps === this || offer.toId !== this.playerId) continue;
      ps._syncTradeOffer();
    }
  }

  /** Refresh teammates' trade lists when this player's operators change. */
  noteTradeCatalog() {
    if (!this.m || this.m.phase !== PHASE.PREP || !this.m.players) return;
    const sig = this.allChess().map((p) => `${p.uid}:${p.id}`).join(',');
    if (sig === this._tradeSig) return;
    this._tradeSig = sig;
    for (const o of this.m.players.values()) if (o !== this && o.alive && !o.isBot) o.dirty();
  }

  tradeView() {
    const round = this.m.round;
    const onceEach = this.gd.bandHas(this.bandId, 'trade_once_each');
    const view = {
      roundUsed: roundUsed(this, round),
      matchUsed: this.tradeMatchCount | 0,
      roundMax: ROUND_MAX,
      matchMax: onceEach ? null : MATCH_MAX,
      onceEach,
      outgoing: null,
      incoming: [],
      players: [],
    };
    if (this.m.phase !== PHASE.PREP) return view;
    if (this.tradeOffer && this.tradeOffer.round === round) view.outgoing = offerView(this.m, this.tradeOffer);
    for (const ps of this.m.players.values()) {
      if (ps !== this && ps.tradeOffer && ps.tradeOffer.toId === this.playerId && ps.tradeOffer.round === round) {
        view.incoming.push(offerView(this.m, ps.tradeOffer));
      }
      if (ps === this || !ps.alive || ps.isBot) continue;
      const chess = [];
      for (const p of ps.allChess()) {
        if (!tradeable(ps.gd, p)) continue;
        const rec = ps.gd.chess(p.id);
        chess.push({ uid: p.uid, id: p.id, tier: rec.tier, name: rec.name, golden: !!rec.isGolden });
      }
      const partnerOnce = this.gd.bandHas(ps.bandId, 'trade_once_each');
      view.players.push({
        playerId: ps.playerId, name: ps.name, ready: !!ps.ready, chess,
        roundUsed: roundUsed(ps, round), matchUsed: ps.tradeMatchCount | 0,
        onceEach: partnerOnce, matchMax: partnerOnce ? null : MATCH_MAX,
        traded: !!((this.tradePartners || {})[ps.playerId]) || !!((ps.tradePartners || {})[this.playerId]),
      });
    }
    return view;
  }

  _tradeBlocked(ps, otherId) {
    const other = otherId ? this.m.players.get(otherId) : null;
    const otherOnce = !!(other && this.gd.bandHas(other.bandId, 'trade_once_each'));
    if (this.gd.bandHas(ps.bandId, 'trade_once_each')) {
      if (roundUsed(ps, this.m.round) >= ROUND_MAX) return fail(ERR.TRADE_ROUND);
      return null;
    }
    // Trading with 博士，打灰么？ does not use this player's round or match quota.
    if (otherOnce) return null;
    if ((ps.tradeMatchCount | 0) >= MATCH_MAX) return fail(ERR.TRADE_LIMIT);
    if (roundUsed(ps, this.m.round) >= ROUND_MAX) return fail(ERR.TRADE_ROUND);
    return null;
  }

  _spendTrade(otherId) {
    const other = otherId ? this.m.players.get(otherId) : null;
    const mineOnce = this.gd.bandHas(this.bandId, 'trade_once_each');
    const otherOnce = !!(other && this.gd.bandHas(other.bandId, 'trade_once_each'));
    if (mineOnce || !otherOnce) {
      if (this.tradeRound !== this.m.round) {
        this.tradeRound = this.m.round;
        this.tradeRoundCount = 0;
      }
      this.tradeRoundCount += 1;
      this.tradeMatchCount += 1;
    }
    if (otherId) {
      if (!this.tradePartners) this.tradePartners = {};
      this.tradePartners[otherId] = (this.tradePartners[otherId] || 0) + 1;
    }
    this.tradeOffer = null;
  }

  _voidTradeOffer({ toast = false } = {}) {
    const offer = this.tradeOffer;
    if (!offer) return;
    this.tradeOffer = null;
    const other = this.m.players.get(offer.toId);
    if (other) other.dirty();
    if (!toast) return;
    this.m.toast(this, 'info', msg('交换已取消'));
    if (other) this.m.toast(other, 'info', msg('{name}取消了交换', { name: this.name }));
  }

  /**
   * The received operator is a gain for merging: three normal copies become the elite, the same way a shop buy does.
   * A set that is still short is stowed (hand, then temp).
   */
  _receiveTradePiece(piece) {
    const rec = this.gd.chess(piece && piece.id);
    if (rec && !rec.isGolden && this.completesChessMerge(piece.id)) {
      const elite = this._mergeChess(this.gd.baseIdOf(piece.id), piece);
      if (elite) return elite;
    }
    this.stow(piece, { allowTemp: true });
    return piece;
  }

  _takeTradePiece(ps, loc) {
    const piece = loc.piece;
    ps.removeTokensOf(piece.uid);
    for (const it of [...(piece.items || [])]) {
      ps._detach({ piece: it, area: 'equipped', holder: piece });
      ps.stow(it, { allowTemp: true });
    }
    piece.items = [];
    ps._detach(loc);
    return piece;
  }
}

function offerView(m, offer) {
  const from = m.players.get(offer.fromId);
  const to = m.players.get(offer.toId);
  return {
    id: offer.id,
    fromId: offer.fromId,
    fromName: from ? from.name : '',
    toId: offer.toId,
    toName: to ? to.name : '',
    tier: offer.tier,
    mine: { uid: offer.myUid, id: offer.myId, name: offer.myName },
    theirs: { uid: offer.theirUid, id: offer.theirId, name: offer.theirName },
    free: !!(from && m.gd.bandHas(from.bandId, 'trade_once_each') && !(to && m.gd.bandHas(to.bandId, 'trade_once_each'))),
  };
}
