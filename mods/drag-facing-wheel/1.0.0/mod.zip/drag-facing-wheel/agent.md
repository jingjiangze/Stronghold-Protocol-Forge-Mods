# 干员自由拖放、平滑放置和朝向轮盘：给接手大模型

整理日期：2026-10-15。用户要求的是自己服务器上已上线的实现。本包直接抓取 https://sp.isomer319.xyz/_v024/ 的当前公开模块，不使用旧候选覆盖现网；来源、下载时间、Last-Modified、大小和SHA256见 server-source-manifest.json。

## 目标和当前交付

复用现网“拖动时不吸附格心、模型平滑跟随、松手平滑落位、摇杆轮盘选朝向”的代码。视觉坐标保持浮点，但最终放置仍是合法整数格子；不能把它改成服务端自由坐标放置。

1. server-original/：从当前服务器取得的34个原文件，保持字节内容与线上一致。它是实现参考及审查基线，不是完整游戏发行包，不能整目录覆盖另一版本。
2. portable/：可在独立HTTP目录运行的兼容模块，保留原拖拽状态机、轮盘组件、方向/范围/意图计算。路径改成相对导入，附带最小UI依赖和兼容适配器；具体变化见compatibility-changes.json。
3. integration-fragments/：从服务器app.js和screens/game.js原样截取的接入片段。这些依赖原闭包变量，不能当作独立ES模块运行。
4. demo/：使用真实拖拽状态机和轮盘的本地示例。Canvas圆点仅替代人物模型，演示提交回执、取消、镜像和拒绝回滚；不连接真实服务。
5. tests/：9项Node测试及6条真实浏览器流程验证结果。没有修改或发布线上代码，没有重启任何服务。

入口：双击“启动本地演示.bat”，需要本机Python。它只在127.0.0.1随机端口服务本目录，按Ctrl+C退出。不要直接用file://打开ES模块。Node测试：在本包根目录执行 `node --test tests/placement.test.mjs`。

## 首先读这些文件

| 需求 | 服务器上的核心位置 |
| --- | --- |
| 鼠标/触屏拖拽状态机 | js/render14-r3/drag.js 的 createDragController |
| 不吸附、鼠标/触屏偏移、目标格高亮 | js/render14-r3/app.js 的 startDragVisual、moveDragVisual |
| 连续跟随和平滑落位 | app.js 的帧循环、dropDragVisual、endDragVisual |
| 圆形摇杆和取消/确认 | js/ui/facingWheel.js 的 FacingWheel |
| 死区、旋转范围、镜像、网络意图 | js/ui/facing.js |
| 键盘拦截及Enter焦点兼容 | js/ui/gameLogic/shortcuts.js |
| 合法落点判定 | js/ui/gameLogic/placement.js，不要用渲染层替代它 |
| 暂存模型、提交、拒绝恢复 | js/screens/game.js 的 openFacing、commitFacing、cancelFacing、heldRef |
| 渲染器可选能力桥接 | js/ui/fieldHost.js 的 OPTIONAL |
| 圆形轮盘样式 | css/screens/game-panels.css 中fwheel基础规则＋joystick-20261012规则，两段都需要 |

实际渲染入口是 render14-r3/app.js。工作区可能还有 render/app.js，不能只改旧副本。drag.js的dragStandTile函数仍可返回格子，但当前服务器app.js主动使用 `const stand = null` 绕过吸附分支。因此只复制drag.js无法得到“不吸附”的效果。

## 放置流程：需要一起迁移

按下命中棋子 → 超过鼠标/触屏拖动阈值 → 自由跟随、只高亮当前目标格 → 松手重新校验落点。

- 落到棋盘且该对象需要方向：暂存模型在目标格，打开FacingWheel，尚不提交移动。
- 落到整备区：走原有整备区移动；装备/画卷仍用原有各自协议和校验。
- 在轮盘选择方向：只预览人物/范围；确认后提交一次请求。
- 取消、PointerCancel、失去编辑权限、对象被卖出/合成、服务端拒绝：清掉预览和跟随目标，恢复权威位置/朝向。
- 请求成功：保持目标格模型，等m.private状态到达再释放临时保持，避免被旧快照拉回。现网界面另设1500ms兜底释放；渲染器pending超时常量是1300ms，二者不是同一机制。

不要省略服务器回执和状态收敛，只在客户端改坐标会造成“看起来放好，下一帧跳回”。原样片段见 integration-fragments/server-facing-handlers.fragment.js 和 server-facing-open-drop.fragment.js。

## 不吸附与平滑的具体参数

- 拖动目标通过camera.unproject取得世界浮点坐标，不能使用round/floor或格子中心作为模型目标。
- 落点判断和格子高亮仍使用指针下方的整数格子。两者分开，手机触控偏移不能改变合法落点。
- 服务器触屏持握偏移0.45格，鼠标0.12格，装备0；拖动抬升0.3。视角、高台与人物hover高度仍进入投影计算。
- 连续跟随系数：`k = 1 - Math.exp(-dt * 22)`；dt是秒，不能传毫秒。它能保持不同刷新率下近似一致的响应。
- 落地/回退时长0.22秒，缓动 `1 - (1-t)^2`。切换到落地缓动时必须清掉_follow，开始新拖动时必须清掉_tween。
- portable/motion.mjs封装了现网公式，使用调用方原有帧循环，不自建另一个requestAnimationFrame。bounds为新增兼容参数，默认保持现网[-1,21]×[-1,19]；其他尺寸棋盘可传自己的界限。

## 轮盘兼容接口

优先让现有渲染view实现：

```js
tileScreen(row,col) // {x,y,s,poly:[[x,y],...],mirror?}，全部是client CSS像素
holdPiece(uid,{row,col}) // 保持选择中的模型；null释放并恢复服务器状态
setPieceDir(uid,'UP'|'RIGHT'|'DOWN'|'LEFT') // 模型朝向预览
highlightTiles(tiles,style) // 范围预览；清理只清对应group
prepField() // 可选，返回 {mirror:true|false}
```

现网组件已经兼容view.raw封装，并在公开方法缺失时尝试debug.cam/tiles/views/app。其他引擎最好实现公开接口，不要依赖私有debug字段。坐标不能重复乘devicePixelRatio，也不能混淆canvas内部像素和clientX/clientY。

轮盘支持鼠标、笔和触屏的Pointer Events；滑回死区取消、右键取消、取消按钮和Esc；方向键预览、Enter确认，并拦截准备/购买等快捷键。按在轮盘外时按“按下点”作为摇杆原点，保持你服务器当前行为。PointerCancel清理指针状态；不要强行把一次取消当成确认。

右半场镜像时屏幕右对应棋盘LEFT。使用boardDir转换一次；调用方不能再翻转一遍，否则朝向又会错。

### 网络格式必须保留

```js
import {facingIntent} from './portable/js/ui/facing.js';
const intent=facingIntent(piece,{row,col},direction);
// 非物品：{t:'g.move',fields:{uid,to:{area:'board',row,col,dir},dir}}
// 画卷：{t:'g.art',fields:{itemUid,row,col,dir}}
```

dir和to.dir同时携带，是为兼容部分服务器只把msg.to转交给PlayerState.move的版本。只传顶层dir可能导致所有干员最终都朝RIGHT。不要删掉兼容字段，也不要把画卷误走g.move。

## 兼容版如何接入

同一项目迁移：以server-original为参考，增量合并app.js中的拖动和帧循环、FacingWheel/样式、game.js中的打开/确认/取消/保持逻辑，保留接收方其他UI、账号、装备与玩法改动。不要直接替换整份game.js/app.js。

独立项目迁移：从portable开始，导入FacingWheel和motion。参考demo/demo.mjs接入自己的合法落点判定、棋子视图、服务端请求和权威状态恢复。该演示的简单棋盘和模拟回执不是生产玩法。

```js
import {FacingWheel} from './portable/js/ui/facingWheel.js';
import {configurePlacementUI} from './portable/js/ui/placementRuntime.js';
import {stepPlacementMotion} from './portable/motion.mjs';
configurePlacementUI({getSettings:()=>yourSettingsStore.get()});
// 在既有帧循环、人物update之前调用：
stepPlacementMotion(unitView,dtSeconds);
// 轮盘由宿主Preact render，传view、row/col、grid及onPreview/onCommit/onCancel。
```

portable带同版本Preact、hooks和htm供独立演示。已有Preact的项目须把这三项导入统一到宿主同一份实例，不要加载两套框架；React/Vue宿主需要重写UI外壳，不能宣称直接兼容。默认取消图标使用文本✕，可通过configurePlacementUI({sprite:YourLocalSprite})恢复宿主图集图标。设置读取通过getSettings接入，默认保留现网快捷键。

CSS只提取轮盘相关规则，把现网以100px为基准的rem换算为px，避免普通16px根字号网站把轮盘文本缩小100/16倍。其余游戏布局样式不进入兼容版。GEO和合法落点逻辑仍按本项目棋盘；其他棋盘需要调整几何和业务判断。

## 验证边界

已跑9项Node测试：同格浮点移动、60/120Hz平滑一致、落地清理、触屏偏移、死区与镜像、双dir协议、范围旋转、合法拖放和非法/取消。

已跑6条真实浏览器流程：鼠标拖放后键盘确认、Esc恢复、镜像鼠标滑动映射、服务端拒绝恢复、中心松手取消、真实触屏拖放和轮盘确认。无JS错误，手机横屏无横向溢出，见tests/browser-results.json和mobile-wheel.png。测试回执为本地模拟，没有请求生产游戏。

这证明当前兼容包的独立流程可运行，不表示已替别人验证所有引擎/上游版本。迁移后还应在接收方测试3D高台、左右Boss半场、整备区/临时区、交换、装备替换、画卷、出售/合成、阶段切换、掉线和慢回执。所有正式提交保留服务端合法性校验，性能降级不应改变玩法。

本文件名是用户要求的agent.md，需明确交给接手模型阅读，不依赖工具自动发现。包内没有root密码、API密钥、Cookie、账号库或CDN后台凭据。
