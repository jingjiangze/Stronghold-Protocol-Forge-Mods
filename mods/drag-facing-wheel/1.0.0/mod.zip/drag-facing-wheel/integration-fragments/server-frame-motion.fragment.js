// Verbatim per-frame motion excerpt; reuse in the existing render loop, not a second ticker.
        if (v._tween) {
          const tw = v._tween;
          tw.t = Math.min(1, tw.t + dt / 0.22);
          const k = 1 - (1 - tw.t) * (1 - tw.t);
          v.x = tw.fx + (tw.tx - tw.fx) * k; v.y = tw.fy + (tw.ty - tw.fy) * k; v.z = tw.fz + (tw.tz - tw.fz) * k;
          if (tw.t >= 1) v._tween = null;
        } else if (v._follow) {
          const f = v._follow, k = 1 - Math.exp(-dt * 22);
          v.x += (f.x - v.x) * k; v.y += (f.y - v.y) * k; v.z += (f.z - v.z) * k;
        }
