// Verbatim excerpt from current server app.js; depends on its closure.
  function startDragVisual(p) {
    const key = 'p:' + p.uid;
    const v = views.get(key);
    if (!v) return;
    dragState = { uid: p.uid, key, view: v, from: p.from, home: v._home || { x: v.x, y: v.y, z: v.z } };
    v.lift = 0.3;
    v._tween = null;
    const t = pieceTile(p.piece);
    if (t) drawHighlight([[t.row, t.col]], 'hover', 'dragFrom');
    v._follow = null; // deploy-feel-20261012: only the landing tile is highlighted while dragging
  }

  function moveDragVisual(p) {
    if (!dragState) return;
    const v = dragState.view;
    const item = v instanceof ItemView;
    // a unit over a legal drop target — the tile under the pointer, on the board or the bench (render/drag.js
    // dragStandTile) — stands on it, lifted, as in the official deploy drag (the owner's recording of 2026-10-09): the
    // world point the drop tween goes to (boardWorld, the prep field transform applied), set at once, no tween
    const stand = null; // deploy feel: follow the pointer smoothly (no tile snapping)
    if (stand) {
      const w = boardWorld(stand.row, stand.col, stand.bench);
      v.x = w.x; v.y = w.y; v.z = w.z;
    } else {
      // otherwise held under the pointer (the player still sees what they carry): a unit with its drawn (lifted) feet
      // DRAG_HOLD_TILES of its own px per tile below it (the scale at the pointer's ground, refined once at the feet), an
      // item plate centred on it
      const g = cam.unproject(p.x, p.y, 0);
      const hold = item ? 0 : (lastPtrType === 'touch' ? DRAG_HOLD_TILES : 0.12);
      const s0 = g ? cam.scaleAt(g.x, g.y, 0) : cam.scale;
      const t = pickTile(cam, p.x, p.y + hold * s0, heightAt, tiles.levels);
      const z = t ? heightAt(t.row, t.col) : 0;
      const up = item ? z : z + (v.lift || 0) + (v.hover || 0);
      let w = cam.unproject(p.x, p.y + hold * s0, up);
      if (w && hold) w = cam.unproject(p.x, p.y + hold * cam.scaleAt(w.x, w.y, up), up) || w;
      if (w) {
        const f = { x: Math.max(-1, Math.min(21, w.x)), y: Math.max(-1, Math.min(19, w.y)), z };
        if (!v._follow) { v.x = f.x; v.y = f.y; v.z = f.z; }
        v._follow = f;
      }
    }
    // the drop target (p.target, highlighted) is the tile under the pointer
    if (p.target && p.target.area !== 'temp') {
      const h = p.target.area === 'hand' ? handTile(p.target.idx) : null;
      const r = h ? h.row : p.target.row;
      const c = h ? h.col : p.target.col;
      drawHighlight([[r, c]], p.legal ? 'target' : 'illegal', 'dragTarget');
    } else clearHl('dragTarget');
  }

  function dropDragVisual(p) {
    if (!dragState) return;
    const v = dragState.view; v._follow = null;
    const t = p.target;
    if (t && (t.area === 'board' || t.area === 'hand')) {
      const h = t.area === 'hand' ? handTile(t.idx) : null;
      const row = h ? h.row : t.row, col = h ? h.col : t.col;
      const w = boardWorld(row, col, t.area === 'hand');
      v._tween = { fx: v.x, fy: v.y, fz: v.z, tx: w.x, ty: w.y, tz: w.z, t: 0 };
      pending.set(dragState.key, { t: performance.now(), view: v, board: t.area === 'board' ? { row, col } : null });
    } else {
      const h = dragState.home;
      v._tween = { fx: v.x, fy: v.y, fz: v.z, tx: h.x, ty: h.y, tz: h.z, t: 0 };
    }
    v.lift = 0;
    clearHl('dragFrom'); clearHl('dragTarget'); clearHl('legal');
    dragState = null;
  }

  function endDragVisual(cancelled) {
    if (dragState) {
      const v = dragState.view;
      const h = dragState.home;
      if (cancelled && v && !v.destroyed) v._tween = { fx: v.x, fy: v.y, fz: v.z, tx: h.x, ty: h.y, tz: h.z, t: 0 };
      if (v) { v.lift = 0; v._follow = null; }
    }
    dragState = null;
    clearHl('dragFrom'); clearHl('dragTarget'); clearHl('legal');
  }

