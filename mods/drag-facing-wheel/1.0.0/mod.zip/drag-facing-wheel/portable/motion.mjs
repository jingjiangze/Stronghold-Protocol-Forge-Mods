// Extracted from the server renderer's movement formulas. This adapter owns no render loop or network connection.
export function beginPlacementDrag(v){if(!v)return;v.lift=.3;v._tween=null;v._follow=null;}
export function getDragWorldPoint({cam,pointer:p,view:v,isItem:item=false,pointerType:lastPtrType='mouse',heightAt,levels,pickTile,holdTiles:DRAG_HOLD_TILES=.45,bounds={minX:-1,maxX:21,minY:-1,maxY:19}}){
 const g=cam.unproject(p.x,p.y,0);
 const hold=item?0:(lastPtrType==='touch'?DRAG_HOLD_TILES:.12);
 const s0=g?cam.scaleAt(g.x,g.y,0):cam.scale;
 const t=pickTile(cam,p.x,p.y+hold*s0,heightAt,levels);
 const z=t?heightAt(t.row,t.col):0;
 const up=item?z:z+(v.lift||0)+(v.hover||0);
 let w=cam.unproject(p.x,p.y+hold*s0,up);
 if(w&&hold)w=cam.unproject(p.x,p.y+hold*cam.scaleAt(w.x,w.y,up),up)||w;
 return w?{x:Math.max(bounds.minX,Math.min(bounds.maxX,w.x)),y:Math.max(bounds.minY,Math.min(bounds.maxY,w.y)),z}:null;
}
export function followPlacementPointer(v,f){if(!v||!f)return;if(!v._follow){v.x=f.x;v.y=f.y;v.z=f.z;}v._follow=f;}
export function settlePlacement(v,w){if(!v||!w)return;v._follow=null;v._tween={fx:v.x,fy:v.y,fz:v.z,tx:w.x,ty:w.y,tz:w.z,t:0};v.lift=0;}
export function stepPlacementMotion(v,dt){
 if(!v||!Number.isFinite(dt)||dt<0)return;
 if(v._tween){
  const tw=v._tween;tw.t=Math.min(1,tw.t+dt/.22);const k=1-(1-tw.t)*(1-tw.t);
  v.x=tw.fx+(tw.tx-tw.fx)*k;v.y=tw.fy+(tw.ty-tw.fy)*k;v.z=tw.fz+(tw.tz-tw.fz)*k;
  if(tw.t>=1)v._tween=null;
 }else if(v._follow){const f=v._follow,k=1-Math.exp(-dt*22);v.x+=(f.x-v.x)*k;v.y+=(f.y-v.y)*k;v.z+=(f.z-v.z)*k;}
}
