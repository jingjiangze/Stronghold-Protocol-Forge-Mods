// Compatibility adapters only; drag/wheel algorithms remain the server implementation.
import { h } from '../../vendor/preact.module.js';
import htm from '../../vendor/htm.module.js';
import { DEFAULT_HOTKEYS } from './gameLogic/shortcuts.js';
let adapters={getSettings:()=>({keys:DEFAULT_HOTKEYS}),sprite:null};
export function configurePlacementUI(options={}){adapters={...adapters,...options};}
function hFresh(type,props,...children){if(this&&typeof this==='object')this[0]=3;return h(type,props,...children);}
export const html=htm.bind(hFresh);
export const settingsStore={get:()=>{try{return adapters.getSettings?.()||{keys:DEFAULT_HOTKEYS};}catch{return {keys:DEFAULT_HOTKEYS};}}};
export function LocalSprite(props){return adapters.sprite?h(adapters.sprite,props):props.fallback||null;}
