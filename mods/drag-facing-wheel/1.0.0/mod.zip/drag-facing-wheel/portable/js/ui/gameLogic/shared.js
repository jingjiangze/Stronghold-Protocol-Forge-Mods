import { RANDOM_MODE, variantRounds } from '../../../shared/randomMode.js';

// ui/gameLogic/shared.js — small helpers and seat order. Public names are re-exported from ../gameLogic.js.

// ---- small helpers -------------------------------------------------------------------------------

export const isObj = (v) => !!v && typeof v === 'object';
export const int = (v, d = 0) => (Number.isInteger(v) ? v : d);
export const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

/** Stable key of a board tile. */
export const tileKey = (row, col) => `${row},${col}`;

/** Players sorted by seat (nulls dropped). */
export function sortedPlayers(pub) {
  const list = Array.isArray(pub?.players) ? pub.players.filter(isObj) : [];
  return [...list].sort((a, b) => int(a.seat, 99) - int(b.seat, 99));
}

/**
 * The config's rounds row the current round's timers come from. 随机模式 (娱乐模式): the server squeezes the
 * 14-round config into 9 (GameData.applyRandomRounds — R1..R8 keep their row, R9 = the original boss row R14),
 * so the client maps the shown round back to its source row before reading prep/combat timers. The server also
 * adds 随机模式's combat-time bonus (+60 s, RANDOM_MODE.rounds.combatTimeBonus) to R1–R8's limits for the swarm;
 * R9 (the boss row) is untimed in random mode.
 * Lives here (only a shared config import) so phases.js and matchStatus.js can share it without a module cycle.
 * @param {any} pub m.public
 * @param {any} config data/config.json
 * @returns {any|null}
 */
export function roundCfgRow(pub, config) {
  const modes = isObj(config?.modes) ? config.modes : null;
  const mode = modes ? modes[pub.modeId] : null;
  const rounds = isObj(mode?.rounds) ? mode.rounds : null;
  if (!rounds || !isObj(pub)) return null;
  if (pub.randomMode) {
    const r = int(pub.round);
    const total = variantRounds(pub.variant).totalRounds;
    // 独立模拟（mode_single_*）只有 1..9 行——endurance 的 R10–R13 行从同难度的同盟模拟（mode_multi_*）补齐
    const source = /^mode_single_/.test(String(pub.modeId || '')) && isObj(modes[`mode_multi_${String(pub.modeId || '').split('_').pop()}`]?.rounds)
      ? { ...modes[`mode_multi_${String(pub.modeId || '').split('_').pop()}`].rounds, ...rounds }
      : rounds;
    const src = r === total ? 14 : (r >= 1 && r <= total - 1 ? Math.min(r, 13) : null);
    let row = src && isObj(source[String(src)]) ? source[String(src)] : null;
    if (r < total && row?.isBoss && /^mode_single_/.test(String(pub.modeId || ''))) row = modes[`mode_multi_${String(pub.modeId || '').split('_').pop()}`]?.rounds?.[String(Math.min(r, 13))] || row;
    if (!row) return null;
    if (src !== 14) {
      // match the server's +combatTimeBonus on R1..(N-1)'s combat timers (applyRandomRounds)
      return { ...row, combatTimeLimit: Number.isFinite(row.combatTimeLimit) ? row.combatTimeLimit + RANDOM_MODE.rounds.combatTimeBonus : row.combatTimeLimit,
        levelMaxPlayTime: Number.isFinite(row.levelMaxPlayTime) ? row.levelMaxPlayTime + RANDOM_MODE.rounds.combatTimeBonus : row.levelMaxPlayTime };
    }
    return row;
  }
  return isObj(rounds[String(pub.round)]) ? rounds[String(pub.round)] : null;
}
