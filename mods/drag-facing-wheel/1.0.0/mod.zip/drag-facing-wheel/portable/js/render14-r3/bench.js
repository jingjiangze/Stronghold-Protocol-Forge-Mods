import { GEO } from '../../shared/constants.js';
// Keep ten pads on the original row; put expanded slots in the four free pads beside equipment.
export function handTile(idx, geo = GEO) {
  const extra = Math.max(0, geo.HAND_SIZE - 10);
  return idx < extra ? { row: geo.TEMP_ROW, col: idx } : { row: geo.HAND_ROW, col: idx - extra };
}
export function handIndex(row, col, geo = GEO) {
  const extra = Math.max(0, geo.HAND_SIZE - 10);
  if (row === geo.HAND_ROW && col >= 0 && col < Math.min(10, geo.HAND_SIZE)) return col + extra;
  if (row === geo.TEMP_ROW && col >= 0 && col < extra) return col;
  return null;
}
export function benchGlyph(rows, row, col) {
  const extra = Math.max(0, GEO.HAND_SIZE - 10);
  if (!extra) return null;
  if (row === GEO.TEMP_ROW && col >= 0 && col < extra && rows[GEO.HAND_ROW]?.includes('a')) return 'a';
  if (row === 1 && rows[0]?.includes('a') && ((col >= 0 && col < extra) || (col > 20 - extra && col <= 20))) return 'a';
  return null;
}

export function handUnitPoint(unit, side = null) {
  if (unit?.area !== 'hand') return null;
  if (unit.y === GEO.HAND_ROW) { const p = handTile(unit.x); return { x: p.col, y: p.row }; }
  if (unit.y === 0 && (side === 'L' || side === 'R')) {
    const p = handTile(side === 'R' ? 20 - unit.x : unit.x);
    return { x: side === 'R' ? 20 - p.col : p.col, y: p.row - 7 };
  }
  return null;
}
