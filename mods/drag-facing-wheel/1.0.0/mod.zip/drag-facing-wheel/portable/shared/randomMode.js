// shared/randomMode.js — 「无限火力 · 1.1」的全部配置（原随机玩法，保留底层 random 开关）。
// 纯 ESM，无 Node API；server 与 public 各持一份相同文件（如 shared/protocol.js）。
// 所有新逻辑都在 mode === 'random' 的开关后面（server/lobby.js Room.random、Match.opts.random）。
//
// 调数值只改这个文件。结构：
//   RANDOM_MODE.multipliers  数值倍率（作用于 sim/sim Battle 的单位 base，不动数据表）
//   RANDOM_MODE.survival     负生规则（LP<0 判负、1~15 背水盟约翻倍）
//   RANDOM_MODE.firepower    无限火力回转（技力/冷却/再部署）
//   RANDOM_MODE.lowTier      低阶干员逆袭保障（攻速/技力回复/部署上限/突变细胞保底）
//   RANDOM_MODE.bonds        盟约高频叠层参数
//   RANDOM_MODE.rounds       9 回合结构与敌方数值阶梯
//   RANDOM_MODE.band         策略：可重复选、每人两个
//   RANDOM_MODE.shop         商店：盲盒购买、3 选 1、无限池
//   RANDOM_MODE.roundEffects 每回合随机效果表（id、名称、apply(m)、revert(m)），新增只需往表里加一项

import { PHASE } from './constants.js';

/** 模式分支（随机/无限火力房间的第二种协议字段，与 random 并存）。
 *  blitz     快速突袭（短局）：9 回合，紧凑刺激的数值节奏。
 *  endurance 持久鏖战（长局）：13 回合，曲线平滑拉长，供深度养成构筑。
 *  marathon  最长时赛（超长局）：18 回合，深度养成 + 悬赏每回合，最终决战前的极限拉锯。 */
export const RANDOM_VARIANTS = Object.freeze(['blitz', 'endurance', 'marathon']);

/** 归一化分支名（未知值回退 blitz）。 */
export const randomVariantOf = (v) => (v === 'endurance' || v === 'marathon' ? v : 'blitz');

/** 该分支的回合结构（唯一数值源；服务端 GameData.applyRandomRounds / 客户端 roundCfgRow 都读这里）。
 *  返回 { totalRounds, spRounds, enemies, leaders }：blitz 读 RANDOM_MODE.rounds（9 回合）+ 顶层
 *  spRounds / totalRounds；endurance / marathon 读各自分支块（自带全部字段）。 */
export const variantRounds = (variant) => {
  const v = randomVariantOf(variant);
  if (v === 'endurance') return RANDOM_MODE.endurance;
  if (v === 'marathon') return RANDOM_MODE.marathon;
  return {
    totalRounds: RANDOM_MODE.totalRounds,
    spRounds: RANDOM_MODE.spRounds,
    enemies: RANDOM_MODE.rounds.enemies,
    leaders: RANDOM_MODE.rounds.leaders,
  };
};

/**
 * 生成小怪 HP 阶梯（funny 底数 0.8 × 中位怪 4200 基础血 = 3360 基线；hp 倍率 89 ≈ 30 万血，298 ≈ 100 万）。
 * `hpByRound`：指定回合的 hp 倍率锚点（如 R1=89/R2=149 → 30 万/50 万）；其余回合从最后一个锚点几何插值到
 * 末回合的 `hpTo`。ATK 温和递增（0.6 → 3.2）。spRounds：悬赏每回合选（R2 起、末回合前）。
 */
function buildLadder(total, { hpTo = 298, hpByRound = null, atkFrom = 0.6, atkTo = 3.2, leaderFrom = 300000, leaderTo = 2000000 } = {}) {
  const enemies = {};
  const fixed = {};
  if (hpByRound && typeof hpByRound === 'object') {
    for (const [r, v] of Object.entries(hpByRound)) {
      const n = Number(r), val = Number(v);
      if (Number.isInteger(n) && n >= 1 && n <= total && Number.isFinite(val) && val > 0) fixed[n] = val;
    }
  }
  const fixedRounds = Object.keys(fixed).map(Number).sort((a, b) => a - b);
  const lastFixed = fixedRounds.length ? fixedRounds[fixedRounds.length - 1] : 0;
  const lastVal = lastFixed ? fixed[lastFixed] : null;
  const tailRatio = lastFixed && total > lastFixed ? Math.pow(hpTo / lastVal, 1 / (total - lastFixed)) : 1;
  const aRatio = Math.pow(atkTo / atkFrom, 1 / (total - 1));
  for (let r = 1; r <= total; r++) {
    let hp;
    if (fixed[r] != null) hp = fixed[r];
    else if (lastFixed && r > lastFixed) hp = lastVal * Math.pow(tailRatio, r - lastFixed);
    else hp = hpTo; // 锚点之前的回合（理论上不会出现，锚点含 R1）
    enemies[r] = Object.freeze({ hp: Math.round(hp), atk: Math.round(atkFrom * Math.pow(aRatio, r - 1) * 100) / 100 });
  }
  const leaders = { bossPool: null };
  const lRatio = Math.pow(leaderTo / leaderFrom, 1 / (total - 3));
  for (let r = 3; r <= total - 1; r++) {
    leaders[r] = Object.freeze({ hpTarget: Math.round(leaderFrom * Math.pow(lRatio, r - 3) / 10000) * 10000, time: 30 + Math.min(15, r), routeIndex: 0 });
  }
  const spRounds = [];
  for (let r = 2; r <= total - 1; r++) spRounds.push(r);
  return { totalRounds: total, spRounds: Object.freeze(spRounds), enemies: Object.freeze(enemies), leaders: Object.freeze(leaders) };
}

/** R1–R4 固定 hp 倍率 10（FUNNY 0.8 → 中位基础 1 万的怪 ≈ 8 万血），R5 起几何放开到末回合（预算系统接管）。 */
const RM_HP_ANCHORS = Object.freeze({ 1: 10, 2: 10, 3: 10, 4: 10 });

/** 随机模式总配置（冻结；调参只改这里）。 */
export const RANDOM_MODE = Object.freeze({
  /** 快速突袭（短局）总轮次。 */
  totalRounds: 9,
  /** 快速突袭 机变回合（R2 起、末回合前——悬赏每回合选）。 */
  spRounds: Object.freeze([2, 3, 4, 5, 6, 7, 8]),
  /** 持久鏖战（13 回合）/ 最长时赛（18 回合）分支：结构由 buildLadder 生成（小怪 R1 ~15 万 → 末回合 ~100 万，
   *  悬赏每回合选，R3 起悬赏领袖血量递增至 200 万）。 */
  endurance: Object.freeze(buildLadder(13, { hpByRound: RM_HP_ANCHORS })),
  marathon: Object.freeze(buildLadder(18, { hpByRound: RM_HP_ANCHORS })),

  /** 数值倍率：写在 BattleSpec flags 里，由 sim 在「计算最终属性的 base」处相乘（units.js Unit.base 之前）。
   *  技能、盟约 buff 在 base 之上按原公式叠加，所以倍率对它们同样生效。
   *  全局干员白值加成已移除（×3 → ×1）：干员强化改由开局「无限火力模组」装备承担（×5 生命/攻击等，见
   *  opening.modBuff）——不再所有干员无条件变强，穿模组的才强。 */
  multipliers: Object.freeze({
    /** 我方干员（含召唤物）生命倍率 */
    allyHp: 1,
    /** 我方干员（含召唤物）攻击倍率 */
    allyAtk: 1,
    /** 我方防御倍率。 */
    allyDef: 1,
    /** 我方治疗倍率：治疗量通常吃 ATK（ATK×atkScale），ATK 已 ×3，这里再给一个独立系数控制治疗是否额外放大。
     *  1 = 治疗随 ATK 自然放大 3 倍（推荐：干员更硬，医疗也更强）；调小可压制治疗。护盾量同理（吃 heal/atk 的
     *  技能都从放大后的 atk 起算），不单独设倍率。 */
    allyHeal: 1,
    /** 敌人数量倍率：每回合敌人只数 ×N（领袖本体、领袖部件、无伤害装饰怪不翻倍；服务端波次生成时生效）。
     *  怪海怪潮目标 100~250 只/关：占位符替换波次先按 attrPower 拆解（replacedCount 最多 5 倍）再 ×10，
     *  后期波次 ≈ 138 只（R5）→ 峰值接近需求上限；clamp 单组 ≤ 250 只防止刷新队列爆炸。 */
    enemyCount: 10,
    /** 敌人移速 / 攻速 / 阻挡 / 费用 / 射程：一律不动（保持 1）。
     *  敌人 HP/ATK 不在这里：按回合阶梯取（rounds.enemies）。 */
  }),

  /** 负生规则：基地 LP < 0 即判负（当局战败，禁止参与后续联防，但仍然参与后续轮次）；1~15 点进入背水。 */
  survival: Object.freeze({
    /** LP < 0 判负（当局战败：座位保留、继续打后续轮次、不能再当局获胜；不能当联防 helper）。 */
    negativeLose: true,
    /** 背水区间 [1, threshold]（含）：每次进入该区间，所有已激活盟约当前层数立刻翻倍。 */
    threshold: 15,
    /** 最终攻势的合并队伍 LP：判负玩家按 0 计入；队伍 LP 归零即战败（自然规则，无保底）。 */
    teamLpFloor: false,
  }),

  /** 开局部署：全员初始可部署人数直接写死 9 人（不依赖【人事部文档】装备；PlayerState 构造器覆写）。 */
  deploy: Object.freeze({
    /** 随机模式的固定部署上限。 */
    cap: 9,
  }),

  /** 无限火力回转：移除 80% 技力/冷却缩减与强制自动充能——改为全员技力恢复速度 ×1.3（保留干员原生技能轴
   *  与回技力装备联动空间）；再部署时间缩短保持 ×0.3。 */
  firepower: Object.freeze({
    /** 技力消耗乘数：1 = 不缩减（原生技能轴；手动技能冷却同步不缩减）。 */
    spCostMul: 1,
    /** 攻击/受击回复型技能不再强制自动充能（false = 保留原生 spType）。 */
    autoCharge: false,
    /** 全员技力恢复速度倍数（spRecovery ×；time 型回转技的通用加速）。 */
    spRecoveryMul: 1.3,
    /** 手动技能的自动操作冷却乘数（0.5 = -50%）。 */
    opCdMul: 0.5,
    /** 冷却下限（秒）：×乘数后不低于该值。 */
    opCdFloor: 2,
    /** 阵亡/撤退再部署时间乘数（0.3 = -70%）。 */
    redeployMul: 0.3,
  }),

  /** 低阶干员逆袭保障（1~3 阶）。 */
  lowTier: Object.freeze({
    /** 阶 ≤ lowTierMax 的干员攻击速度加成（+120 → +50：配合远程攻速剔除，防前摇动画卡死）。 */
    aspd: 50,
    /** 阶 ≤ lowTierMax 的干员技力恢复速度倍数。 */
    spRecoveryMul: 2,
    /** 低阶保障的最大阶（含）。 */
    lowTierMax: 3,
    /** 这些回合各保底发放 1 件【突变细胞】。 */
    cellRounds: Object.freeze([3, 6]),
  }),

  /** 盟约高频叠层（与怪海/技能强绑定；全部走 sim 内 gainLayers，原乘算公式不动）。
   *  layerCap: 999 → 解除封顶（0 = 无上限，支持四位数成长；Battle.addLayers / settle / 背水全部同读）。 */
  bonds: Object.freeze({
    /** 层数封顶（0 = 无上限：突破四位数无上限成长）。 */
    layerCap: 0,
    /** 通用：每击杀一个敌人，击杀干员所属的已激活盟约各 +killsPerLayer 层（0 = 关闭）。 */
    killsPerLayer: 1,
    /** 【炎】：炎干员每释放 2 次技能 +1；击破精英怪 +5。6 人炎佑属性及灼燃损伤频率 ×2。 */
    yan: Object.freeze({ perSkill: 0.5, perEliteKill: 5, yanyouMul: 2 }),
    /** 【拉特兰】：全队每消耗 8 发技能弹药 +1；2 人羁绊起弹药消耗的攻击力加成上限解除（uncapMembers）。
     *  基础质变：拉特兰成员 dmgDealtMul ×(1 + dmgPerLayer × L)（无上限）。
     *  325：非弹药技能干员的虚拟弹药每 virtualPerHits 次命中，下一次攻击附加 virtualAtkScale × ATK 真伤。
     *  799：圣光——每次真实弹药 ammoUsed 有 holyChance 概率触发（虚拟弹药 holyChanceVirtual），单干员 holyCd 秒
     *  内置冷却；伤害 = holyAtkScale × ATK × (1 + L/799) 全图真实伤害；物法交替（alternateAt799）：圣光在物理
     *  与法术伤害间交替，799 层起伤害 ×2。 */
    laterano: Object.freeze({
      ammoPerLayer: 8, uncapConsumeAtk: true, uncapMembers: 2,
      dmgPerLayer: 0.002,
      virtualPerHits: 5, virtualAtkScale: 1.5,
      holyChance: 0.15, holyChanceVirtual: 0.05, holyCd: 0.3, holyAtkScale: 5,
      alternateAt799: true, alternateMul: 2,
    }),
    /** 【阿戈尔】：保留原版吞噬等阶叠层；每击倒 2~3 只怪物 +1（随机模式：killsPerLayer=2，每第 3 杀额外 +1
     *  ——「每击倒 2~3 只」的平滑化实现：avg 2.5 杀/层）。 */
    egir: Object.freeze({ killsPerLayer: 2, killsPerLayerCycle: 3 }),
    /** 【维多利亚】：携带装备的维多利亚干员每造成 25 次伤害 +1；每 25 层掉 1 件维式重锤（原公式照旧）。 */
    victoria: Object.freeze({ hitsPerLayer: 25, hammerPerLayers: 25 }),
    /** 【谢拉格】：场上每 1 名敌人被冻结或死于冻结 +1；寒风随层数延长至整场常驻。 */
    kjerag: Object.freeze({ perFreeze: 1, stormFloor: 60 }),
    /** 【助力】：每击杀 40 只杂兵，当前所有已激活的核心盟约层数同时 +10。 */
    deput: Object.freeze({ killsPerPulse: 40, pulseLayers: 10 }),
  }),

  /** 9 回合敌方数值与波次阶梯（HP/ATK 倍率乘在原 enemyScale 之上，只影响普通敌人；领袖按 boss 规则）。
   *  逐回合递增（×1.25/轮）：全局干员白值加成已移除（模组承担 ×5），怪曲线同步回调——R1 杂兵 ~6 千血
   *  （1-2 刀）→ R9 ~5.4 万血（3-5 刀），与「穿模组干员 ×5 + 无模组干员 ×1」的输出结构对齐。 */
  rounds: Object.freeze({
    /** 每回合敌方倍率（乘在官方 enemyScale 之上；标准同盟(FUNNY) enemyScale 恒 0.8——中位杂兵 4200 基础血，
     *  ×0.8×倍率 即实际血量，R1 ~15 万 → R9 ~100 万——玩家反馈「还是太脆」，全面上调（buildLadder 生成）。
     *  ATK 低开缓升：干员无全局防御加成，威胁按模组覆盖进度爬坡。 */
    enemies: Object.freeze(buildLadder(9, { hpByRound: RM_HP_ANCHORS }).enemies),
    /** 每回合战斗限时增量（真实秒）：怪海怪潮需要充裕时间刷新完毕并被清理。加在原波次的
     *  combatTimeLimit / levelMaxPlayTime 上（R9 最终决战本身不限时，不受此值影响）。 */
    combatTimeBonus: 60,
    /** 出怪速度倍率（0.6 = 出怪快 40%）：缩放波次的刷怪窗口与起始时间——整波更快涌出，减少「出怪太慢」
     *  的等待（waves.js templateSpawns / buildWaveMixGroups 消费）。 */
    spawnSpeedMul: 0.6,
    /** R1–R4（round < blockableOnlyBefore）波次排除「无视阻挡」的特殊敌人（幽灵组长/鸭爵/圆仔/木印等，
     *  content/enemies.js UNBLOCKABLE_ENEMY_KEYS）——确保开局可被阻挡住。5 = R5 起放开。 */
    blockableOnlyBefore: 5,
    /** 每关常驻领袖（R3–R8；R9 走最终决战的正式 boss 战）：从「悬赏 BOSS 池」按对局种子每关抽 1 个
     *  （悬赏决策 cards.bounty 里 rank=BOSS 的悬赏目标——碎骨 / 自在 / 大鲍勃 / 杰斯顿 / 泥岩 / 弑君者 / W
     *  / 鼠王 / 锏 / 扎罗 / 墓碑 / 复仇者 … 各类悬赏 boss 轮换，不再固定关底 boss），以 extraSpawn 加入普通波次。
     *  每关给的是目标绝对血量 hpTarget（68→90→110→140→180→240 万，避免中期回落/末轮突增；独立乘区）：倍率在服务端按
     *  `hpTarget / 该 boss 基础 maxHp` 反算，所以不同基础血量的悬赏 boss 都被拉到同一血量标尺（确定性）。
     *  `swarm`（可选）：R3–R4 波次本身稀疏（22/19 只），补一组低血量杂兵把怪海拉到 100~250 只区间。 */
    leaders: Object.freeze({
      /** 悬赏 BOSS 池（悬赏决策 cards.bounty，rank=BOSS）。R3–R8 每关用 rngLeader 从池中抽 1 个。 */
      bossPool: Object.freeze([
        'enemy_1500_skulsr', // 碎骨
        'enemy_1501_demonk', // 萨卡兹百夫长
        'enemy_1502_crowns', // 弑君者
        'enemy_1511_mdrock', // 泥岩
        'enemy_1513_dekght', // 腐败骑士
        'enemy_2005_axetro', // “遗弃者”
        'enemy_2004_balloon', // 喷气人
        'enemy_1516_jakill', // 杰斯顿·威廉姆斯
        'enemy_1504_cqbw',   // W
        'enemy_1509_mousek', // 鼠王
        'enemy_1050_lslime', // “庞贝”
        'enemy_1001_bigbo',  // 大鲍勃
        'enemy_1517_xi',     // “自在”
        'enemy_1525_blkswb', // 锏
        'enemy_1535_wlfmster', // 扎罗，“狼之主”
        'enemy_2008_flking', // “墓碑”
        'enemy_2003_rockman', // 迷路的巨像
        'enemy_1512_mcmstr', // “巨大的丑东西”
        'enemy_1539_reid',   // “复仇者”
        'enemy_2048_smgrd',  // “邪魔的利刃”
        'enemy_2050_smsha',  // 陷落雪祀
        'enemy_2052_smgia',  // 纠缠藤蔓
      ]),
      3: Object.freeze({ hpTarget: 300000, time: 30, routeIndex: 0, swarm: { enemyKey: 'enemy_1007_slime', count: 60, time: 10, window: 90 } }),
      4: Object.freeze({ hpTarget: 390000, time: 30, routeIndex: 0, swarm: { enemyKey: 'enemy_1007_slime', count: 50, time: 15, window: 80 } }),
      5: Object.freeze({ hpTarget: 510000, time: 35, routeIndex: 0 }),
      6: Object.freeze({ hpTarget: 660000, time: 35, routeIndex: 0 }),
      7: Object.freeze({ hpTarget: 860000, time: 40, routeIndex: 0 }),
      8: Object.freeze({ hpTarget: 1120000, time: 40, routeIndex: 0 }),
    }),
    /** 领袖及精英怪的防御力与法术抗性统一下调（防御抛光修正）：def/res × 0.6（即 -40%），杜绝高频物理 /
     *  法术干员对上 1000+ 防 60 抗目标的严重刮痧。作用在所有 extraSpawn（领袖 + R5 质检精英）上。 */
    defResMul: 0.6,
    /** R5 中场质检：单体高抗性精英领袖（泥岩巨像）领衔海量怪——服务端在 R5 的普通波次里追加。
     *  自带常驻免控霸体（immunities 免疫全部控制——STATUS 的 immune 名：stun/frozen/sleep/silence/feared/
     *  levitate/palsy），HP 10 万 / DEF 700 / RES 30 天然高抗（防御/法抗按 defResMul 再下调）。 */
    midBoss: Object.freeze({
      round: 5,
      /** 加入波次的精英领袖（数量固定，不随 enemyCount 翻倍——它领衔怪海，不属于怪海）。 */
      eliteKey: 'enemy_1092_mdgint',
      eliteCount: 2,
      /** 免控霸体：免疫全部控制状态（Battle.spawnEnemy opts.immune 与 def.immune 的并集）。 */
      immunities: Object.freeze(['stun', 'frozen', 'sleep', 'silence', 'feared', 'levitate', 'palsy']),
    }),
    /** R9 最终决战：boss 权重只留 假想敌系列 + 阿利斯泰尔（multi：阿利斯泰尔领衔）；多段护盾/锁血由 boss 自带
     *  （假想敌：胄 的形态切换与护盾、阿利斯泰尔的皇家盾），领袖共享血池 ×finalBossHp。 */
    finalBossWeights: Object.freeze({ boss_1: 3, boss_2: 3, boss_3: 2, boss_6: 4 }),
    /** 终局领袖共享血池倍率（乘 bloodPoint×share 之后；普通敌人不适用）。模组×5 + 盟约叠层下玩家输出极高，
     *  原 19（≈800–1330 万）太脆——上调到 150（coop ≈ 6000 万 / solo ≈ 1500 万），最终 boss 成为真正的血墙。 */
    finalBossHp: 150,
  }),

  /** 策略（战斗前选人）：同策略可被不同玩家重复选（甚至同一玩家两个同名），每人选两个。 */
  band: Object.freeze({
    /** 每人可选策略数 */
    picksPerPlayer: 2,
    /** 是否允许同一玩家两个位置选同一个策略（叠加两次） */
    allowDuplicateSelf: true,
  }),

  /** 商店盲盒。 */
  shop: Object.freeze({
    /** 盲盒统一价（购买前不知道内容）。按回合定价：R1–2 更便宜，R3 起涨价——一个 (round) => price 函数。
     *  购买前不知道内容；null = 沿用原价体系（不推荐，会泄露稀有度）。 */
    mysteryPrice: (round) => (round <= 2 ? 2 : 3),
    /** 购买后 4 选 1 的候选数。 */
    revealChoices: 4,
    /** 阵营盲盒：每次刷新固定出现 1 个（占用一个盲盒槽位）。候选阵营 = 所有核心盟约中有 ≥1 名可抽干员的阵营；
     *  权重 w_f = 1 + weightK × min(n_f, 6) / 6（n_f = 玩家场上+备战区属于该阵营的不同干员数，同名只算一次）；
     *  归一化后单阵营概率 ≤ maxShare（超出按其他阵营权重比例分配；候选不足 3 个时不封顶）。
     *  保底：主阵营 = n_f 最大者（并列取层数高者；全为 0 不触发），连续 pity-1 次未出现则第 pity 次必出，出现后清零；
     *  主阵营变化时清零。 */
    factionBox: Object.freeze({
      weightK: 5,
      maxShare: 0.5,
      pity: 4,
    }),
    /** 盲盒免费重掷次数（展开候选后可重掷，重新走盲盒规则刷新候选；0 = 关闭）。 */
    rerolls: 1,
    /** 取消干员池限制：不受池余量限制、无上限（整备区/棋盘容量照旧限制） */
    infinitePool: true,
    /** 候选不限商店等级：全池 1–6 阶干员都可能开出（刺激就完事了） */
    candidateMaxTier: 6,
    /** R1 起商店直接 6 级（满级：5 干员 + 1 装备槽、全阶可刷）：省去升级经济的铺垫，配合盲盒 1–6 阶
     *  全随机的定位；升级按钮在随机模式下不可用（已满级）。 */
    startLevel: 6,
    /** R1 的开局资金（原版 income[1]=4；后续回合 R2+ 走原版收入表）。 */
    startFunds: 8,
    /** 商店中 5 阶与 6 阶装备的刷新权重提升（1 = 原版；4 = 提升 300%）。 */
    rareEquipWeight: 4,
  }),

  /** 每回合随机效果（回合开始 apply，回合结束 revert；随机数由服务端抽取）。
   *  已移除无限资金/无限刷新类增益（rm_inf_funds / rm_inf_refresh）：保留正常合理的局内经济循环与盲盒
   *  获取节奏，不再出现资金无意义溢出。
   *  已移除天降超模正向事件「装备大甩卖 / 装备狂欢」（rm_inf_item）：高阶装备获取改走 5/6 阶权重提升 +
   *  阶段质变【军备充盈】的正规途径。 */
  roundEffects: Object.freeze([
    // ---- 玩家侧 ----
    {
      id: 'rm_bond_double', name: '盟约狂欢·羁绊翻倍',
      apply: (m) => { for (const ps of m.alivePlayers()) { m._rmBondDoubleBefore = m._rmBondDoubleBefore || new Map(); m._rmBondDoubleBefore.set(ps.playerId, { ...ps.layers }); for (const [b, n] of Object.entries(ps.layers)) ps.layers[b] = n * 2; ps.recompute(); } },
      revert: (m) => { const before = m._rmBondDoubleBefore; if (!before) return; for (const ps of m.alivePlayers()) { const b = before.get(ps.playerId); if (b) { ps.layers = { ...b }; ps.recompute(); } } m._rmBondDoubleBefore = null; },
    },
    {
      id: 'rm_all_hp', name: '生命强化·全员超载',
      apply: (m) => { m._rmStatMul = { hp: 2 }; },
      revert: (m) => { m._rmStatMul = null; },
    },
    {
      id: 'rm_all_atk', name: '攻击强化·伤害拉满',
      apply: (m) => { m._rmStatMul = { atk: 2 }; },
      revert: (m) => { m._rmStatMul = null; },
    },
    {
      id: 'rm_all_fast', name: '攻速狂飙·点射地狱',
      apply: (m) => { m._rmAllyAspd = 200; },
      revert: (m) => { m._rmAllyAspd = 0; },
    },
    // ---- 敌人侧 ----
    {
      id: 'rm_enemy_speed', name: '敌人竞速·夺命狂奔',
      apply: (m) => { m._rmEnemyMoveMul = 1.5; },
      revert: (m) => { m._rmEnemyMoveMul = 1; },
    },
    {
      id: 'rm_enemy_fast', name: '敌人开挂·加特林模式',
      apply: (m) => { m._rmEnemyAspd = 150; },
      revert: (m) => { m._rmEnemyAspd = 0; },
    },
    {
      id: 'rm_enemy_bomb', name: '同归于尽·狂飙自爆',
      // 所有敌人移速 ×2 疯狂冲锋；敌人被击倒时原地自爆，对半径 1.5 内我方干员造成 10000×当前回合数的
      // 真实伤害（无视闪避/防御；每干员 0.5s 限频一次；Battle 的 rm.enemyBomb 按 kill hook 落地，
      // 领袖/部件不自爆）。
      apply: (m) => { m._rmEnemyMoveMul = 2; m._rmEnemyBomb = true; },
      revert: (m) => { m._rmEnemyBomb = false; m._rmEnemyMoveMul = 1; },
    },
  ]),

  /** 攻速安全上限：interval 下限由 TICK(1/30s) 决定，aspd 上限沿用 sim 的 ASPD_MAX(600) 再收紧 */
  aspdCap: 600,

  /** 远程单位攻速剔除：所有高台/远程干员与远程敌方单位严格不获得额外全局攻速增益（rm.allyAspd /
   *  rm.enemyAspd / 低阶 aspd），防止因攻速过快导致前摇动画卡死原地（sim 侧按 position/attack 判定）。 */
  rangedNoAspd: true,

  /** 阶段质变（每 3 回合，休整期强制三选一弹窗；Match._rmEvolutionRounds / EnterEvolution）。 */
  evolution: Object.freeze({
    /** blitz 分支的质变回合。 */
    rounds: Object.freeze([3, 6, 9]),
    /** endurance 分支的质变回合（13 回合模式：3/6/9/12）。 */
    roundsEndurance: Object.freeze([3, 6, 9, 12]),
    /** 【层数共鸣】已激活盟约层数 ×1.5。 */
    layersMul: 1.5,
    /** 【生机坚壁】基地生命值 +N（可突破初始上限）。 */
    lpGain: 15,
    /** 【军备充盈】塞满整备栏的随机高阶装备（5/6 阶各半，超出进暂存）。 */
    armoryCount: 12,
    /** 【盟约同调】（第 4 选项）：另一个核心盟约的层数同步为自己已激活盟约中的最高层数。 */
    syncEnabled: true,
  }),

  /** R5 核心干员自选：第 5 回合休整期固定发放 1 个自选道具，使用后指定获取任意 1 名干员。 */
  pickAny: Object.freeze({
    round: 5,
    /** 自选候选数（0 = 全池浏览式选择；>0 = 随机候选 n 选 1）。 */
    candidates: 6,
  }),

  /** 多人干员互传【信标】：每回合商店固定刷新 1 件（随机模式独有），使用后把自身 1 名干员传给指定队友。
   *  实现：复用道具 chess_item_5_04_e_a（信标，use_equip_recruit_new_char_and_give_char_to_player_most_bond）。 */
  beacon: Object.freeze({
    itemId: 'chess_item_5_04_e_a',
  }),

  /** 敌方数值终局约束（sim spawnEnemy 最终落点 Clamp）。血量不设上限（Infinity）：逐回合递增的
   *  enemies/leaders 阶梯自然成长，领袖层成长也不封顶。
   *  防御按玩家层数 L 计算（见 BUDGET.defBaseScale / defExtraAt799 / defCapRatio）：最终防御 = 基础防御 × s + extraDef。 */
  enemyClamp: Object.freeze({
    /** 控制免疫：小怪/精英/领袖对控制状态（stun/frozen/sleep/silence/feared/levitate/palsy 等）的高额抗性——
     *  施加控制时按 ccResist 概率抵抗（0 = 无免疫，1 = 完全免疫）。 */
    ccResist: 0.9,
    /** 血量上限：单怪最高 100 万（普通/精英/全局同限；Boss 血池单位另走 pool，不受此限）。 */
    normalHpCap: 1000000,
    eliteHpCap: 1000000,
    globalHpCap: 1000000,
  }),

  /** 终局领袖关卡（R9 / R13 最终决战）：150 秒限时 + 软化加班扣除。 */
  finalLevel: Object.freeze({
    /** 终局领袖关卡限时（真实秒；到点后战斗继续，进入加班流失）。 */
    seconds: 150,
    /** 加班流失：每 5 真实秒扣 1 点基地生命值（软化；正常模式每秒 1 点）。 */
    overtimePerSecs: 5,
    overtimeLoss: 1,
  }),

  /** 波次复合组成（怪潮全库随机多样化；waves.js 随机模式专用编队）。
   *  每波敌人不重复：四类池默认走全库自动筛选（waves.js waveMixPools，配置列表 <8 个时忽略）；组内抽取
   *  排除本波已用 key（uniquePerWave），模板占位符每 action 也独立抽全库 key（templateSpains diverse）。 */
  waveMix: Object.freeze({
    /** 是否启用复合编队（关闭 = 走官方随机模板）。 */
    enabled: true,
    /** 前排肉盾池（<8 个 key 时自动用全库筛选池——留空即纯全库）。 */
    tankKeys: Object.freeze([]),
    /** 步兵海池。 */
    infantryKeys: Object.freeze([]),
    /** 边路高速怪池。 */
    fastKeys: Object.freeze([]),
    /** 后排远程怪池。 */
    rangedKeys: Object.freeze([]),
    /** 机制怪池。 */
    specialKeys: Object.freeze([]),
    /** 每回合额外附加的复合波组数（组越多、每组越小 = 每波种类越多）。 */
    groupsPerRound: 4,
    /** 每组的复合构成（占每组怪数的比例）。 */
    weights: Object.freeze({ tank: 0.15, infantry: 0.55, fast: 0.15, ranged: 0.15 }),
    /** 机制怪出现概率（每组独立掷一次）。 */
    specialChance: 0.5,
    /** 单组怪数基数（× enemyCount 前）。 */
    baseGroupSize: 8,
  }),

  /** 中后期领袖血量随玩家层数自然抬升（R5+ 的悬赏领袖 hpTarget 额外 ×(1 + teamLayers×growthPerLayer)）。 */
  leaderGrowth: Object.freeze({
    /** 从第几回合起生效。 */
    fromRound: 5,
    /** 每层全队盟约层数折算的领袖血量成长（× 基准 hpTarget；每 ~1670 全队层数 ≈ ×2）。 */
    growthPerLayer: 0.0006,
    /** 成长不封顶（Infinity：盟约层数无上限，领袖血量同步无上限）。 */
    maxMul: Infinity,
  }),

  /** 高层数质变（盟约里程碑）：任一盟约层数达到阈值时全员激活对应特性（bonds/core.js installMilestones）。
   *  全局层（milestones.aspd / milestones.splash）：达到阈值的盟约本身所在阵营干员获得攻速 +N 与攻击溅射。
   *  perBond 层：各盟约专属质变（325/799），见 core.js installMilestones 的实现注释。 */
  milestones: Object.freeze({
    /** 阈值 → 攻速加成（该盟约阵营干员）。 */
    aspd: Object.freeze({ 325: 50, 799: 100 }),
    /** 阈值 → 攻击附带范围伤害（溅射半径 / 倍率）。 */
    splash: Object.freeze({ 799: Object.freeze({ radius: 1.5, scale: 1.0 }) }),
    /** 精锐干员所在的阵营叠层 ×1.5（每名精锐干员给自己所属的已激活盟约的叠层收益乘区）。
     *  实现：PlayerState.addLayers 的随机模式分支——目标盟约的成员里每有 1 名精锐，本次叠层 ×1.5。 */
    eliteLayerMul: 1.5,
    /** 精锐倍率按成员数封顶（×，最终乘区上限）。 */
    eliteLayerCap: 6,
  }),

  /** 开局发育保障（R1–R2）：高攻速 + 直接获取三连合成后的精锐干员。 */
  opening: Object.freeze({
    /** R1–R2 全员（干员）额外攻速。 */
    earlyAspd: 150,
    /** R1–R2 获取（盲盒买出 / 自选 / 信标等 acquireChess）的干员直接以三连合成后的精锐形态入栏
     *  （PlayerState.acquireChess 的随机模式分支：凑齐 3 份副本直接合成精锐）。 */
    earlyEliteRounds: Object.freeze([1, 2]),
    /** 开局发放「无限火力装置」装备：R1 发 5 个、R2/R3 各 2 个（共 9 个）。
     *  复用刷新类道具寻呼模块做载体，装备时销毁并给该干员永久模式 buff。 */
    modItemsPerRound: Object.freeze({ 1: 5, 2: 2, 3: 2 }),
    modRounds: Object.freeze([1, 2, 3]),
    /** 模组装备 id（寻呼模块——装备时销毁的刷新类道具；随机模式下其原生效果被模式 buff 替代）。 */
    modItemId: 'chess_item_4_01_e_a',
    /** 模式特有 buff（装备模组的干员获得）：生命 ×5、技力恢复时间 -50%（恢复速度 ×2）、可复活一次、
     *  攻击 ×5、防御 +30%、阻挡数 +8。 */
    modBuff: Object.freeze({
      hpMul: 5,
      spRecoveryMul: 2,
      reviveOnce: true,
      atkMul: 5,
      defMul: 1.3,
      blockCnt: 8,
      /** 技能冷却 ×cdMul（0.25 = -75%；skills.js activate 的手动技能冷却读取）。 */
      cdMul: 0.25,
      /** 双倍效果：所有伤害 ×2（"双倍效果的特质"）。 */
      dmgDealtMul: 2,
    }),
    /** 精锐干员可穿无限装备（解除 equipPerChess 2 件上限）。 */
    eliteInfiniteEquip: true,
  }),

  /** 偷干员的怪（R4 起）：每局有 30% 概率在 R4 起的一个非最终回合出现一次、1000 万血的慢速怪冲上战场「偷走」玩家 1 名已部署干员——被偷的干员
   *  永久移除，只有在本回合内击败这只怪才会归还。激励玩家堆输出/围攻。 */
  thief: Object.freeze({
    /** 从第几回合开始出现（含）。 */
    fromRound: 4,
    /** 目标血量（固定绝对血量，按 hp / 基础 maxHp 反算倍率）。1000 万——降低单人输出压力。 */
    hp: 10000000,
    /** 每局出现概率；命中后只在一个普通回合出现一次。 */
    chance: 0.3,
    /** 载体敌人（近战地面 boss——走得到前线，慢速可拦可打）。 */
    enemyKey: 'enemy_1001_bigbo',
    /** 移速乘数（0.08 = 极慢，几乎原地；玩家有充裕时间围杀）。 */
    moveMul: 0.08,
    /** 加入波次的时间（秒）与刷出窗口。 */
    time: 8,
    window: 40,
    /** 每次偷走的干员数（被偷者从棋盘移除，永久丢失，除非击败此怪归还）。 */
    stealCount: 1,
  }),
});

/** 该房间是否是随机模式（Room 或 match opts 都可传入）。 */
export const isRandomRoom = (room) => !!(room && room.random === true);

/** 输出预算/单击封顶/层数护盾/阶段配置（仅随机模式；server/match/budget.js 实现）。 */
export const BUDGET = Object.freeze({
  /** 基础预算系数 K（modes.hpBudgetK 可覆盖，默认 0.6）。B_group = K_run × T × DPS_est。 */
  hpBudgetK: 0.6,
  /** 血量预算只追踪玩家 DPS 的这一比例（敌人强度用 DPS_est × dpsScale；DPS 统计与 D5 记录保持原值）。 */
  dpsScale: 0.5,
  /** 按玩家盟约层数分阶段（L = 最高核心盟约永久层数，阶段只升不降）。
   *  阶段 0（L<100）：m=1，原版数值，无特殊机制；阶段 1（100–324）：开预算，K_stage 按 log(L) 从 0.5 线性过渡到 1.0；
   *  阶段 2（325–798）：K_stage=1.0；阶段 3（≥799）：K_stage=1.0，开层数护盾。 */
  stageThresholds: Object.freeze([100, 325, 799]),
  /** K_stage 过渡：阶段 1 内 K_stage = lerp(kStageLo, kStageHi, (log(L)-log(100))/(log(325)-log(100)))。 */
  kStageLo: 0.5,
  kStageHi: 1.0,
  /** T（全队满输出秒数）—— 杂兵组 / 精英·领袖，按绝对回合 r 取值。 */
  T: Object.freeze({
    mob: (r) => (r <= 4 ? [6, 7, 8, 9][r - 1] : r === 5 ? 6 : 5),
    elite: (r) => (r <= 4 ? [8, 9, 10, 11][r - 1] : r === 5 ? 10 : 9),
  }),
  /** runMul 开局对数均匀 [0.85, 1.25]；roundMul 每回合均匀 [0.9, 1.15]；乘积封顶 kRunCap。 */
  runMulRange: Object.freeze([0.85, 1.25]),
  roundMulRange: Object.freeze([0.9, 1.15]),
  kRunCap: 1.3,
  /** R6+ 追踪公式指数：B_group = K_run × T × D5 × (DPS_est / D5)^0.6。 */
  chaseExp: 0.6,
  /** 血量预算只追踪玩家 DPS 的一部分：所有用 DPS_est 计算敌人强度的地方（预算 B / 走路封顶 / 终局 Boss）
   *  都乘 dpsScale。DPS 统计与日志保持原值，另发 DPS_used = DPS_est × dpsScale。
   *  R6+ 公式里 D5 保持原始 DPS（公式整体已乘过一次，避免重复）。 */

  /** 完全无数据时 DPS_est = F_now × 0.4（F 已按敌中位防御折减）。 */
  coldStart: 0.4,
  /** DPS_eng：最近 10 个有效窗口 p50 ÷2（2s 窗口）；有效窗口 <3 视为无数据。 */
  windowSec: 2,
  windowKeep: 10,
  windowMin: 3,
  /** 走路时间封顶：杂兵组 B ≤ 0.6 × DPS_est × t_walk；精英和领袖 B ≤ 0.5 × DPS_est × t_walk（t_walk = 路径长 ÷ 实际移速）。 */
  walkCap: Object.freeze({ mob: 0.6, elite: 0.5 }),
  /** 护盾计入走路封顶的系数：层数 × 平均每次命中伤害 × 0.9。 */
  walkShieldFactor: 0.9,
  /** 倍率封顶：mCap[stage]（阶段 0–3）。 */
  mCap: Object.freeze([1, 3, 8, 20]),
  /** 单击封顶（占目标当前 maxHp 的比例）—— 只对精英/领袖/Boss（杂兵不封顶）。 */
  hitCap: Object.freeze({
    elite: (r) => (r <= 4 ? 0.015 : 0.03),
    boss: 0.005,
  }),
  /** 终局 boss：finalBossHp = clamp(K_run × 80 × DPS_est, 原版数值, DPS_est × 120)；去掉 3.25 亿硬上限。 */
  finalBossT: 80,
  finalBossCapT: 120,
  /** 层数护盾（仅阶段 3，只对精英、领袖、Boss）。每次 dealDamage 命中消耗 1 层，该次伤害 ×0.1。 */
  shield: Object.freeze({
    eliteLayers: 10,
    leaderLayers: 15,
    bossLayers: 30,
    /** Boss 每降 25% 血补 30 层。 */
    bossRefillPct: 25,
    bossRefillLayers: 30,
    /** 层数吸收时该次伤害的乘区。 */
    absorbMul: 0.1,
  }),
  /** 敌人移速上限：最终移速 ≤ 原始 ×moveMulCap，且每秒 ≤ tilesPerSecCap 格。 */
  moveMulCap: 1.5,
  tilesPerSecCap: 1.2,
  /** 敌人防御按玩家层数 L 计算（L 与阶段系统同口径）：最终防御 = 基础防御 × s + extraDef（精英/领袖再 ×0.6，
   *  封顶 ≤ 当前上阵干员最终攻击中位数 × defCapRatio，出场时算一次）。
   *  s：L<100 为 0；100≤L<325 按 log(L) 从 defBaseScale 线性过渡到 1.0；L≥325 为 1.0。
   *  extraDef：L<100 为 0；100≤L<799 为 defExtraAt799 × log(L/100)/log(7.99)；L≥799 为 defExtraAt799 × (1 + log2(L/799))。 */
  defBaseScale: 0.5,
  defExtraAt799: 1200,
  defCapRatio: 0.4,
  /** Boss 免疫谢拉格 799 即死。 */
  shatter: Object.freeze({ bossImmune: true }),
});

/** 分支显示名。 */
export const RANDOM_VARIANT_NAMES = Object.freeze({ blitz: '快速突袭', endurance: '持久鏖战' });

/** m.public / room.state 上显示的模式名。 */
export const RANDOM_MODE_NAME = '无限火力 · 1.1';

/** One encounter per match, using its own seeded random stream. No encounter on boss fields. */
export function rollThiefRound(rng, eligibleRounds) {
  const rounds = eligibleRounds.filter(r => Number.isInteger(r) && r >= RANDOM_MODE.thief.fromRound);
  if (!rounds.length || rng() >= RANDOM_MODE.thief.chance) return null;
  return rounds[Math.min(rounds.length - 1, Math.floor(rng() * rounds.length))];
}

/** Presentation only: preserve the original item and effects outside infinite firepower. */
export function randomModeItemRecord(item, enabled) {
  if (!enabled || !item || item.id !== RANDOM_MODE.opening.modItemId) return item;
  const b = RANDOM_MODE.opening.modBuff;
  const desc = `配发后消耗装置，干员本局永久获得：生命上限 ×${b.hpMul}、攻击力 ×${b.atkMul}、防御力 +${Math.round((b.defMul - 1) * 100)}%、技力恢复速度 ×${b.spRecoveryMul}、阻挡数 +${b.blockCnt}${b.reviveOnce ? '；每场战斗首次受到致命伤害时满血复活一次' : ''}。`;
  return { ...item, name: '无限火力装置', desc, descRaw: desc, flavor: '', note: '仅无限火力模式生效；配发后装置消耗，替代寻呼模块原本的选人效果。' };
}
