// kits/chess_char_9_14_a.js - 同人内容包的行为层 kit（创意工坊 §4：kits/<id>.js，默认导出即 kit 函数）。
//
// 契约与官方内容 server/sim/content/kits/tierN.js 完全一致：返回 { skill?, skills?, talents?, trait?, install? }。
// 引擎按 baseId → id → 去掉 _a/_b 的裸 id 查表，所以一个文件同时覆盖普通与精锐两枚棋子。
//
// 共享辅助（含引擎内部工具函数的逐字复刻）住在 ./lib/_shared.js：被相对 import，所以它自己
// 不写白名单 specifier（loader 只重写顶层 kit 文件里的那些）。
import * as S from './lib/_shared.js';

const { num, on, talentBb, mods, batPct, tokenOf, prostOf, isProstsOf, neighbors, whileOn, inRangeOf,
  skillRec, skillBbOf, COLS, hypot, hasHp, periodicDamage, bodyInKeys, frontOf, sortEnemyTargets,
  PRIO_REVIVE, MONSTR_TOKEN, WISDEL_TOKEN, WISDEL_SHADOW_CAP, WISDEL_CAMO_RANGE,
  WISDEL_S3_SPLASH, HUANG_BURST_RADIUS, HUANG_RAMP_SEC } = S;

export default (bb, chess, def) => {
    const t0 = talentBb(chess, 0);
    const spAtk = num(t0['amiya_t_1[atk].sp']), spKill = num(t0['amiya_t_1[kill].sp']);
    return {
      skill: {
        kind: 'duration',
        mods: mods({ atkPct: num(bb.atk), hpPct: num(bb.max_hp) }),
        targeting: { rangeGrid: def?.skill?.rangeGrid ?? null },
        attack: { dmgType: 'true' },
        onEnd({ battle, unit }) {
          if (on(unit)) battle.retreat(unit, { reason: 'retreat' });
        },
      },
      talents: [
        { install(battle, unit) { // 情绪吸收
          if (spAtk > 0) battle.on('attack', (c) => { if (c.attacker === unit) unit.skill.gainSp(spAtk, 'talent'); }, { owner: unit });
          if (spKill > 0) battle.on('kill', (c) => { if (c.killer === unit) unit.skill.gainSp(spKill, 'talent'); }, { owner: unit });
        } },
      ],
    };
  }
