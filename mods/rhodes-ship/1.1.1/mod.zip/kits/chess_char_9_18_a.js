// kits/chess_char_9_18_a.js - 同人内容包的行为层 kit（创意工坊 §4：kits/<id>.js，默认导出即 kit 函数）。
//
// 契约与官方内容 server/sim/content/kits/tierN.js 完全一致：返回 { skill?, skills?, talents?, trait?, install? }。
// 引擎按 baseId → id → 去掉 _a/_b 的裸 id 查表，所以一个文件同时覆盖普通与精锐两枚棋子。
//
// 共享辅助（含引擎内部工具函数的逐字复刻）住在 ./lib/_shared.js：被相对 import，所以它自己
// 不写白名单 specifier（loader 只重写顶层 kit 文件里的那些）。
import * as S from './lib/_shared.js';

const { num, on, talentBb, mods, batPct, tokenOf, prostOf, isProstsOf, neighbors, whileOn, inRangeOf,
  skillRec, skillBbOf, COLS, hypot, hasHp, periodicDamage, bodyInKeys, frontOf, sortEnemyTargets,
  PRIO_REVIVE, MONSTR_TOKEN, WISDEL_TOKEN, WISDEL_SHADOW_CAP, WISDEL_CAMO_RANGE,
  WISDEL_S3_SPLASH, HUANG_BURST_RADIUS, HUANG_RAMP_SEC } = S;

export default (bb, chess) => {
    const KALTS_TOKEN = 'token_10002_kalts_mon3tr';
    const atkFrom = num(bb['attack@atk'], 1.6);
    const defUp = num(bb['attack@def'], 1.2);
    const penalty = num(bb['attack@hp_ratio'], 0.5);
    return {
      trait: {
        heal: {
          mode: 'single',
          prefer(battle, unit, cands) { // 优先治疗自身和Mon3tr
            if (cands.includes(unit)) return unit;
            const tk = tokenOf(battle, unit, KALTS_TOKEN);
            return tk && cands.includes(tk) ? tk : null;
          },
        },
      },
      skill: {
        kind: 'duration',
        duration: num(bb.duration, 18),
        onStart(ctx) {
          ctx.unit.mem.kaltsKills = 0;
          ctx.unit.mem.kaltsMelt = 0;
        },
        onTick(ctx) {
          const { battle, unit, dt } = ctx;
          const tk = tokenOf(battle, unit, KALTS_TOKEN);
          if (!tk) return;
          unit.mem.kaltsMelt = num(unit.mem.kaltsMelt) + num(dt);
          if (unit.mem.kaltsMelt < 1) return;
          unit.mem.kaltsMelt = 0;
          // 攻击力从 +160% 逐渐降低至 +0%: re-grant the pair every second at the fraction of the skill left
          const dur = num(unit.skill?.duration, 18);
          const left = Math.max(0, num(unit.skill?.timeLeft, dur));
          const frac = dur > 0 ? left / dur : 0;
          battle.addBuff(tk, {
            key: 'kalts:melt', refresh: 'replace', duration: Math.max(left, 0.1),
            mods: mods({ defPct: defUp, atkPct: atkFrom * frac }), tags: ['skill', 'kalts'],
          });
        },
        onEnd(ctx) {
          const { battle, unit } = ctx;
          if (num(unit.mem.kaltsKills) > 0 || !on(unit)) return; // 技能期间未击杀任何敌人
          const loss = unit.s.maxHp * penalty;
          if (loss > 0) battle.dealDamage(unit, unit, { amount: loss, type: 'true', isSkill: true, tags: ['skill', 'kalts'] });
        },
      },
      talents: [
        { install(battle, unit) { // 天赋1 Mon3tr — Mon3tr不在凯尔希攻击范围内时防御力降至0
          whileOn(battle, unit, 0.25, () => {
            const tk = tokenOf(battle, unit, KALTS_TOKEN);
            if (!tk) return;
            if (inRangeOf(unit, tk)) battle.removeBuff(tk, 'kalts:outrange');
            // a 0.4 s buff refreshed every 0.25 s: it lapses on its own the moment the token is gone / out of reach
            else battle.addBuff(tk, { key: 'kalts:outrange', duration: 0.4, refresh: 'extend', mods: { defPct: -1 }, visible: true, tags: ['talent'] });
          });
        } },
        { install(battle, unit) { // 不毁重构
          battle.on('kill', (c) => {
            const tk = tokenOf(battle, unit, KALTS_TOKEN);
            if (!tk || c.victim !== tk) return;
            if (c.reason === 'retreat' || c.reason === 'expired') return; // 不包括撤退
            if (tk.mem.kaltsKills != null) tk.mem.kaltsKills++;
            if (unit.mem.kaltsKills != null) unit.mem.kaltsKills++;
            for (const e of battle.foesInRadius(tk.tileC, tk.tileR, 1)) {
              if (!e.alive) continue;
              battle.applyStatus(e, 'stun', { duration: 3, source: unit });
              battle.dealDamage(unit, e, { amount: 1200, type: 'true', isSkill: true, tags: ['talent', 'kalts'] });
            }
          }, { owner: unit });
        } },
      ],
      install(battle, unit) { // 指令：熔毁 — "伤害类型变为真实" while the skill runs
        // The 'hit' hook runs before mitigation and the pipeline re-reads `dmg.type` after it (damage.js), so the
        // token's own normal attacks land as 真实伤害 for the skill's duration; a phys/arts one keeps its dodge roll
        // off (真实伤害 is not dodged).
        battle.on('hit', (c) => {
          if (!unit.skill || !unit.skill.active) return;
          if (c.dmg.type !== 'phys' && c.dmg.type !== 'arts') return;
          const tk = tokenOf(battle, unit, KALTS_TOKEN);
          if (!tk || c.source !== tk) return;
          c.dmg.type = 'true';
          c.dmg.canDodge = false;
        }, { owner: unit });
      },
    };
  }
