// kits/chess_char_9_11_a.js - 同人内容包的行为层 kit（创意工坊 §4：kits/<id>.js，默认导出即 kit 函数）。
//
// 契约与官方内容 server/sim/content/kits/tierN.js 完全一致：返回 { skill?, skills?, talents?, trait?, install? }。
// 引擎按 baseId → id → 去掉 _a/_b 的裸 id 查表，所以一个文件同时覆盖普通与精锐两枚棋子。
//
// 共享辅助（含引擎内部工具函数的逐字复刻）住在 ./lib/_shared.js：被相对 import，所以它自己
// 不写白名单 specifier（loader 只重写顶层 kit 文件里的那些）。
import * as S from './lib/_shared.js';

const { num, on, talentBb, mods, batPct, tokenOf, prostOf, isProstsOf, neighbors, whileOn, inRangeOf,
  skillRec, skillBbOf, COLS, hypot, hasHp, periodicDamage, bodyInKeys, frontOf, sortEnemyTargets,
  PRIO_REVIVE, MONSTR_TOKEN, WISDEL_TOKEN, WISDEL_SHADOW_CAP, WISDEL_CAMO_RANGE,
  WISDEL_S3_SPLASH, HUANG_BURST_RADIUS, HUANG_RAMP_SEC } = S;

export default (bb, chess) => {
    const slowBy = Math.min(0.9, Math.abs(num(bb.move_speed)));
    const bindProb = num(bb.prob), bindFor = num(bb.debuff, 1.5);
    const cover = (chess?.talents || []).find((t) => t && t.index === 0) ?? null;
    return {
      skill: { kind: 'duration', mods: mods({ aspd: num(bb.attack_speed) }) },
      talents: [
        { install(battle, unit) { // 掩护打击 (elite only)
          if (!cover) return;
          const bat = num(cover.bb && cover.bb.base_attack_time);
          if (bat) battle.addBuff(unit, { key: 'frostl:cover', mods: { batPct: batPct(bat, chess) }, persist: true, allowDead: true });
          const g = cover.rangeGrid;
          if (Array.isArray(g) && g.length) {
            unit.rangeGrid = g.map((p) => [p[0], p[1]]);
            battle.refreshRange(unit);
          }
        } },
      ],
      install(battle, unit) { // 凝冰枪刃: 每次攻击减速 + 束缚
        battle.on('hit', (c) => {
          if (!unit.skill || !unit.skill.active) return;
          if (c.source !== unit || !c.dmg.isAttack) return;
          if (!c.target || c.target.side !== 'enemy') return;
          if (slowBy > 0) battle.applyStatus(c.target, 'slow', { value: slowBy, duration: bindFor, source: unit });
          if (bindProb > 0 && battle.rng.chance(bindProb)) battle.applyStatus(c.target, 'bind', { duration: bindFor, source: unit });
        }, { owner: unit, priority: 10 });
      },
    };
  }
