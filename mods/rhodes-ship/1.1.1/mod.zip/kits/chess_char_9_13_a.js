// kits/chess_char_9_13_a.js - 同人内容包的行为层 kit（创意工坊 §4：kits/<id>.js，默认导出即 kit 函数）。
//
// 契约与官方内容 server/sim/content/kits/tierN.js 完全一致：返回 { skill?, skills?, talents?, trait?, install? }。
// 引擎按 baseId → id → 去掉 _a/_b 的裸 id 查表，所以一个文件同时覆盖普通与精锐两枚棋子。
//
// 共享辅助（含引擎内部工具函数的逐字复刻）住在 ./lib/_shared.js：被相对 import，所以它自己
// 不写白名单 specifier（loader 只重写顶层 kit 文件里的那些）。
import * as S from './lib/_shared.js';

const { num, on, talentBb, mods, batPct, tokenOf, prostOf, isProstsOf, neighbors, whileOn, inRangeOf,
  skillRec, skillBbOf, COLS, hypot, hasHp, periodicDamage, bodyInKeys, frontOf, sortEnemyTargets,
  PRIO_REVIVE, MONSTR_TOKEN, WISDEL_TOKEN, WISDEL_SHADOW_CAP, WISDEL_CAMO_RANGE,
  WISDEL_S3_SPLASH, HUANG_BURST_RADIUS, HUANG_RAMP_SEC } = S;

export default (bb, chess) => {
    const t0 = talentBb(chess, 0);
    const atk = num(t0.atk), def = num(t0.def);
    return {
      // The record's derived `dmgType` is 'arts' (the trait text mentions 法术), but 驭法铁卫 attacks physically unless a
      // skill runs — the skill's `attack.dmgType` below switches the arts damage on and off with it.
      trait: { dmgType: 'phys' },
      skill: {
        kind: 'duration',
        mods: mods({ atkPct: num(bb.atk) }),
        attack: { dmgType: 'arts', hitAllBlocked: true },
      },
      talents: [
        { install(battle, unit) { // 攻守兼备
          if (!(atk > 0) && !(def > 0)) return;
          battle.addBuff(unit, { key: 'durnar:guard', mods: mods({ atkPct: atk, defPct: def }), persist: true, allowDead: true });
        } },
      ],
    };
  }
