// workshop/rhodes-ship/battle/main.mjs — 罗德岛盟约 / 装备 / 特质的战斗逻辑
// （pack.json.server.battle，docs/WORKSHOP.md §1.15）。
//
// 把 fanpack-rhodes 覆盖包里 server/sim/content/bonds/custom.js 的**罗德岛那一半**与
// server/sim/content/garrisons/custom.js 的**战斗那一半**移植进创意工坊的 server.battle 通道：
// 引擎自己的 data/*.json 与 server/** 一个字节都不改，卸载 = 删文件夹。卡兹戴尔那一半不在这里
// （那是 kazdel-ship 包的事；本包的 bonds.json 没有 kazdelShip）。
//
// 只能 import @battle/（= server/sim/content/support/index.js 的辅助函数）与 @sim/ 两个前缀，所以：
//   * 源石弧的 statWithout 自己内联了一份属性聚合（引擎的 aggregateMods 住在 server/sim/buffs.js，不在白名单里），
//     逐项对齐 units.js 的 _recalc；
//   * 特质（garrisons/custom.js）的准备期那一半在 meta/garrisons.mjs（server.meta 通道）。
//
// 数值全部来自记录黑板，不写字面量。盟约 id / 装备 key / 特质 effect key 与覆盖包逐字一致。

import {
  num, bondRecord, buffParams, buffsOf, bondActive, bondTier, bondLayers, isMember, onField, playerOps,
  itemsOf, itemKeyOf, hasItemKey, passiveBuff, directMods, itemRecord, battleStore,
  unitBonds, gainLayers, coreBondIds, bodyInKeys, garrisonRecord,
} from '@battle/index.js';
import { ELEMENT_GAUGE_MAX } from '@sim/constants.js';

const RHODES = 'rhodesShip';
const RING_KEY = 'chess_item_c_03_e';
const ARC_KEY = 'chess_item_c_04_e';
const CLAW_KEY = 'chess_item_c_05_e';
const CARAPACE_KEY = 'chess_item_4_12_e';
const POLL = 0.25;           // 源石弧「场上总和」重算间隔 (s)
const ARC_SUM_KEY = 'bond:' + RHODES + ':arc:sum';

// =====================================================================================================================
// shared helpers

const fin = (v, d) => (Number.isFinite(v) ? v : d);
/** detmath.powi 的整数次幂（正幂），不引 Math.pow。 */
const powi = (x, n) => { let r = 1; for (let i = 0; i < n; i++) r *= x; return r; };
const isEnemy = (t) => !!t && t.side === 'enemy' && t.alive;
const tagged = (dmg, tag) => !!(dmg && Array.isArray(dmg.tags) && dmg.tags.includes(tag));

/** Bond effect blackboard ({ ...bb, ...bbStr }) (numbers only) or {}. */
const bbOf = (id) => buffParams(bondRecord(id), 'env_gbuff_new') ?? {};

/** { ...bb, ...bbStr } of an item's buff whose bbStr.key is `key`. */
function itemParams(itemId, key) {
  const rec = itemRecord(itemId);
  if (!rec) return null;
  for (const b of buffsOf(rec)) if (b.bbKey === key) return b.p;
  return null;
}

/** The equipped id of an item family on `u` (any quality), or null. */
const itemIdOf = (u, key) => itemsOf(u).find((x) => itemKeyOf(x) === key) ?? null;

/** server/sim/buffs.js aggregateMods 的最小复刻（只用于 statWithout；*Mul 按层数次幂）。 */
function aggregate(buffs, skip) {
  const add = Object.create(null), mul = Object.create(null);
  for (const b of buffs) {
    if (skip(b)) continue;
    const m = b.mods;
    if (!m) continue;
    const st = b.stacks || 1;
    for (const k in m) {
      const v = m[k];
      if (typeof v !== 'number' || !Number.isFinite(v)) continue;
      if (k === 'shield') continue;
      if (k.endsWith('Mul')) mul[k] = (mul[k] ?? 1) * (st === 1 ? v : powi(v, st));
      else add[k] = (add[k] ?? 0) + v * st;
    }
  }
  return { add, mul };
}

/** Did any of `srcs` grant `b`? The engine's `source` unit, or the `data.src` marker the 鼓舞 auras carry. */
function fromAny(b, srcs, srcIds) {
  if (!b) return false;
  if (srcs.has(b.source)) return true;
  const d = b.data && b.data.src;
  return srcs.has(d) || srcIds.has(d);
}

/**
 * `u`'s ATK / max HP as if every buff granted by one of `srcs` were absent (mirrors units.js _recalc).
 *
 * 源石弧的「场上总和」不能读回携带者自己发出去的属性：魔王 S3 的血量鼓舞是「她最大生命的 65 %」，
 * 实时读 o.s.maxHp 会构成 弧 -> 她的最大生命 -> 鼓舞 -> 场上总和 -> 弧 的正反馈（范围内干员越多涨得越快）。
 * 摘掉携带者发的 buff 就切断这条回路；盟约 / 装备 / 其它干员的 buff 照常计入。
 */
function statWithout(u, stat, srcs, srcIds) {
  const { add, mul } = aggregate(u.buffs, (b) => fromAny(b, srcs, srcIds));
  const b = u.base;
  const cm = u.cultMul || null;
  if (stat === 'maxHp') {
    const bHp = fin(b.maxHp, 1) > 0 ? fin(b.maxHp, 1) : 1;
    const v = (bHp + fin(add.hpFlat, 0)) * Math.max(0, 1 + fin(add.hpPct, 0)) * fin(mul.hpMul, 1) * fin(cm && cm.hp, 1);
    return Math.max(1, fin(v, bHp));
  }
  const v = ((fin(b.atk, 0) + fin(add.atkFlat, 0)) * Math.max(0, 1 + fin(add.atkPct, 0)) + fin(add.atkFinal, 0)) * fin(mul.atkMul, 1) * fin(cm && cm.atk, 1);
  return Math.max(0, fin(v, fin(b.atk, 0)));
}

/** 鼓舞（引擎判据：key/status 带 inspire）——与 kits 里 inspire() 写的是同一套键。 */
const isInspireBuff = (b) => !!b && (b.key === 'inspire' || b.status === 'inspire'
  || b.key.startsWith('inspire:') || b.key.endsWith(':inspire'));

/**
 * `u` 身上**不是携带者发的、但派生自别人当前属性**的那部分 stat（鼓舞 / 另一个携带者的弧 grant），
 * 换算到最终值域。`statWithout` 只摘「携带者自己发出去的」；第三方转一手的那条边靠这一层。
 * Σ 只开局读一次之后它已不是必需，留着当纵深防御。
 */
function nestedStat(u, stat, srcs, srcIds) {
  const flatKey = stat === 'maxHp' ? 'hpFlat' : 'atkFlat';
  let flat = 0;
  for (const b of u.buffs ?? []) {
    if (!b.mods || fromAny(b, srcs, srcIds)) continue;       // 携带者发的已经不在 statWithout 里了
    if (b.key !== ARC_SUM_KEY && !isInspireBuff(b)) continue;
    const v = b.mods[flatKey];
    if (typeof v === 'number' && Number.isFinite(v)) flat += v * (b.stacks || 1);
  }
  if (!flat) return 0;
  const { add, mul } = aggregate(u.buffs, () => false);
  const f = stat === 'maxHp'
    ? Math.max(0, 1 + fin(add.hpPct, 0)) * fin(mul.hpMul, 1) * fin(u.cultMul && u.cultMul.hp, 1)
    : Math.max(0, 1 + fin(add.atkPct, 0)) * fin(mul.atkMul, 1) * fin(u.cultMul && u.cultMul.atk, 1);
  return flat * f;
}

/** Has `pid` reached `cnt` distinct members (count, else the tier index) — mirrors bonds/core.js reached. */
function reachedCount(battle, pid, bondId, cnt) {
  const st = battle.getPlayer(pid)?.bonds?.[bondId];
  if (!st || !st.active) return false;
  const need = num(cnt, 0);
  if (!(need > 0)) return true;
  if (num(st.count, 0) >= need) return true;
  const th = bondRecord(bondId)?.thresholds;
  const idx = Array.isArray(th) ? th.indexOf(need) : -1;
  return idx >= 0 && num(st.tier, 0) >= idx + 1;
}

// =====================================================================================================================
// install

export function install(battle) {
  if (!battle || !Array.isArray(battle.players)) return;
  const guard = battleStore(battle, 'rhodes-ship:battle', () => ({ installed: false }));
  if (guard.installed) return;
  guard.installed = true;
  installBonds(battle);
  installTraits(battle);
}

/** 罗德岛盟约本体 + 它的装备的条件部分。 */
function installBonds(battle) {
  for (const p of battle.players) {
    const pid = p.playerId;
    const ops = playerOps(battle, pid);

    if (bondActive(battle, pid, RHODES)) {
      const bb = bbOf(RHODES);
      const members = ops.filter((u) => isMember(battle, u, RHODES));
      const live = () => {
        const L = bondLayers(battle, pid, RHODES);
        const mods = directMods({
          atk: num(bb.base_atk) + num(bb.atk_per_stack) * L,
          hp: num(bb.base_max_hp) + num(bb.max_hp_per_stack) * L,
        });
        for (const u of members) passiveBuff(battle, u, 'bond:' + RHODES, mods);
      };
      if (members.length) {
        live();
        battle.on('layerGain', (c) => {
          if (c && c.playerId === pid && c.bondId === RHODES) battle.after(0, live);
        });
      }
      const six = bondTier(battle, pid, RHODES) >= 2 || reachedCount(battle, pid, RHODES, bb.power_bond_char_cnt);
      if (six && members.length) {
        const healMul = 1 + num(bb.heal_scale);
        for (const u of members) if (healMul !== 1) passiveBuff(battle, u, 'bond:' + RHODES + ':heal', { healingTakenMul: healMul });
        const spIv = num(bb.sp_interval, 2), spN = num(bb.sp_per_interval, 1);
        if (spIv > 0 && spN > 0) {
          battle.every(spIv, () => {
            for (const u of members) if (onField(u) && u.skill) u.skill.gainSp(spN, 'bond');
          });
        }
        const hpPct = num(bb.regen_hp_scale), elPct = num(bb.regen_element_scale);
        // regen_hp_scale 是 生命回复速度, not 治疗: an hpRegenRatio buff the engine ticks itself.
        for (const u of members) if (hpPct > 0) passiveBuff(battle, u, 'bond:' + RHODES + ':regen', { hpRegenRatio: hpPct });
        if (elPct > 0) {
          battle.every(1, () => {
            for (const u of members) if (onField(u)) battle.reduceElement(u, elPct * ELEMENT_GAUGE_MAX);
          });
        }
      }
    }

    installItems(battle, pid, ops);
  }
}

function installItems(battle, pid, ops) {
  const has = (u, key) => hasItemKey(u, key);

  // 罗德岛抑制环: 元素损伤 reduction
  for (const u of ops) {
    if (!has(u, RING_KEY)) continue;
    const p = itemParams(itemIdOf(u, RING_KEY), 'act2autochess_equip_custom_rhodes_ring');
    const cut = num(p?.elem_taken);
    if (cut > 0) passiveBuff(battle, u, 'bond:' + RHODES + ':ring', { elemTakenMul: Math.max(0.05, 1 - cut) });
  }

  // 罗德岛特制源石弧
  /** Carriers of the arc's 场上总和 leg, { u, share } — their grant is written after this loop (see below). */
  const arcCarriers = [];
  for (const u of ops) {
    if (!has(u, ARC_KEY)) continue;
    const id = itemIdOf(u, ARC_KEY);
    const p = itemParams(id, 'act2autochess_equip_custom_rhodes_arc');
    if (!p) continue;
    const taken = num(p.damage_taken);
    if (taken > 0) passiveBuff(battle, u, 'bond:' + RHODES + ':arc:taken', { dmgTakenMul: Math.max(0.05, 1 - taken) });
    const member = isMember(battle, u, RHODES);
    const share = num(p.field_sum_share);
    // [ASSUMED] "攻击力和生命总和的X%加成" = X% of the on-field operators' summed ATK / max HP, granted as flat stats.
    // The grant is written after this loop, in one pass over the player's carriers (see below).
    if (member && share > 0) arcCarriers.push({ u, share });
    // 抑制环 synergy: the arc's whole 属性提升效果 is shared with the field (the carrier already has the taken part).
    if (member && has(u, RING_KEY)) {
      const base = itemParams(id, 'attr_common_global_buff');
      const atk = num(base?.atk), hp = num(base?.max_hp);
      if (atk > 0 || hp > 0 || taken > 0) {
        const mods = directMods({ atk, hp });
        const shared = taken > 0 ? { ...mods, dmgTakenMul: Math.max(0.05, 1 - taken) } : mods;
        const apply = () => { for (const o of ops) if (onField(o)) passiveBuff(battle, o, 'bond:' + RHODES + ':arc:share', o === u ? mods : shared); };
        apply();
        battle.on('battleStart', apply);
        battle.on('deploy', () => battle.after(0, apply));
        battle.every(POLL, apply);
      }
    }
  }

  // 源石弧的「场上总和」腿：**只开局记录一次**（业主裁决 2026-10-15，见 源石弧-同类递归审计.md）。
  //
  // 每一次重读都是一条回边：「携带者当前属性 → 它发给友军的鼓舞 → 友军当前属性 → Σ → 携带者的弧 grant →
  // 携带者当前属性」。浊心斯卡蒂 / 魔王 / 三角初华的鼓舞都是「自身当前攻击力 / 最大生命」的函数 —— 只要 Σ
  // 每 0.25 s 重读一次，这条环就在（2026-10-15 实测：浊心斯卡蒂 + 罗德岛盟约 + 源石弧 数值飙升）。一次性读值
  // 没有回边：开场那一刻场上还没有任何鼓舞，读到就是各干员自身的数值（同 炎 yanShip 6 层的写法）。
  //
  // statWithout（摘掉携带者自己发出去的 buff）与 nestedStat（剔掉第三方转一手的鼓舞 / 别的弧 grant）都保留为
  // 纵深防御：前者管「携带者 ↔ 携带者」，后者管「第三方转一手」。
  // 代价（字面结果）：中途部署的干员不计入 Σ；阵亡 / 复活也不重算。
  if (arcCarriers.length) {
    const apply = () => {
      const live = arcCarriers.filter((c) => onField(c.u));
      for (const c of live) battle.removeBuff(c.u, ARC_SUM_KEY);
      if (!live.length) return;
      const srcs = new Set(live.map((c) => c.u));
      const srcIds = new Set(live.map((c) => c.u.id));
      for (const c of live) {
        let atk = 0, hp = 0;
        for (const o of battle.allies()) {
          if (o === c.u || o.kind !== 'op' || !onField(o)) continue;
          atk += Math.max(0, statWithout(o, 'atk', srcs, srcIds) - nestedStat(o, 'atk', srcs, srcIds));
          hp += Math.max(0, statWithout(o, 'maxHp', srcs, srcIds) - nestedStat(o, 'maxHp', srcs, srcIds));
        }
        passiveBuff(battle, c.u, ARC_SUM_KEY, { atkFlat: c.share * atk, hpFlat: c.share * hp });
      }
    };
    battle.on('battleStart', apply, { once: true });
  }

  // M3利爪 (custom) + M3茧甲 / M3护甲 (official, chess_item_4_12_e): attacks carry atk_scale x ATK as true damage.
  for (const u of ops) {
    if (!has(u, CLAW_KEY) || !has(u, CARAPACE_KEY)) continue;
    const p = itemParams(itemIdOf(u, CLAW_KEY), 'act2autochess_equip_custom_m3_claw');
    const scale = num(p?.atk_scale);
    if (!(scale > 0)) continue;
    battle.on('damaged', (c) => {
      const s = c.source, t = c.target, dmg = c.dmg;
      if (s !== u || !dmg || !dmg.isAttack || !isEnemy(t)) return;
      if (tagged(dmg, 'item:m3claw')) return;
      battle.dealDamage(u, t, { amount: scale * u.s.atk, type: 'true', canDodge: false, tags: ['item:m3claw'] });
    });
  }
}

// =====================================================================================================================
// 特质（garrisons/custom.js 的战斗那一半）

const TKEY = Object.freeze({
  FIRST_SKILL: 'custom_gain_first_skill',
  ON_SKILL: 'custom_gain_on_skill',
  ON_HEAL: 'custom_gain_on_heal',
  ON_HURT: 'custom_gain_on_hurt_or_heal',
  ON_KILLS: 'custom_gain_on_kills',
  ON_CONTROLLED: 'custom_gain_on_controlled',
  ON_NEW_TARGET: 'custom_gain_on_new_target',
  SCALE_BONDS: 'custom_scale_bonds_layers',
});
const CONTROLLED_POLL = 1; // s — 维什戴尔's 每有一个敌人处于眩晕、束缚时 +1 层

/** The custom garrison records of a unit (empty for the official pool). */
function garrisonsOf(u) {
  const list = u?.def?.raw?.garrisonIds ?? u?.def?.garrisonIds;
  if (!Array.isArray(list) || !list.length) return [];
  const out = [];
  for (const id of list) {
    const g = garrisonRecord(id);
    if (g && g.bbStr && typeof g.bbStr.key === 'string' && g.bbStr.key.startsWith('custom_')) out.push(g);
  }
  return out;
}

/** Enemy under 眩晕 / 停顿 / 束缚 / 不动. */
function controlled(t) {
  if (!t || !t.findBuff) return false;
  const f = t.s && t.s.flags;
  if (f && (f.stun || f.bind || f.immobile || f.rooted)) return true;
  return !!(t.findBuff('stun') || t.findBuff('sluggish') || t.findBuff('bind') || t.findBuff('immobile'));
}

const idsOf = (s) => String(s ?? '').split(',').map((x) => x.trim()).filter(Boolean);

function installTraits(battle) {
  /** Every operator of every player that carries a custom trait, with its records. */
  const owners = [];
  for (const p of battle.players || []) {
    for (const u of playerOps(battle, p.playerId)) {
      const gs = garrisonsOf(u);
      if (gs.length) owners.push({ u, gs });
    }
  }
  if (!owners.length) return;

  const byKey = new Map();
  for (const o of owners) {
    for (const g of o.gs) {
      const k = g.bbStr.key;
      if (!byKey.has(k)) byKey.set(k, []);
      byKey.get(k).push({ u: o.u, g, bb: g.bb || {} });
    }
  }
  const has = (k) => byKey.has(k);
  const gain = (u, bonds, n, cap, capKey) => gainLayers(battle, {
    playerId: u.ownerId, bonds, n, requireActive: true, source: u, reason: 'garrison',
    cap: Number.isFinite(cap) ? cap : Infinity, capKey: capKey ? capKey + ':' + (u.uid ?? u.defId) : null,
  });
  const isOp = (u) => !!u && u.kind === 'op';
  /** The owner's own bonds that are active right now. */
  const ownActiveBonds = (u) => unitBonds(u).filter((b) => bondActive(battle, u.ownerId, b));

  // ---- skill casts ------------------------------------------------------------------------------------------------
  if (has(TKEY.FIRST_SKILL) || has(TKEY.ON_SKILL)) {
    battle.on('skillStart', ({ unit }) => {
      if (!isOp(unit)) return;
      for (const rec of byKey.get(TKEY.FIRST_SKILL) || []) {
        if (rec.u !== unit || unit.mem.customFirstSkill) continue;
        unit.mem.customFirstSkill = true;
        gain(unit, ownActiveBonds(unit), num(rec.bb.gain), Infinity, null);
      }
      for (const rec of byKey.get(TKEY.ON_SKILL) || []) {
        if (rec.u !== unit) continue;
        gain(unit, ownActiveBonds(unit), num(rec.bb.gain), Infinity, null);
      }
    });
  }

  // ---- healing ----------------------------------------------------------------------------------------------------
  if (has(TKEY.ON_HEAL) || has(TKEY.ON_HURT)) {
    battle.on('heal', (c) => {
      const src = c.source, tgt = c.target;
      if (!isOp(tgt) || !(num(c.amount) > 0)) return;
      for (const rec of byKey.get(TKEY.ON_HEAL) || []) {
        if (rec.u !== src) continue;
        gain(rec.u, ownActiveBonds(rec.u), num(rec.bb.gain), num(rec.bb.max, Infinity), TKEY.ON_HEAL);
      }
      for (const rec of byKey.get(TKEY.ON_HURT) || []) {
        if (rec.u !== tgt) continue;
        gain(rec.u, ownActiveBonds(rec.u), num(rec.bb.gain), num(rec.bb.max, Infinity), TKEY.ON_HURT);
      }
    });
    battle.on('damaged', (c) => {
      const tgt = c.target, dmg = c.dmg;
      if (!isOp(tgt) || !dmg || dmg.cancelled) return;
      for (const rec of byKey.get(TKEY.ON_HURT) || []) {
        if (rec.u !== tgt) continue;
        gain(rec.u, ownActiveBonds(rec.u), num(rec.bb.gain), num(rec.bb.max, Infinity), TKEY.ON_HURT);
      }
    });
  }

  // ---- kills in range (阿斯卡纶) ----------------------------------------------------------------------------------
  if (has(TKEY.ON_KILLS)) {
    battle.on('death', (c) => {
      const victim = c.unit;
      if (!victim || victim.side !== 'enemy') return;
      for (const rec of byKey.get(TKEY.ON_KILLS) || []) {
        const u = rec.u;
        if (!onField(u)) continue;
        const keys = Array.isArray(u.rangeKeys) ? u.rangeKeys : [];
        if (!keys.length) continue;
        // death fires once the victim is already dead, so a live-target query never lists it: ask its BODY instead.
        if (!bodyInKeys(victim, keys)) continue;
        u.mem[TKEY.ON_KILLS + ':n'] = (u.mem[TKEY.ON_KILLS + ':n'] ?? 0) + 1;
        const per = Math.max(1, num(rec.bb.per_kills, 2));
        if (u.mem[TKEY.ON_KILLS + ':n'] % per) continue;
        gain(u, ownActiveBonds(u), num(rec.bb.gain), num(rec.bb.max, Infinity), TKEY.ON_KILLS);
      }
    });
  }

  // ---- controlled enemies in range (维什戴尔) ---------------------------------------------------------------------
  if (has(TKEY.ON_CONTROLLED)) {
    const list = byKey.get(TKEY.ON_CONTROLLED);
    battle.every(CONTROLLED_POLL, () => {
      for (const rec of list) {
        const u = rec.u;
        if (!onField(u)) continue;
        const keys = Array.isArray(u.rangeKeys) ? u.rangeKeys : [];
        if (!keys.length) continue;
        for (const e of battle.enemiesInKeys(keys, u, u.profile)) {
          if (!controlled(e)) continue;
          gain(u, ['kazdelShip'], num(rec.bb.gain), Infinity, null);
        }
      }
    });
  }

  // ---- attacking a new enemy (霜叶) -------------------------------------------------------------------------------
  if (has(TKEY.ON_NEW_TARGET)) {
    const list = byKey.get(TKEY.ON_NEW_TARGET);
    battle.on('damaged', (c) => {
      const u = c.source, t = c.target, dmg = c.dmg;
      if (!dmg || !dmg.isAttack || !t || t.side !== 'enemy') return;
      for (const rec of list) {
        if (rec.u !== u) continue;
        const seen = (u.mem.customTargets ??= new Set());
        const key = t.uid ?? t.id;
        if (seen.has(key)) continue;
        seen.add(key);
        gain(u, ['rhodesShip'], num(rec.bb.gain), num(rec.bb.max, Infinity), TKEY.ON_NEW_TARGET);
      }
    });
  }

  // ---- layer scaling (逻各斯) -------------------------------------------------------------------------------------
  const scalers = byKey.get(TKEY.SCALE_BONDS) || [];
  if (scalers.length) {
    const apply = (rec) => {
      const u = rec.u;
      // the core bonds PLUS the extras listed in the record's bbStr.bonds (逻各斯: 核心盟约和【远见】每叠加3层).
      const bonds = [...coreBondIds(), ...idsOf(rec.g.bbStr?.bonds ?? '')];
      let layers = 0;
      for (const b of bonds) if (bondActive(battle, u.ownerId, b)) layers += bondLayers(battle, u.ownerId, b);
      const per = Math.max(1, num(rec.bb.per_layers, 3));
      const steps = Math.floor(layers / per);
      if (!(steps > 0)) { battle.removeBuff(u, 'gar:' + rec.g.garrisonId); return; }
      const mods = directMods({ atk: num(rec.bb.atk) * steps, hp: num(rec.bb.hp) * steps });
      passiveBuff(battle, u, 'gar:' + rec.g.garrisonId, mods);
    };
    for (const rec of scalers) apply(rec);
    battle.on('layerGain', () => {
      // the gain is recorded AFTER the hook — re-read the live layers next tick (bonds/core.js does the same)
      for (const rec of scalers) battle.after(0, () => apply(rec));
    });
    battle.on('deploy', () => {
      for (const rec of scalers) apply(rec);
    });
  }
}
