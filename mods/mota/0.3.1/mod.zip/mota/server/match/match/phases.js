// server/match/match/phases.js — Match methods: the round flow up to the prep — INFO_CHECK, the strategy draft
// (BAND_DRAFT: one countdown of BAND_TURN_SECONDS per turn, 队友已选, the highlighted strategy on a timeout, skips),
// BATTLE_CHECK and ROUND_START (the round's enemies — a normal wave or the boss pairing — planned before the players'
// round start).
// Installed on Match.prototype by server/match/Match.js (a method container: never instantiated; `this` is the match).

import { PHASE, ERR } from '../../../shared/constants.js';
import { msg } from '../../../shared/i18n.js';
import { buildNormalWave, buildBossWave } from '../waves.js';
import { layoutOf } from '../../../shared/layout.js';
import { pairPlayers } from '../finalAssault.js';
import { createRng, deriveSeed } from '../../sim/rng.js';
import { botPickBand } from '../bot.js';
import { OK, fail, DELAYS, BAND_TURN_SECONDS } from './common.js';

/**
 * 「试玩时直接发到手上」—— 哪些干员要在第一回合进手牌（业主 2026-10-08 提的开关）。
 *
 * 为什么只在试玩里生效：工坊/助战干员的正规来路是**商店**（0.5.0 起「不白送」，见 docs/WORKSHOP.md §2.3），
 * 直接把牌塞进手里会让正式对局的规则变形。作者真正要的是「试玩时立刻拿它开一局」，所以这里读的是编辑器
 * spawn 出来的那个一次性服务器进程的环境变量（`SP_PLAYTEST=1`，editor/playtest.mjs 设的）：
 * **正式服务器一个都不发** —— 即使装了一个声明了这个开关的包，`SP_PLAYTEST` 也不是 `1`。
 *
 * 名单是**两个来源的并集**：
 *   ① 记录里自带 `directToHand: true` 的（非覆盖的工坊件；今天的写法，向后兼容，一个字都没改）；
 *   ② `pack.json.playtest.directToHand` 声明的（覆盖模式靠这条 —— 覆盖时记录必须与官方同形，
 *      `directToHand` 那个键写不进去，见 editor/server.mjs 的 `stripEditorOnlyKeys`）。
 * ②由编辑器在 `/api/playtest/start` 算出来，经 `SP_DIRECT_TO_HAND=<逗号分隔 id>` 交给子进程（与 `SP_STAGE` 同一条路）。
 *
 * 名单里一个 `visibleChess` 里没有的 id 只是**不出现在结果里**，不抛错：那是声明侧该拦的事
 * （`PLAYTEST_UNKNOWN_CHESS`），引擎不该为了一个坏 id 把一局打不开。
 *
 * 取牌走 `PlayerState.poolOf` —— 唯一分派点（design-level A, docs/PS100-MIGRATION.md §10-A）：`≤ MAX_SEATS` 时它就是共享池
 * （同一个 `m.pool` 对象），座位变体打开时是本玩家自己的池。两种情况下「池里那一份」都是真的被拿走的 —— 与开局礼包不同，
 * 这里不会凭空多出一份拷贝。
 * @param {object} gd 这一局的 GameData
 * @param {Record<string, string|undefined>} [env] 默认 `process.env`（单测直接喂一个假环境）
 * @returns {string[]} 可见、非精锐、且被两个来源之一点名的干员 id
 */
export function directToHandIds(gd, env = process.env) {
  if (String((env && env.SP_PLAYTEST) || '') !== '1') return [];
  const fromEnv = new Set(
    String((env && env.SP_DIRECT_TO_HAND) || '').split(',').map((s) => s.trim()).filter(Boolean),
  );
  return ((gd && gd.visibleChess) || []).filter((id) => {
    const rec = gd.chess(id);
    if (!rec || rec.isGolden) return false;
    return rec.directToHand === true || fromEnv.has(id);
  });
}

export class MatchPhases {
  enterInfoCheck() {
    this.phase = PHASE.INFO_CHECK;
    for (const ps of this.order) if (ps.botControlled) ps.infoReady = true;
    // solo: no time limit (the player confirms); co-op: the official 25 s guard
    this.setDeadline(this.soloUntimed ? 0 : this.gd.timer('infoCheck'), () => this.enterBandDraft());
    this.markPublic();
    for (const ps of this.order) this.markPrivate(ps);
    this.flush(true);
    this.maybeEndInfo();
  }

  maybeEndInfo() {
    if (this.phase !== PHASE.INFO_CHECK || this.setupVote || this._infoAdvanceTimer) return;
    if (this.order.every((p) => p.isBot || p.left || p.infoReady)) {
      this.setDeadline(0);
      this._infoAdvanceTimer = this.later(0, () => {
        this._infoAdvanceTimer = null;
        if (this.phase === PHASE.INFO_CHECK && !this.setupVote) this.enterBandDraft();
      });
    }
  }

  /**
   * The strategy draft (user playtest #4 item 4): ONE countdown — every turn has the same clock, BAND_TURN_SECONDS, and
   * m.public.deadline is the current turn's end (= draft.turnDeadline; the step header and the turn indicator show the
   * same number). No separate step cap: the turns bound the step (≤ (seats + skips) × turn). AI seats pick at once. A
   * turn that runs out takes the strategy the player has highlighted (g.bandFocus) while it is free, else the default
   * (timeoutBand). Solo, and any single-human match (soloUntimed): untimed. Solo also keeps seat order and has no skip.
   */
  enterBandDraft() {
    if (this.phase !== PHASE.INFO_CHECK) return;
    this.phase = PHASE.BAND_DRAFT;
    let order = this.order.map((p) => p.playerId);
    if (!this.isSolo) this.rngDraft.shuffle(order);
    order = this.humansFirst(order);
    const skips = this.isSolo ? 0 : this.gd.bandDraft.skipsPerPlayer;
    const untimed = this.soloUntimed;
    this.draft = {
      order, idx: 0, picks: {}, skipsLeft: Object.fromEntries(order.map((pid) => [pid, skips])), untimed, turnDeadline: 0,
      /** playerId → the strategy highlighted in the draft screen (g.bandFocus) */
      focus: new Map(),
    };
    this.setDeadline(0);
    this.startDraftTurn();
    this.markPublic();
  }

  /**
   * The co-op room option 「AI 队友最后选择」 (this.aiPicksLast, GitHub #338): every human seat before every AI seat, each
   * group in the order the draft drew (a stable partition applied AFTER the shuffle — no extra random draw: the order
   * with the option off is unchanged, and with it on every random stream stands where it would without it; only the
   * picks made in the new order can differ). A human is any seat that is not an AI seat (room.addBot): under AI 托管,
   * disconnected or departed it still counts as a human. Used by the strategy draft and the 机变 draft
   * (MatchSpDraft.enterSpDraft).
   * @param {string[]} order playerIds in drawn order
   * @returns {string[]}
   */
  humansFirst(order) {
    if (!this.aiPicksLast) return order;
    const bot = (pid) => !!this.players.get(pid)?.isBot;
    return [...order.filter((pid) => !bot(pid)), ...order.filter(bot)];
  }

  draftTurn() {
    const d = this.draft;
    if (!d) return null;
    return d.order[d.idx] ?? null;
  }

  /** Real ms of one strategy-draft turn (BAND_TURN_SECONDS × timerScale). */
  bandTurnMs() { return this.scaled(BAND_TURN_SECONDS * 1000); }

  startDraftTurn() {
    const d = this.draft;
    this.cancel(this._turnTimer);
    this._turnTimer = null;
    if (this.test) this.setDeadline(0);
    while (d.idx < d.order.length && d.picks[d.order[d.idx]]) d.idx++; // loop-cap: draft order
    if (d.idx >= d.order.length) {
      d.turnDeadline = 0;
      this.deadline = 0;
      this.later(0, () => this.finishBandDraft(false));
      return;
    }
    const token = ++this._turnToken;
    if (!d.untimed) {
      const ms = this.bandTurnMs();
      d.turnDeadline = this.sched.now() + ms;
      // the step's countdown IS the turn's (one number everywhere)
      this.deadline = d.turnDeadline;
      const expire = () => {
        if (this.phase !== PHASE.BAND_DRAFT || token !== this._turnToken) return;
        const pid = this.draftTurn();
        if (pid) this._applyBand(this.players.get(pid), this.timeoutBand(pid));
      };
      if (this.test) { this.setDeadline(ms / 1000 / (this.timerScale || 1), expire); d.turnDeadline = this.deadline; }
      else this._turnTimer = this.later(ms, expire);
    } else {
      d.turnDeadline = 0;
      this.deadline = 0;
    }
    const cur = this.players.get(this.draftTurn());
    if (cur && cur.botControlled) this.scheduleBandBot();
    this.markPublic();
  }

  /** An AI seat's (or an AI 托管 seat's) turn: it picks at once (user playtest #4 item 4 — nobody waits on the AI). */
  scheduleBandBot() {
    const token = this._turnToken;
    this.later(0, () => {
      if (this.phase !== PHASE.BAND_DRAFT || token !== this._turnToken) return;
      const ps = this.players.get(this.draftTurn());
      if (!ps || !ps.botControlled) return;
      // a strategy a teammate already took is not selectable (队友已选): the bot re-draws, else the first free one
      let id = botPickBand(this, ps);
      for (let k = 0; k < 8 && this.bandTaken(id, ps.playerId); k++) id = botPickBand(this, ps);
      if (this.bandTaken(id, ps.playerId)) id = this.gd.bandIds().find((b) => !this.bandTaken(b, ps.playerId)) || id;
      this._applyBand(ps, id, { dedupe: true });
    });
  }

  /**
   * Whether `bandId` was already picked by another player of this draft. Research 09 §5 / DESIGN §14 corrections:
   * the strategy draft marks a teammate's pick as 队友已选 and it cannot be chosen again (co-op). The automatic
   * assignments — a turn that runs out and a departing seat — obey the same rule: see timeoutBand / defaultBand.
   */
  bandTaken(bandId, playerId) {
    const picks = this.draft?.picks || {};
    for (const [pid, id] of Object.entries(picks)) if (pid !== playerId && id === bandId) return true;
    return false;
  }

  /**
   * The strategy an automatic assignment gives `playerId` (a departing seat; a timed-out turn without a usable
   * highlight, timeoutBand): the official default 「华法琳」 (bandDraft.timeoutBandId) while no teammate holds it, else the
   * first strategy of the mode (sortId order, gd.bandIds) that nobody else picked — never a duplicate (队友已选; the
   * client shows the same choice: public/js/screens/bandDraft.js timeoutBand). Solo drafts have no teammates, so it is
   * always the default.
   * @param {string} playerId
   */
  defaultBand(playerId) {
    const def = this.gd.bandDraft.timeoutBandId;
    if (!this.bandTaken(def, playerId)) return def;
    return this.gd.bandIds().find((b) => !this.bandTaken(b, playerId)) || def;
  }

  /**
   * What a turn that runs out assigns (user playtest #4 item 4): the strategy the player has highlighted in the draft
   * screen (g.bandFocus — the detail pane's band, the one 确认选择 would take) while it is allowed and no teammate holds
   * it, else defaultBand.
   * @param {string} playerId
   */
  timeoutBand(playerId) {
    const f = this.draft && this.draft.focus instanceof Map ? this.draft.focus.get(playerId) : null;
    if (typeof f === 'string' && this.gd.bandAllowed(f) && !this.bandTaken(f, playerId)) return f;
    return this.defaultBand(playerId);
  }

  /**
   * g.bandFocus { bandId? }: the strategy the player highlights in the draft screen (any time before its pick; also
   * while waiting for its turn). A missing / null bandId clears it. Only a timed-out turn reads it (timeoutBand).
   */
  bandFocus(ps, bandId) {
    if (this.phase !== PHASE.BAND_DRAFT || !this.draft) return fail(ERR.WRONG_PHASE);
    const d = this.draft;
    if (d.picks[ps.playerId]) return fail(ERR.ALREADY);
    if (!(d.focus instanceof Map)) d.focus = new Map();
    if (bandId == null) { d.focus.delete(ps.playerId); return OK; }
    if (typeof bandId !== 'string' || !this.gd.bandAllowed(bandId)) return fail(ERR.BAD_TARGET);
    d.focus.set(ps.playerId, bandId);
    return OK;
  }

  pickBand(ps, bandId) {
    if (this.phase !== PHASE.BAND_DRAFT || !this.draft) return fail(ERR.WRONG_PHASE);
    if (this.draft.picks[ps.playerId]) return fail(ERR.ALREADY);
    if (this.draftTurn() !== ps.playerId) return fail(ERR.NOT_YOUR_TURN);
    if (typeof bandId !== 'string' || !this.gd.bandAllowed(bandId)) return fail(ERR.BAD_TARGET);
    if (this.bandTaken(bandId, ps.playerId)) return fail(ERR.BAD_TARGET, '队友已选'); // i18n-ignore: developer detail (players see ERR_TEXT)
    this._applyBand(ps, bandId);
    return OK;
  }

  _applyBand(ps, bandId, { dedupe = false } = {}) {
    const d = this.draft;
    if (!d || !ps || d.picks[ps.playerId]) return;
    let id = this.gd.bandAllowed(bandId) ? bandId : this.defaultBand(ps.playerId);
    if (dedupe && this.bandTaken(id, ps.playerId)) id = this.gd.bandIds().find((b) => !this.bandTaken(b, ps.playerId)) || id;
    d.picks[ps.playerId] = id;
    ps.bandId = id;
    ps.lp = this.gd.startLp(id);
    this.markPrivate(ps);
    this.markPublic();
    this.startDraftTurn();
  }

  skipBand(ps) {
    if (this.phase !== PHASE.BAND_DRAFT || !this.draft) return fail(ERR.WRONG_PHASE);
    const d = this.draft;
    if (this.isSolo) return fail(ERR.WRONG_PHASE, 'no skip in solo');
    if (d.picks[ps.playerId]) return fail(ERR.ALREADY);
    if (this.draftTurn() !== ps.playerId) return fail(ERR.NOT_YOUR_TURN);
    if (!(d.skipsLeft[ps.playerId] > 0)) return fail(ERR.ALREADY, 'no skip left');
    if (d.order.length - d.idx <= 1) return fail(ERR.BAD_TARGET, 'nobody to pass to');
    d.skipsLeft[ps.playerId]--;
    d.order.splice(d.idx, 1);
    // the skipper goes to the end; with 「AI 队友最后选择」 to the end of the humans still to pick — behind them, ahead of
    // the AI seats — and to the very end only when no other human is left to pass to [ASSUMED: the option's intent,
    // humans before AI, kept through a skip; no source, a remake option]
    let at = d.order.length;
    if (this.aiPicksLast) {
      for (let j = d.order.length - 1; j >= d.idx; j--) {
        if (!this.players.get(d.order[j])?.isBot) { at = j + 1; break; }
      }
    }
    d.order.splice(at, 0, ps.playerId);
    this.startDraftTurn();
    return OK;
  }

  finishBandDraft(timeout) {
    if (this.phase !== PHASE.BAND_DRAFT) return;
    this.cancel(this._turnTimer);
    this._turnTimer = null;
    for (const ps of this.order) {
      if (!this.draft.picks[ps.playerId]) {
        // one after another in seat order, so each default sees the ones assigned before it (no duplicates)
        const id = this.defaultBand(ps.playerId);
        this.draft.picks[ps.playerId] = id;
        ps.bandId = id;
        ps.lp = this.gd.startLp(id);
      }
      this.markPrivate(ps);
    }
    void timeout;
    this.initTeamHp();   // 对抗模式：选完策略后建整队共享血池
    this.enterBattleCheck();
  }

  /**
   * 每回合从模式的 stages 池里按权重抽一张战场（业主 2026-10-17：14 回合场景不同步，只在 boss 场合变化）。
   *
   * 随机流独立派生（`deriveSeed(seed, 'stage:<round>')`），所以不会扰动 rngWaves / rngDraft 的序列，
   * 同一 seed 的重放仍然逐帧一致。编辑器「试玩这张图」指定了 SP_STAGE 时不参与（`this.stageForced`）。
   * 换图后要让每个玩家重算部署图（与 SP_STAGE 那条路径同一处理），否则能放的位置还是上一张图的。
   */
  /** 第 r 回合该用哪张图（纯函数：不碰状态，重放/预测都走它）。池不足 2 张时返回 null（沿用当前图）。 */
  stageIdForRound(r) {
    if (this.stageForced) return null;
    const pool = Array.isArray(this.gd.mode?.stages) ? this.gd.mode.stages : [];
    let cands = pool
      .map((id) => [id, this.gd.stage(id)])
      .filter(([, st]) => st && st.active !== false && Number(st.weight) > 0)
      .map(([id, st]) => [id, Number(st.weight)]);
    if (cands.length < 2) return null;
    // 「每回合换图」的换：不上一回合刚打过的那张（否则相邻两回合可能抽到同一张，看起来像没换）。
    // 用 r-1 自己的派生流再算一次，保持确定性（重放/预测同一条链）；池里只剩这一张时仍然用它。
    if (r > 1) {
      const prev = this.stageIdForRound(r - 1);
      const rest = cands.filter(([id]) => id !== prev);
      if (rest.length) cands = rest;
    }
    const total = cands.reduce((n, [, w]) => n + (Number.isFinite(w) ? w : 0), 0);
    if (!(total > 0)) return null;
    const rng = createRng(deriveSeed(this.seed, `stage:${r}`));
    let x = rng.int(total);
    for (const [cid, w] of cands) { if (x < w) return cid; x -= w; }
    return cands[cands.length - 1][0];
  }

  /**
   * 每回合换战场 (业主 2026-10-17)。换图会重建棋盘，为了不出现「先程序化、后官方场景」的两次重建，
   * 同时把**下一回合**要用哪张图算出来（`this.nextStageId`），让客户端在本回合空闲时预热场景包。
   */
  /** 把一张图真正装到这一局上（几何、部署图重算）。返回是否换了。 */
  _applyStage(id) {
    if (!id || id === this.stageId) return false;
    const stage = this.gd.stage(id);
    if (!stage) return false;
    this.stageId = id;
    this.stage = stage;
    this.layout = layoutOf(stage);
    for (const ps of this.players.values()) ps.invalidateDeployMap?.();
    return true;
  }

  /**
   * 每回合换战场（业主 2026-10-17 定稿；「随机地图」开着时的协同共竞规则）。
   * 换图会重建棋盘，为了不出现「先程序化、后官方场景」的两次重建，同时把**下一回合**要用哪张图算出来
   * （`this.nextStageId`），让客户端在本回合空闲时预热场景包。
   */
  pickRoundStage(r) {
    if (this.stageForced) return;
    this._applyStage(this.stageIdForRound(r));
    const next = this.stageIdForRound(r + 1);
    this.nextStageId = next || this.stageId;
  }

  /**
   * boss 关要换成哪张战场（2026-10-22 业主口径：关掉「随机地图」时，开局随机一张，只在 boss 关刷新）。
   * 抽法沿用 `stageIdForRound`（同一套权重与独立 seed），但**保证不等于当前这张** —— 否则 1/N 的概率会抽回
   * 同一张图，看起来像「boss 关没刷新」。预换热身也用这个函数，客户端拿到的一定是真正会装上的那张。
   */
  bossStageFor(r) {
    const id = this.stageIdForRound(r);
    if (id && id !== this.stageId) return id;
    const cands = (Array.isArray(this.gd.mode.stages) ? this.gd.mode.stages : [])
      .filter((x) => x !== this.stageId && this.gd.stage(x) && this.gd.stage(x).active !== false && Number(this.gd.stage(x).weight) > 0);
    if (!cands.length) return id || this.stageId;
    const rng = createRng(deriveSeed(this.seed, `stage-boss:${r}`));
    return cands[rng.int(cands.length)];
  }

  /**
   * 其他玩法的战场刷新（业主 2026-10-18）：开局定一张，之后**只在 boss 关**换。
   * 抽法沿用 `stageIdForRound`（同一套权重与独立 seed），只是把应用时机收窄到 boss 关；
   * 不设 `nextStageId` —— 非协同共竞没有「下一回合预换」，客户端预热目标就是当前这张。
   */
  pickBossStage(r) {
    if (this.stageForced) return;
    this._applyStage(this.bossStageFor(r));
  }

  enterBattleCheck() {
    this.phase = PHASE.BATTLE_CHECK;
    this.setDeadline(this.gd.timer('battleCheck'), () => this.afterBattleCheck(), { silent: this.soloUntimed });
    this.markPublic();
  }

  /**
   * BATTLE_CHECK is over: R1 is about to begin. A plugin window declared at `battleCheck` for this round opens here —
   * "before the round begins", the host's own step first (docs/PLUGINS.md §10b) — and holds R1 back until it closes; a
   * content set without a window continues exactly as before (`openOfferWindow` returns before it touches anything).
   */
  afterBattleCheck() {
    this.startRound(1);
  }

  startRound(r, afterStart = null) {
    // Every round, including boss rounds. [ASSUMED] Expire nonblocking windows at the next round.
    for (const w of this.offerWin) this._closeOffer(w);
    this.offersDispose(); // A test-console round jump must discard the older continuation too.
    const step = () => { this._startRoundAfterOffers(r); afterStart?.(); };
    if (this.openOfferWindow('battleCheck', r) !== 'open') { step(); return; }
    this._offerResume = step;
  }

  _startRoundAfterOffers(r) {
    this.phase = PHASE.ROUND_START;
    this.round = r;

    // 协同共竞（mode_xie_*）：第 3 回合开始前开一次「海克斯熔毁协议」四栏商店（保真移植 hexmod 的 meltdown）。
    // 关店后回调继续本回合；st.wave === 0 保证只开一次，不会因为回调再进本函数而重复开。
    try {
      if (String(this.modeId || '').startsWith('mode_xie_') && r === 3 && typeof this.meltdownOpen === 'function') {
        const st = this._melt();
        if (!st.open && st.wave === 0) {
          this.meltdownOpen(() => this._startRoundAfterOffers(r));
          return;
        }
      }
    } catch (e) { this.reportError?.('meltdown open', e); }
    // 藏品三选一（业主 2026-10-27）：协同房 R4 / R8 / R12 各一次，非阻塞（选完或 20s 超时自动取第一张）。
    try {
      if ((String(this.modeId || '').startsWith('mode_xie_') || this.isRogue === true) && typeof this.relicOffer === 'function'
        && typeof this.relicDraftRound === 'function' && this.relicDraftRound(r)) {
        this.relicOffer();
      }
    } catch (e) { this.reportError?.('relic offer', e); }
    // 肉鸽随机事件（不期而遇）：R3 / R6 / R9，非阻塞，20s 超时取第一个选项。
    try {
      if (this.isRogue === true && typeof this.rogueEventOffer === 'function'
        && typeof this.rogueEventRound === 'function' && this.rogueEventRound(r)) {
        this.rogueEventOffer();
      }
    } catch (e) { this.reportError?.('rogue event', e); }
    // 肉鸽：本回合随机词缀 + 紧急作战（数值已并进敌人乘区；紧急回合给全队补偿资金）
    try {
      if (this.isRogue === true && typeof this.rogueRoundAffix === 'function') {
        const aff = this.rogueRoundAffix(r);
        const hot = typeof this.rogueEmergencyRound === 'function' && this.rogueEmergencyRound(r);
        for (const ps of this.alivePlayers()) {
          if (hot) {
            try { ps.addFunds(4, { reason: 'rogue-emergency' }); } catch { /* noop */ }
            this.toast(ps, 'warn', `紧急作战：敌人生命 +25% / 攻击 +20%，补偿 +4 资金`);
          }
          if (aff && aff.label) this.toast(ps, 'info', aff.label);
        }
      }
    } catch (e) { this.reportError?.('rogue affix toast', e); }
    // 攻防回合：狩猎期窗口内每回合红蓝互换攻守（首攻红队）；非攻防回合两者为 null。
    const role = this.roleTeamsFor(r);
    this.attackingTeam = role ? role.attack : null;
    this.defenderTeam = role ? role.defend : null;
    this._confrontDoneRound = 0;
    // 战场刷新（业主 2026-10-22 定稿）：
    //   * 「随机地图」开着（默认）：协同共竞**每回合**抽一张新图（原有规则）；其他玩法沿用官方规则（开局一张，只在 boss 关换）。
    //   * 关掉：开局前已经随机抽了一张（Match 的 setupMatchWaves），整局不换，**只在 boss 关（含隐藏 boss 关）刷新一次**。
    // 关闭态的下一张图提前一回合算进 `nextStageId`，客户端在本回合空闲时预热场景包（换图不白屏）。
    // 顺序要紧：必须在 `_planBossWaves` 之前（同一关的出战表按新图的几何算）。
    const bossNext = (x) => x === this.gd.bossRound || x === this.gd.hiddenRound;
    if (this.randomStage !== true) {
      // 业主 2026-10-27：**关掉就整局同一张图** —— boss 关也不再刷新。此前「关 = 开局一张、boss 关刷新一次」
      // 会让玩家在 R14/R15 看到地图被换掉（线上反馈「关了还是被切图」）。
      this.nextStageId = this.stageId;
    } else if (this.isXie || this.isRogue === true) {
      // 协同共竞与肉鸽都每回合换图（肉鸽靠它做「每层不同地图」）；stageIdForRound 自带 seed 派生，重放安全
      this.pickRoundStage(r);
    } else if (bossNext(r)) {
      this.pickBossStage(r);
    }
    this._revivalHeld = false; // 救援冻结是一次性的（每回合最多挂起一次）
    this.fields = [];
    this.watchers.clear();
    this.unitePlan = null;
    this.uniteResultView = null;
    this.sp = null;
    this.wave = null;
    this.bossWaves = null;
    // 对抗模式：上一回合的 狩猎期 / 事件期状态不得漏进本回合的 PREP / 视图
    if (this.isVersus) {
      this.confrontStage = null; this.confront = null; this.confrontSubs = null; this.confrontTargets = null;
      this._confrontRemoved = null;
    }
    // 熔毁代价的「每回合全属性」档：每回合把 debt.round 累加进 growth（业主 2026-10-26 接线）
    if (this.melt && this.melt.debt) {
      const per = Math.max(0, Number(this.melt.debt.round) || 0);
      if (per > 0) this.melt.growth = Math.max(0, Number(this.melt.growth) || 0) + per;
    }
    const alive = this.alivePlayers();
    // the round's enemies (shared composition, generated now so the prep preview is exact). Planned BEFORE the players'
    // round start: its recompute() checks the board on the field the player deploys on this round (deployFieldOf reads
    // the boss pairing), so R14 → R15 never re-checks a boss-field board against the normal field (user playtest #5
    // item 7). rngWaves is used only here, so the order leaves every random stream unchanged.
    const isBoss = r === this.gd.bossRound || r === this.gd.hiddenRound;
    if (isBoss) {
      this._planBossWaves();
    } else {
      // stageId: a workshop stage may bind its own wave table to a round (shared/waveAuthoring.js; waves.js buildNormalWave)
      this.wave = buildNormalWave(this.gd, this.rngWaves, this.factions, r, this.stageId);
      // 对抗：记下本回合真正生成的怪 —— 狩猎期「只能选该回合往前出过的怪」以它为真源（业主 2026-10-26）
      if (this.isVersus) {
        try { this.confrontRecordWave(r, this.wave); } catch (e) { this.reportError('confrontRecordWave', e); }
      }
    }
    for (const ps of alive) ps.startRound(r);
    // hexDraftDisabled：业主 2026-10-26 口径 —— 协同共竞**不做海克斯三选一**（草案），只保留熔毁商店。
    // 商店（第 3 回合）里的卡片仍通过 _hexApply 直接生效，与草案无关，所以这里整段不要。
    // 协同经济 (DESIGN §28): the ask budget and the team transfer total are **per round**, re-armed here
    if (this.teamEcon) this.econNewRound();
    // 方案 B (DESIGN §27): the loans of the last round are paid back out of the income just granted
    if (this.teamEcon) this.econSettleDebts(alive);
    // 助战 (shared/support.js): re-check what each player brought against the pool ONE more time at the first round's
    // start and record what it really got (data/support.json can change between the lobby check and here). Nothing is
    // handed out: the operators are in the shop (Match.supportSupply puts them in the pool), priced like any other
    // piece — `granted` is what the player can actually buy, which is what the client echoes back.
    // Guarded on purpose: this is an optional extension of the remake, and startRound is where the ROUND_START deadline
    // (afterRoundStart → PREP) is armed — an exception here used to escape into Match.guard, so no deadline was ever set
    // and the match sat in ROUND_START with the whole HUD locked (2026-10-17: `ps.prepareSupports is not a function`).
    if (r === 1) for (const ps of alive) {
      try { ps.prepareSupports(); } catch (e) { this.reportError('prepareSupports', e); }
    }
    // 「试玩时直接发到手上」（记录里的 `directToHand`，或 `pack.json.playtest.directToHand`，业主 2026-10-08）：
    // 只有编辑器 spawn 的试玩服务器会发牌（见 directToHandIds）
    if (r === 1) {
      try { this.grantDirectToHand(alive); } catch (e) { this.reportError('grantDirectToHand', e); }
    }
    for (const ps of alive) this.dispatch(ps, 'onRoundStart', { round: r });
    // an eliminated player's pending 信标 gift still goes to its teammate (effects flagged afterElimination; GitHub #86)
    for (const ps of this.order) {
      if (ps.alive) continue;
      try { this.dispatcher.dispatchEliminated(ps, 'onRoundStart', { round: r }); } catch (e) { this.reportError('dispatch onRoundStart (eliminated)', e); }
    }
    for (const ps of alive) ps.recompute();
    this.setDeadline(DELAYS.ROUND_START / 1000, () => this.afterRoundStart(), { silent: this.soloUntimed });
    this.markPublic();
    // eliminated humans and spectator seats scout the board of the player they follow through the round's prep, not
    // their own empty board (community report of 2026-10-06, item 56; MatchWatch._followScout)
    for (const ps of this._viewers()) this._followScout(ps);
  }

  /**
   * @param {Array<object>} players 这一局的人类席位
   */
  grantDirectToHand(players) {
    const ids = directToHandIds(this.gd, process.env);
    if (!ids.length) return;
    for (const ps of players) {
      if (!ps || ps.isBot) continue;
      const got = [];
      for (const id of ids) {
        const slot = ps.hand.findIndex((x) => x == null);
        if (slot < 0) break;
        try {
          const rec = this.gd.chess(id);
          const base = this.gd.baseIdOf(id);
          // 份数走 `PlayerState.poolOf` —— 唯一分派点（design-level A, docs/PS100-MIGRATION.md §10-A）：自选槽走本人 stock、
          // 100 座变体走本玩家自己的池，≤ MAX_SEATS 时它就是 `this.pool` 本身（同一个对象上的同一条语句）。
          // 从共享目录直接 take 会让变体下的目录 `left < cap`，正是变体要消灭的东西。
          const taken = ps.poolOf(base).take(base, rec && rec.isGolden ? this.gd.goldenCopies : 1);
          ps.hand[slot] = ps.newPiece('chess', id, { poolCopies: taken });
          got.push(id);
        } catch (e) {
          this.reportError?.(`directToHand ${id}`, e);
        }
      }
      if (got.length) {
        // 让作者一眼看到「试玩直接发牌」生效了（试玩服务器是编辑器起的，不会有人误解成正式对局）
        this.toast(ps, 'ok', msg('试玩：标了「直接发到手上」的 {0} 名干员已进手牌', { 0: got.length }));
      }
      ps.recompute?.();
      ps.dirty?.();
    }
  }

  /** Stable per-match pairs and their templates, generated before the prep preview / board validation. */
  _planBossWaves() {
    const r = this.round;
    const bossId = r === this.gd.hiddenRound && r !== this.gd.bossRound ? this.hiddenBossId : this.bossId;
    // Pairing uses an independent seeded draw, consuming no shop, wave, draft or battle randomness.
    const groups = pairPlayers(this.alivePlayers(), createRng(deriveSeed(this.seed, 'boss-pairs')), this.bossPairs);
    this.bossPairs = groups.map(g => g.map(p => p.playerId));
    this.bossWaves = groups.map((g) => ({
      players: g.map((p) => p.playerId),
      wave: buildBossWave(this.gd, this.rngWaves, this.factions, r, { bossId, solo: this.isSolo || g.length === 1 }, this.stageId),
    }));
  }

  afterRoundStart() {
    // 对抗模式的事件期（eventRoundsFor）：一回合一次，先于机变 / 休整期。
    if (this.eventDue && this.eventDue()) { this.enterEvent(); return; }
    if (this.gd.spRounds().includes(this.round)) this.enterSpDraft();
    else this.beforePrepOffers();
  }

  beforePrepOffers() {
    // The official round start and its draw/draft finish first; only entering prep waits.
    this.sp = null;
    // 攻防回合：先由攻方投放（CONFRONT），再进入守方的休整期；非攻防回合照旧。
    const step = () => (this.isRoleRound() ? this.enterConfront() : this.enterPrep());
    if (this.openOfferWindow('prep', this.round) !== 'open') { step(); return; }
    this._offerResume = step;
  }
}
