// server/match/invariants.js — engine invariants (DESIGN §11) as a non-throwing check. Used by the test harness
// (i18n-ignore-file: developer reports in English with the game's terms, never shown to players — docs/I18N.md)
// (test/match/harness.js checkInvariants asserts the list is empty) and by tools/matchrun.mjs --check sweeps.
//
// collectViolations(m) → string[] (empty when every invariant holds):
//   pool     raw balance ≤ cap and raw balance + Σ copies held by pieces == cap (public availability is clamped at zero) per base chess; non-pool chess hold 0 copies;
//            above MAX_SEATS PARTICIPANTS (the 100-seat variant, docs/PS100-MIGRATION.md §10-A) the same equation holds PER PLAYER
//            against that player's own pool (PlayerState.poolOf), while the shared `m.pool` is checked as the read-only
//            canonical catalog; ≤ MAX_SEATS participants keeps the room-wide reading (a 20-seat room with 4 players in it included)
//            every capped shop item is held by at most its cap (normal occupies 1, upgraded 2; effect-only items have no cap)
//            a player's 自选 stock (0.2.0, player/diy.js) the same against its own pieces of each slotted slot — a DIY
//            piece is always a slotted slot of its owner's, and a DIY shop / reward card one of its stocked slots
//   economy  funds / pendingFunds non-negative integers, LP finite, shop level in range, prices ≥ 0
//   pieces   unique uids; hand 10 / temp 5 slots; temp holds pieces only while the hand is full (a free hand slot pulls
//            a temp piece in, PlayerState._fillHandFromTemp); chess carry ≤ equipPerChess known items
//            (morphPairing plus: a 变形同构体 does not count toward that cap); a normal piece
//            holds ≤ 1 copy, an elite ≤ goldenCopies; merges are immediate (never `mergeCount` normal copies of one
//            chess, never two copies of a mergeable normal item); every token's owner chess is deployed
//   board    tiles inside the own region and legal for the piece (a range-bound summon inside its owner's attack
//            range); no items on the board; chess count ≤ deploy cap
//            (where a merge's elite goes — a consumed deployed copy's tile, else the hand — needs the state before the
//            merge: audit.js checks it per merge)
//   bonds    ps.bonds equals a fresh computeBonds() (every mutation recomputed them); every bond's layers 0 … BOND_LAYER_CAP
//   shop     slot count follows the rolled layout; ids known; banned chess never offered by the shop / rewards — the
//            only exception is an operator a player BROUGHT as 助战 (shared/support.js: it keeps one pool copy and is
//            marked `support` on its slot), because banning a shop roll must not disable a support
//   elim.    an eliminated player owns nothing (board, hand, temp, shop, offers, bounties, funds)
//   choice   a player's open 教鞭 choice (`personalChoice`) is one of an alive, not-Ready player in the PREP of its own round,
//            with one to three different cards
//   match    phase known; teamLp / boss pool within range; combat fields match the alive players

import { PHASE, BOND_LAYER_CAP } from '../../shared/constants.js';
import { morphSlotPolicy, ruleOption } from '../../shared/plugins/rules.js';
import { FIELD, canPlace, placeClass, positionClass, parseKey } from './board.js';
import { computeBonds } from './bondsMeta.js';
import { matchSlotPolicy } from '../../shared/morph.js';   // 协同共竞: 装备位策略（mod 层 shared 文件已随树携带）
// 装备位语义（第 7 段）：不变量里「占几格 / 最多几件 / 最多一件变形同构体」读这一局的策略（缺省档 = 官方那条算术）。

const PHASES = new Set(Object.values(PHASE));

/**
 * @param {import('./Match.js').Match} m
 * @param {{ limit?: number }} [opts]
 * @returns {string[]}
 */
export function collectViolations(m, { limit = 25 } = {}) {
  const out = [];
  const fail = (msg) => { if (out.length < limit) out.push(msg); };
  const gd = m.gd;
  const held = new Map();
  const uids = new Set();
  const banned = new Set(m.bannedChess || []);
  // 100-seat variant (design-level A, docs/PS100-MIGRATION.md §10-A): above MAX_SEATS PARTICIPANTS every player has a
  // pool of its own, so the SAME conservation equation holds PER PLAYER instead of room-wide. Both readings are checked
  // below — this is a gate, not a replacement: ≤ MAX_SEATS participants still runs the room-wide equation, statement
  // for statement. It reads the Match's ONE computed gate (`m.variant`, 「在场参与者数」不是「房间容量」) rather than
  // re-deriving it from `seatCap`, so the checker can never disagree with the code it checks.
  const independent = m.variant === true;
  /** @type {Map<string, Map<string, number>>} playerId → baseId → the copies its pieces hold (自选 stock excluded) */
  const heldOf = new Map();
  const note = (ps, p) => {
    if (!Number.isInteger(p.uid) || p.uid <= 0) fail(`${ps.playerId}: bad uid ${p.uid}`);
    else if (uids.has(p.uid)) fail(`${ps.playerId}: duplicate uid ${p.uid}`);
    uids.add(p.uid);
  };

  if (!PHASES.has(m.phase)) fail(`unknown phase ${m.phase}`);
  if (m.teamLp != null && !(Number.isFinite(m.teamLp) && m.teamLp >= 0)) fail(`teamLp ${m.teamLp}`);
  if (m.bossPool && !(m.bossPool.hp >= 0 && m.bossPool.hp <= m.bossPool.maxHp)) fail(`boss pool ${m.bossPool.hp}/${m.bossPool.maxHp}`);

  // 协同经济 (DESIGN §28): the reserve and the request registry are match state — the checkers below must not see
  // either while the rule set is off, and never a request that outlived its prep.
  if (m.teamEcon) {
    if (!Number.isInteger(m.teamReserve) || m.teamReserve < 0) fail(`team reserve ${m.teamReserve}`);
    // 三层资金（业主 2026-10-26 / 复审计 2026-10-27）：个人储备必须非负，且每个活着的玩家
    // 的个人储备都要 >= 团队储备 —— 只校验 teamReserve 非负会让这个不变量被静默破坏。
    for (const pid of m.order) {
      const ps = m.players.get(pid);
      if (!ps || !ps.alive) continue;
      const r = ps.reserve;
      if (!(Number.isInteger(r) && r >= 0)) fail(`personal reserve ${r} of ${pid}`);
      if (r < m.teamReserve) fail(`personal reserve ${r} < team reserve ${m.teamReserve} (${pid})`);
    }
    const outs = new Map();
    for (const req of m.econRequests.values()) {
      if (m.phase !== PHASE.PREP) fail(`request ${req.id} outside PREP (${m.phase})`);
      if (req.round !== m.round) fail(`request ${req.id} of round ${req.round} (now ${m.round})`);
      if (!(Number.isInteger(req.amount) && req.amount >= 1 && req.amount <= m.teamEcon.transfer.maxPerRequest)) fail(`request ${req.id} amount ${req.amount}`);
      // 广播借钱 (user decision 2026-10-12): a request carries a **targets[] list** (one entry for a named ask,
      // every other living seat for a broadcast) — there is no single `to` any more.
      const from = m.players.get(req.from);
      if (!from || !from.alive || from.left) fail(`request ${req.id} involves an absent asker`);
      if (!Array.isArray(req.targets) || !req.targets.length) fail(`request ${req.id} has no targets`);
      for (const id of req.targets) {
        const to = m.players.get(id);
        if (!to || !to.alive || to.left) fail(`request ${req.id} involves an absent target (${id})`);
      }
      outs.set(req.from, (outs.get(req.from) || 0) + 1);
    }
    // 一人一条在途请求（其余人**可以**同时成为多条广播的目标 —— 广播就是问遍所有人的）
    for (const [pid, n] of outs) if (n > 1) fail(`${pid}: ${n} pending outgoing requests`);
    if (m.econRound && m.econRound.spent > m.teamTransferCap()) fail(`team transfers this round ${m.econRound.spent} > cap ${m.teamTransferCap()}`);
    // 救济 (DESIGN §28): the round's draw on the reserve stays inside its two caps, and a project level never exceeds
    // what the mode sells
    if (m.teamEcon.relief.enabled) {
      const rl = m.teamEcon.relief;
      if (!Number.isInteger(m.econReliefSpent) || m.econReliefSpent < 0 || m.econReliefSpent > rl.teamPerRound) fail(`team relief this round ${m.econReliefSpent} > cap ${rl.teamPerRound}`);
      for (const [pid, n] of m.econReliefByPlayer || []) {
        if (!Number.isInteger(n) || n < 0 || n > rl.perPlayerPerRound) fail(`${pid}: ${n} relief draws > cap ${rl.perPlayerPerRound}`);
      }
    } else if (m.econReliefSpent) {
      fail(`relief state (${m.econReliefSpent}) while the rule is off`);
    }
    // 兜底分红 (DESIGN §28.5, user decision 2026-10-09): the pool's un-paid fraction always stays under one whole
    // fund, and the interest minted this match never passes the principals it was minted on ("借 1 永远不会收回 2")
    const cov = m.teamEcon.coverInterest;
    if (cov && cov.enabled) {
      if (!(Number.isFinite(m.econCoverCarry) && m.econCoverCarry >= 0 && m.econCoverCarry < 1)) fail(`兜底 pool carry ${m.econCoverCarry} outside [0, 1)`);
      if (!Number.isInteger(m.econCoverPaid) || !Number.isInteger(m.econCoverRepaid) || m.econCoverPaid > m.econCoverRepaid) {
        fail(`兜底 interest ${m.econCoverPaid} > principals repaid ${m.econCoverRepaid}`);
      }
      for (const [pid, n] of m.econCoverEarned || []) {
        if (!Number.isInteger(n) || n < 0) fail(`${pid}: 兜底 interest earned ${n}`);
      }
      for (const [pid, n] of m.econCoverLastBonus || []) {
        if (!Number.isInteger(n) || n < 0) fail(`${pid}: 兜底 last bonus ${n}`);
      }
    } else if (m.econCoverPaid || m.econCoverRepaid || m.econCoverCarry) {
      fail(`兜底 dividend state (paid ${m.econCoverPaid}, carry ${m.econCoverCarry}) while the rule is off`);
    }
    for (const [id, level] of Object.entries(m.teamProjects || {})) {
      const costs = m.teamEcon.projects[id] && m.teamEcon.projects[id].costs;
      if (!costs) fail(`project ${id} not shipped by the rule set`);
      else if (!Number.isInteger(level) || level < 0 || level > costs.length) fail(`project ${id} level ${level} > ${costs.length}`);
    }
  } else if (m.teamReserve || m.econRequests.size || m.econReliefSpent) {
    fail(`team economy state (reserve ${m.teamReserve}, ${m.econRequests.size} requests) while the rule set is off`);
  }

  for (const ps of m.players.values()) {
    const id = ps.playerId;
    // the player's view of the data (its slotted 自选 slots are its operators) and the copies its 自选 pieces hold
    const pgd = ps.gd || gd;
    const diyHeld = new Map();
    if (!Number.isInteger(ps.funds) || ps.funds < 0) fail(`${id}: funds ${ps.funds}`);
    if (!Number.isInteger(ps.pendingFunds) || ps.pendingFunds < 0) fail(`${id}: pendingFunds ${ps.pendingFunds}`);
    if (!Number.isFinite(ps.lp)) fail(`${id}: lp ${ps.lp}`);
    if (ps.alive && m.phase !== PHASE.SETTLE && ps.lp <= 0 && m.teamLp == null && m.round > 0 && ps.bandId) fail(`${id}: alive with lp ${ps.lp}`);
    if (ps.hand.length !== gd.benchSize) fail(`${id}: hand has ${ps.hand.length} slots`);
    if (ps.temp.length < gd.tempSize) fail(`${id}: temp has fewer than ${gd.tempSize} visible slots`);
    if (ps.temp.length > gd.tempSize && ps.temp.some((x) => x == null)) fail(`${id}: overflow queue has an unfilled slot`);
    // 临时整备区 = overflow only (PRTS 卫戍协议/帮助 §手牌区 "常规手牌区出现空位时自动移入", GitHub #82)
    if (ps.temp.some(Boolean) && ps.hand.some((x) => x == null)) fail(`${id}: a temp piece waits while a hand slot is free`);
    if (!(ps.shop.level >= 1 && ps.shop.level <= gd.maxShopLevel)) fail(`${id}: shop level ${ps.shop.level}`);
    if (!(ps.shop.upgradePrice >= 0)) fail(`${id}: upgradePrice ${ps.shop.upgradePrice}`);
    if (!Number.isInteger(ps.shop.freeRefreshes) || ps.shop.freeRefreshes < 0) fail(`${id}: freeRefreshes ${ps.shop.freeRefreshes}`);
    // the official per-bond layer cap (shared/constants.js): no writer may pass it
    for (const [b, v] of Object.entries(ps.layers || {})) {
      if (!(Number.isFinite(v) && v >= 0 && (!(BOND_LAYER_CAP > 0) || v <= BOND_LAYER_CAP))) fail(`${id}: ${b} layers ${v}`);
    }

    if (!ps.alive) {
      if (ps.board.size) fail(`${id}: eliminated but keeps ${ps.board.size} board pieces`);
      if (ps.hand.some(Boolean) || ps.temp.some(Boolean)) fail(`${id}: eliminated but keeps hand/temp pieces`);
      if (ps.shop.slots.length || ps.offers.length || ps.bounties.length) fail(`${id}: eliminated but keeps shop/offers/bounties`);
      if (ps.funds || ps.pendingFunds) fail(`${id}: eliminated with funds ${ps.funds}+${ps.pendingFunds}`);
    }
    // 教鞭's personal choice (Match.offerBountyChoice): resolved before the prep ends — by its owner, the deadline or the bot
    const pc = ps.personalChoice;
    if (pc) {
      if (!ps.alive || ps.ready || m.phase !== PHASE.PREP || pc.round !== m.round) fail(`${id}: a personal choice outside its own prep (${m.phase} R${m.round}, offered in R${pc.round})`);
      if (!Array.isArray(pc.cards) || !pc.cards.length || pc.cards.length > 3 || new Set(pc.cards.map((c) => c && c.effectId)).size !== pc.cards.length) fail(`${id}: personal choice of ${pc.cards && pc.cards.length} cards`);
    }

    // pieces
    const all = [...ps.board.values(), ...ps.hand.filter(Boolean), ...ps.temp.filter(Boolean)];
    const boardChessUids = new Set();
    for (const p of ps.board.values()) if (p.kind === 'chess') boardChessUids.add(p.uid);
    const itemCounts = new Map();
    // A copy gained as the previous prep ended (PlayerState.acquireItem deferMerge) waits until the next prep.
    // It does not count toward "merges are immediate" until that prep's checkItemMerges consumes it.
    const countItem = (it) => { if (it.deferMerge) return; itemCounts.set(it.id, (itemCounts.get(it.id) || 0) + 1); };
    for (const p of all) {
      note(ps, p);
      if (p.kind === 'chess') {
        const rec = pgd.chess(p.id);
        if (!rec) { fail(`${id}: unknown chess ${p.id}`); continue; }
        if (rec.isDiy && !rec.diyFor) fail(`${id}: owns ${p.id}, a 自选 slot it has not filled`);
        const slots = morphSlotPolicy(ruleOption(m.rules, 'morphPairing'), (it) => !!pgd.item(it?.id)?.canGiveBond);
        if (!Array.isArray(p.items) || slots.slotsUsed(p.items) > slots.slotCap(gd.equipPerChess)) fail(`${id}: ${p.id} carries ${p.items && p.items.length} items`);
        if (ruleOption(m.rules, 'morphPairing') === 'plus' && (p.items || []).filter((it) => pgd.item(it?.id)?.canGiveBond).length > 1) fail(`${id}: ${p.id} carries multiple morphs`);
        for (const it of p.items || []) {
          note(ps, it);
          if (it.kind !== 'item' || !gd.item(it.id)) fail(`${id}: ${p.id} carries a bad item ${it.kind}:${it.id}`);
          else if (gd.item(it.id).itemType !== 'EQUIP') fail(`${id}: ${p.id} carries a non-equipment item ${it.id}`);
          countItem(it);
        }
        const maxCopies = rec.isGolden ? gd.goldenCopies : 1;
        if (!Number.isInteger(p.poolCopies) || p.poolCopies < 0 || p.poolCopies > maxCopies) fail(`${id}: ${p.id} holds ${p.poolCopies} copies`);
        const base = gd.baseIdOf(p.id);
        const tally = rec.isDiy ? diyHeld : held;
        tally.set(base, (tally.get(base) || 0) + (p.poolCopies || 0));
        if (!rec.isDiy) {
          // the same tally, kept per player: the variant's pools are per player (see `independent` above)
          let mine = heldOf.get(id);
          if (!mine) { mine = new Map(); heldOf.set(id, mine); }
          mine.set(base, (mine.get(base) || 0) + (p.poolCopies || 0));
        }
      } else if (p.kind === 'item') {
        if (!gd.item(p.id)) fail(`${id}: unknown item ${p.id}`);
        countItem(p);
      } else if (p.kind === 'token') {
        if (!pgd.token(p.id)) fail(`${id}: unknown token ${p.id}`);
        if (!(p.count >= 1)) fail(`${id}: token stack count ${p.count}`);
        // summons exist only while their owner is deployed (withdrawing / selling / merging it removes them)
        if (!boardChessUids.has(p.ownerUid)) fail(`${id}: token ${p.uid} without a deployed owner (${p.ownerUid})`);
      } else {
        fail(`${id}: piece of unknown kind ${p.kind}`);
      }
    }
    // board
    let deployed = 0;
    // a pure read (Match.deployMapFor: the field the player deploys on now) — PlayerState.deployMap() would update the
    // player's cached field / legality flag, and this checker must not change when a later recompute moves pieces
    const dmap = typeof m.deployMapFor === 'function' ? m.deployMapFor(ps) : ps.deployMap();
    for (const [k, p] of ps.board) {
      const [r, c] = parseKey(k);
      if (!(r >= FIELD.r0 && r <= FIELD.r1 && c >= FIELD.c0 && c <= FIELD.c1)) fail(`${id}: piece outside the board at ${k}`);
      if (p.kind === 'item') { fail(`${id}: item ${p.id} stands on the board`); continue; }
      const rec = p.kind === 'token' ? pgd.token(p.id) : pgd.chess(p.id);
      const cls = p.kind === 'chess' ? placeClass(ps, rec) : positionClass(rec);
      if (rec && !canPlace(dmap, cls, r, c)) fail(`${id}: ${p.id} on an illegal tile ${k}`);
      // a "只能部署在召唤者攻击范围内" summon inside its owner's attack range (PlayerState.summonRange: a pure read)
      const range = p.kind === 'token' && typeof ps.summonRange === 'function' ? ps.summonRange(p) : null;
      if (range && !range.has(k)) fail(`${id}: ${p.id} on ${k}, outside its owner's attack range`);
      // an outside-bound summon (战术锚点, PlayerState.summonExcluded) outside it
      const out = p.kind === 'token' && typeof ps.summonExcluded === 'function' ? ps.summonExcluded(p) : null;
      if (out && out.has(k)) fail(`${id}: ${p.id} on ${k}, inside its owner's attack range`);
      if (p.kind === 'chess') deployed++;
    }
    if (deployed > ps.deployCap) fail(`${id}: ${deployed} chess deployed > cap ${ps.deployCap}`);
    // merges are immediate
    const copies = new Map();
    for (const p of all) if (p.kind === 'chess' && pgd.chess(p.id) && !gd.isGolden(p.id)) { const b = gd.baseIdOf(p.id); copies.set(b, (copies.get(b) || 0) + 1); }
    for (const [b, n] of copies) {
      const need = gd.mergeCount(b);
      if (need > 1 && gd.goldenIdOf(b) && n >= need) fail(`${id}: owns ${n} normal copies of ${b} (merges at ${need})`);
    }
    for (const [itemId, n] of itemCounts) {
      const rec = gd.item(itemId);
      if (!rec || rec.isGolden || rec.itemType !== 'EQUIP' || !rec.mergeable) continue;
      const need = Number.isInteger(rec.upgradeNum) ? rec.upgradeNum : gd.itemMergeCount;
      const gid = rec.upgradeChessId || rec.goldenId;
      if (need > 1 && need < 100 && gid && gd.item(gid) && n >= need) fail(`${id}: owns ${n} copies of item ${itemId} (merges at ${need})`);
    }
    // bonds are up to date
    try {
      const fresh = computeBonds(pgd, ps);
      if (JSON.stringify(fresh) !== JSON.stringify(ps.bonds)) fail(`${id}: stale bonds (missing recompute)`);
    } catch (e) {
      fail(`${id}: computeBonds threw ${e && e.message}`);
    }
    // shop
    if (ps.alive) {
      const layout = ps.shop.layout;
      if (layout && ps.shop.slots.length !== layout.chess + layout.item) fail(`${id}: ${ps.shop.slots.length} shop slots for layout ${layout.chess}+${layout.item}`);
      ps.shop.slots.forEach((s, i) => {
        if (!s) return;
        if (s.kind === 'chess' ? !gd.chess(s.id) : !gd.item(s.id)) fail(`${id}: shop slot ${i} unknown ${s.kind} ${s.id}`);
        if (!Number.isInteger(s.basePrice) || s.basePrice < 0) fail(`${id}: shop slot ${i} basePrice ${s.basePrice}`);
        // 助战是这条规则唯一的例外（shared/support.js）：本局随机禁用的是**抽卡内容**，而带上的助战必须买得到，
        // 所以它的池子拷贝能出现在商店里 —— 前提是它真的带着那份助战拷贝（pool.isSupport），不是被禁了还漏出来。
        if (s.kind === 'chess' && banned.has(gd.baseIdOf(s.id)) && !(s.support === true && m.pool.isSupport(gd.baseIdOf(s.id)))) {
          fail(`${id}: banned chess ${s.id} in the shop`);
        }
        if (s.kind === 'chess' && gd.chess(s.id)?.isDiy && !(ps.diyStock && ps.diyStock.has(gd.baseIdOf(s.id)))) fail(`${id}: 自选 slot ${s.id} in the shop without its stock`);
      });
      for (const o of ps.offers) {
        for (const s of o.slots || []) {
          if (s.kind === 'item' ? !gd.item(s.id) : !gd.chess(s.id)) fail(`${id}: bad reward slot ${s.kind} ${s.id}`);
          if (s.kind !== 'item' && banned.has(gd.baseIdOf(s.id)) && o.source === 'merge') fail(`${id}: banned chess ${s.id} offered as a merge reward`);
          if (s.kind !== 'item' && gd.chess(s.id)?.isDiy && !(ps.diyStock && ps.diyStock.has(gd.baseIdOf(s.id)))) fail(`${id}: 自选 slot ${s.id} offered without its stock`);
        }
        if (!o.slots || !o.slots.length || o.slots.length > 6) fail(`${id}: reward offer with ${o.slots && o.slots.length} slots`);
      }
    }
    // 自选 stock accounting (player/diy.js): left + held == cap per slotted slot; a slot without stock holds nothing
    for (const [base, e] of ps.diyStock ? ps.diyStock.entries : []) {
      if (!(Number.isInteger(e.left) && e.left <= e.cap)) fail(`${id}: 自选 stock ${base}: balance ${e.left} cap ${e.cap}`);
      const h = diyHeld.get(base) || 0;
      if (e.left + h !== e.cap) fail(`${id}: 自选 stock ${base}: left ${e.left} + held ${h} != cap ${e.cap}`);
    }
    for (const [base, n] of diyHeld) if (!(ps.diyStock && ps.diyStock.has(base)) && n !== 0) fail(`${id}: 自选 slot ${base} without stock holds ${n} copies`);
  }

  // shared pool accounting
  if (!independent) {
    for (const [base, e] of m.pool.entries) {
      if (!(Number.isInteger(e.left) && e.left <= e.cap)) fail(`pool ${base}: balance ${e.left} cap ${e.cap}`);
      const h = held.get(base) || 0;
      if (e.left + h !== e.cap) fail(`pool ${base}: left ${e.left} + held ${h} != cap ${e.cap}`);
    }
    for (const [base, n] of held) if (!m.pool.has(base) && n !== 0) fail(`non-pool chess ${base} holds ${n} copies`);
  } else {
    // 100-seat variant: the shared pool is the canonical CATALOG — its `entries` are the authoritative id set and its
    // caps the copy ceilings (audit.js, platform.js, the shop), but no copies are taken from it, so only its balance
    // bound is checked here. Every piece's copies are conserved against ITS OWNER's pool (PlayerState.poolOf is the one
    // dispatch point), which is the same equation the branch above applies room-wide.
    for (const [base, e] of m.pool.entries) {
      if (!(Number.isInteger(e.left) && e.left <= e.cap)) fail(`pool ${base}: balance ${e.left} cap ${e.cap}`);
    }
    for (const ps of m.players.values()) {
      const mine = heldOf.get(ps.playerId) || null;
      const own = ps._ownPool || null;
      if (!own) {
        if (mine) for (const [base, n] of mine) if (n !== 0) fail(`${ps.playerId}: holds ${n} copies of ${base} with no pool of its own`);
        continue;
      }
      for (const [base, e] of own.entries) {
        if (!(Number.isInteger(e.left) && e.left <= e.cap)) fail(`${ps.playerId} pool ${base}: balance ${e.left} cap ${e.cap}`);
        const h = mine ? mine.get(base) || 0 : 0;
        if (e.left + h !== e.cap) fail(`${ps.playerId} pool ${base}: left ${e.left} + held ${h} != cap ${e.cap}`);
      }
      if (mine) for (const [base, n] of mine) if (n !== 0 && !own.has(base)) fail(`${ps.playerId}: non-pool chess ${base} holds ${n} copies`);
    }
  }

  // Displayed shop cards and item rewards may overdraw; itemPool.debt is that overage (#624). Fixed gift families
  // may overdraw without a debt entry. debt > over is always a missed repay or a debt recorded for a piece not kept.
  // The chess pool above also permits explicit overdraw (Mimic, displayed operator cards).
  if (m.itemPool && gd.raw.items) {
    for (const [id, rec] of Object.entries(gd.raw.items)) {
      if (!rec || rec.isGolden) continue;
      const cap = m.itemPool.cap(id);
      if (!Number.isInteger(cap)) continue;
      const h = m.itemPool.held(id);
      const over = Math.max(0, h - cap);
      const debt = m.itemPool.debtOf(id);
      if (debt > over) fail(`item ${id}: debt ${debt} > overage ${over} (held ${h}, cap ${cap})`);
      if (!gd.isUnlimitedGiftItem(id) && over > debt) fail(`item ${id}: held ${h} > cap ${cap} without debt ${debt}`);
    }
  }

  // combat fields
  if (m.phase === PHASE.COMBAT) {
    // one field per alive player (+ the force-ended field of a player who quit during this combat)
    const alive = m.order.filter((p) => p.alive || (p.left && m.fields.some((f) => f.fieldId === `n:${p.playerId}`))).map((p) => `n:${p.playerId}`).sort();
    const ids = m.fields.map((f) => f.fieldId).sort();
    if (JSON.stringify(alive) !== JSON.stringify(ids)) fail(`combat fields ${ids.join(',')} != alive ${alive.join(',')}`);
  }
  return out;
}
