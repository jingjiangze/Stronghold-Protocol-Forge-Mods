// Minimal observable store for the browser client.
//
// One app-wide store holds everything the UI renders from:
//   connection  – socket status + latency (fed by net.js via main.js)
//   me          – { playerId, name, token } from `welcome`
//   content     – `welcome.content`: the server's content identity { vanilla: <cs> } (DESIGN §32), or null
//   session     – { entered } (the player pressed 开始 on the title screen in this tab)
//   room        – last `room.state` payload (without `t`) or null
//   match       – { public, private, field, result } from the `m.*` pushes; `battle` = the local battle runner's
//                 state (client-side combat, public/js/battle/runner.js): { battleId, fieldId, kind, authoritative,
//                 watch, done, own, members, loading, speed, paused, leaks } | null — `paused`: the solo pause holds
//                 every local clock; `leaks`: { [fieldId]: counted leaks so far } of every normal field simulated
//                 locally (the live LP of ui/hud.js liveLp, user playtest #3 item 2). Under client-side combat `field`
//                 is published by the runner (the m.field shape of the battle on screen, `local: true`).
//   ticker      – recent `m.ticker` lines, emotes – recent `m.emote` events
//   clock       – { offset, rtt } server clock correction: serverNow ≈ Date.now() + offset
//   ui          – small bits of local UI state shared between screens (pendingJoin / pendingPlaytest: the
//                 `?room=` / `?playtest=` deep links, consumed by main.js once entered + online)
//
// The store is framework-agnostic (get/set/subscribe); `useStore(selector)` binds it to Preact.
// Updates are immutable at the top level: `set` shallow-merges a patch object, `patch(key, obj)`
// shallow-merges into one nested object. Subscribers are notified synchronously.

import { useLayoutEffect, useReducer, useRef } from '../vendor/hooks.module.js';
import { PHASE } from '../../shared/constants.js';
import { t } from '../../shared/i18n.js';

/**
 * Create an observable store.
 * @template S
 * @param {S} initial initial state object
 * @returns {{ get: () => S, set: (patch: Partial<S> | ((s: S) => Partial<S>)) => void,
 *             patch: (key: keyof S, value: object | ((prev: any) => object)) => void,
 *             subscribe: (fn: (s: S, prev: S) => void) => () => void, reset: () => void }}
 */
export function createStore(initial) {
  let state = { ...initial };
  const listeners = new Set();

  const notify = (prev) => {
    for (const fn of [...listeners]) {
      try { fn(state, prev); } catch (err) { console.error('[store] listener failed', err); }
    }
  };

  return {
    get: () => state,
    set(patch) {
      const p = typeof patch === 'function' ? patch(state) : patch;
      if (!p || typeof p !== 'object') return;
      const prev = state;
      state = { ...state, ...p };
      notify(prev);
    },
    patch(key, value) {
      const cur = state[key];
      const p = typeof value === 'function' ? value(cur) : value;
      if (!p || typeof p !== 'object') return;
      const prev = state;
      state = { ...state, [key]: { ...(cur && typeof cur === 'object' ? cur : {}), ...p } };
      notify(prev);
    },
    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },
    reset() {
      const prev = state;
      state = { ...initial };
      notify(prev);
    },
  };
}

/** Fresh (empty) match slice. */
export const emptyMatch = () => ({ public: null, private: null, field: null, result: null, battle: null });

/** Initial app state (exported for tests and resets). */
export const initialState = Object.freeze({
  connection: { status: 'idle', ping: null, attempt: 0, retryAt: 0, lastError: null, everOnline: false },
  me: { playerId: null, name: '', token: null },
  // `preloadRequired` / `preloadReady` are the resource-pack entry gate (缺口 3, DESIGN §28.13.3): a C-layer panel
  // raises the first and lowers the second, and `selectRoute` holds the title screen while
  // `preloadRequired && !preloadReady`. Both default to `false`, so with no pack declaring one the gate is inert and
  // every route decision is exactly what it was — the fields are additive, nothing else reads them.
  session: { entered: false, preloadRequired: false, preloadReady: false },
  content: null,
  // how many unofficial plugins the server has (DESIGN §32 P1a: /healthz or welcome `content.plugins`; content.js)
  installedPlugins: 0,
  // A language-only installation may have announcements without an unofficial plugin count.
  installedNotices: false,
  room: null,
  // welcome.testMode (DESIGN §34.8). The server omits the key when the switch is off; the client cannot set it.
  testMode: false,
  match: emptyMatch(),
  ticker: [],
  emotes: [],
  clock: { offset: 0, rtt: null, synced: false },
  ui: { pendingJoin: null, pendingPlaytest: null, restoring: false, buildStale: false, xieRoom: false, p2p: false },
  // 工坊 mod set (W-A, DESIGN §28.9): `available` = the packs `welcome.mods` declared (empty on a plain install, so the
  // lobby's picker stays hidden), `selected` = the host's picks for the next room it creates. The values themselves live
  // in public/js/roomMods.js; this slice is what the UI renders from.
  roomMods: { available: [], selected: [] },
  // 官方版本（DESIGN §35.23）：`versions` = 服务器启用的版本列表（main.js 的 welcome 写入；null = 开关关闭）；
  // `lobbyVersion` = 本浏览器的大厅选择（与核心 store 同口径）—— 缺了它刷新页面后大厅版本偏好不会被恢复。
  versions: null,
  lobbyVersion: (() => { const v = loadPref('lobby.version', null); return typeof v === 'string' && v.length <= 40 ? v : null; })(),
});

/** The app-wide store singleton. */
export const store = createStore(initialState);

/**
 * Whether the resource-pack entry gate is holding the client on the title screen (缺口 3, DESIGN §28.13.3).
 *
 * This is **not a security boundary** — it decides what the player sees, not what the server accepts (that is the
 * pack-declared `server.preDispatch` hook). It is one expression used by `selectRoute` and by `main.js`'s two deep-link
 * consumers, so 「未就绪也能进」 cannot come back through a `?room=` / `?playtest=` link or through the localStorage
 * "already entered" flag.
 * @param {any} s store state
 * @returns {boolean}
 */
export function entryGateBlocked(s) {
  return !!(s?.session?.preloadRequired && !s.session.preloadReady);
}

/**
 * Which screen the router shows for a given app state:
 * not entered → title; the pack entry gate is closed → title; m.public.phase ≠ LOBBY or room.inMatch → game; in a room
 * → room; else lobby.
 * @param {any} s store state
 * @returns {'title'|'lobby'|'room'|'game'}
 */
export function selectRoute(s) {
  if (!s?.session?.entered) return 'title';
  // 入口闸门（缺口 3）：只在 `preloadRequired` 时加条件，所以没有包声明预载时这一行等价于不存在；`entered` 由
  // `identity.wasEntered()`（public/js/net.js）在开机时就能置真 —— 那条 localStorage 旁路因此进不了大厅。
  if (entryGateBlocked(s)) return 'title';
  const phase = s.match?.public?.phase;
  if (phase && phase !== PHASE.LOBBY) return 'game';
  if (s.room?.inMatch) return 'game'; // match starting: m.public is on its way
  if (s.room) return 'room';          // a created room wins: the 协同共竞 page only owns the BEFORE state
  if (s.ui?.xieRoom) return 'xie';    // 协同共竞 entry: its own room-creation page, not the lobby
  return 'lobby';
}

/**
 * Whether the player holds one of the room's spectator seats (room.state `spectators`; community report #26, a remake
 * feature): it is no player of the room or its match, watches like an eliminated player and may not act.
 * @param {any} room room.state payload
 * @param {string|null|undefined} playerId
 * @returns {boolean}
 */
export function isSpectating(room, playerId) {
  return playerId != null && Array.isArray(room?.spectators) && room.spectators.some((s) => s && s.playerId === playerId);
}

/**
 * The notice after a `welcome` that starts a brand-new server session (the server restarted, or this session expired
 * on it: a new playerId) while a room or a match was on screen — everything shown is gone. Null when nothing is lost
 * (the first welcome, a resumed session, only the title / lobby on screen).
 * @param {any} prev store state before the welcome
 * @param {string|null|undefined} playerId the welcome's playerId
 * @returns {string|null}
 */
export function sessionResetNotice(prev, playerId) {
  const prevId = prev?.me?.playerId;
  if (prevId == null || prevId === playerId) return null;
  if (prev?.match?.public || prev?.room?.inMatch) return t('服务器会话已重置，上一局模拟已结束');
  if (prev?.room) return t('服务器会话已重置，已返回大厅');
  return null;
}

/**
 * Current server time in ms since epoch, corrected by the measured clock offset.
 * @returns {number}
 */
export function serverNow() {
  const off = store.get().clock?.offset;
  return Date.now() + (Number.isFinite(off) ? off : 0);
}

/**
 * Shallow equality for plain objects / arrays (use as `useStore(sel, shallowEqual)`).
 * @param {any} a
 * @param {any} b
 * @returns {boolean}
 */
export function shallowEqual(a, b) {
  if (Object.is(a, b)) return true;
  if (!a || !b || typeof a !== 'object' || typeof b !== 'object') return false;
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  const ka = Object.keys(a);
  const kb = Object.keys(b);
  if (ka.length !== kb.length) return false;
  for (const k of ka) if (!Object.prototype.hasOwnProperty.call(b, k) || !Object.is(a[k], b[k])) return false;
  return true;
}

// ---- tiny persisted preferences (localStorage, failure-tolerant) --------------------------------

/**
 * Read a JSON preference from localStorage.
 * @template T
 * @param {string} key
 * @param {T} fallback
 * @returns {T}
 */
export function loadPref(key, fallback) {
  try {
    const raw = globalThis.localStorage?.getItem(`sp.pref.${key}`);
    return raw == null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

/**
 * Write a JSON preference to localStorage (silently ignores quota/privacy errors).
 * @param {string} key
 * @param {any} value
 */
export function savePref(key, value) {
  try { globalThis.localStorage?.setItem(`sp.pref.${key}`, JSON.stringify(value)); } catch { /* ignore */ }
}

const identity = (s) => s;

/**
 * Preact hook: subscribe to a slice of a store. Re-renders only when the selected value changes
 * (by `isEqual`, default `Object.is`).
 * @template S, T
 * @param {(s: S) => T} [selector]
 * @param {(a: T, b: T) => boolean} [isEqual]
 * @param {ReturnType<typeof createStore>} [target] store to read (defaults to the app store)
 * @returns {T}
 */
export function useStore(selector = identity, isEqual = Object.is, target = store) {
  const [, force] = useReducer((c) => c + 1, 0);
  const selRef = useRef(selector);
  const eqRef = useRef(isEqual);
  selRef.current = selector;
  eqRef.current = isEqual;

  let value;
  try { value = selector(target.get()); } catch (err) { console.error('[store] selector failed', err); value = undefined; }
  const valRef = useRef(value);
  valRef.current = value;

  useLayoutEffect(() => {
    const check = (s) => {
      let next;
      try { next = selRef.current(s); } catch { return; }
      if (!eqRef.current(next, valRef.current)) force();
    };
    const unsub = target.subscribe(check);
    check(target.get()); // catch updates between render and subscription
    return unsub;
  }, [target]);

  return value;
}
