// js/ai/scoringWorker.js — ai-scoring 自有的评分 Worker（不动基座 public/js/battle/rehearsalWorker.js）。
// (i18n-ignore-file: 日志与错误消息是诊断输出，不进 UI —— 见 docs/I18N.md)
//
// 为什么单独一个 Worker（审计 2026-10-21）：
//   基座 rehearsalWorker 是「托管彩排」的一半，只认 {t:'data'}/{t:'rehearsal'}、只回胜者 index（score 故意不外泄）；
//   而本地评分需要「玩家布阵 → 一个可复现的分数」。两者数据面也不同：真实回合的波次权威值（seed/pick/mods）
//   浏览器拿不到。所以这里跑「确定性标准场景」：官方第 1 回合模板波次 + 固定 seed，玩家布阵在其中真打一场
//   Battle，分数 = -1000×counted漏怪 + 击杀 − 0.01×序号（与 server/sim/rehearsal.js 同式，RehearsalRun 同款
//   tick cap 与早停）。语义是「布阵库内排序用的场景分」，不是对该回合真实战斗的预测。
//
//   postMessage → { t: 'ready' }                          一次，脚本评估完毕
//   onmessage ← { t: 'score', taskId, id, cells, ... }     一条候选布阵（cells = [{id,golden,row,col,dir}]）
//   postMessage → { t: 'done', taskId, results:[{index,built,leaks,kills,score}] } | { t:'error', taskId, message }
//
// 中断 = 调用方 terminate 本 Worker（与基座 battle/rehearsal.js 一致：模拟切片之间读不到消息）。

const SIM_URL = '/js/battle/simLoader.js';

let simPromise = null; // loadBrowserSim 的冻结数据 + DataSource（每 Worker 实例一次）
let configCache = null; // /data/config.json：标准场景的模板/时限来源（simLoader 的 raw 不含 config）

async function sim() {
  if (!simPromise) simPromise = import(SIM_URL).then((m) => m.loadBrowserSim());
  if (!configCache) {
    configCache = await fetch('/data/config.json', { cache: 'no-cache' })
      .then((r) => (r && r.ok ? r.json() : {}))
      .catch(() => ({}));
  }
  return simPromise;
}

/** 标准场景配方：mode 的第 1 回合模板波次 + 首个官方 stage + 模板时限（全固定 ⇒ 可复现、可比）。 */
function scenarioFor(task, raw) {
  const modes = (configCache && configCache.modes) || {};
  const cfg = modes[task?.modeId] || modes.mode_single_normal || Object.values(modes)[0] || {};
  const rd = (cfg.rounds && (cfg.rounds['1'] || cfg.rounds[1])) || {};
  const waves = raw.waves || {};
  const tpl = (rd.template && waves[rd.template]) || Object.values(waves)[0] || null;
  const tl = Number(rd.combatTimeLimit) || Number(tpl?.maxPlayTime) || 45;
  const stageId = Object.keys(raw.stages || {})[0] || null;
  return { tpl, timeLimit: tl, stageId };
}

async function score(task) {
  const s = await sim();
  const { buildBattleSpec, createBattleFromSpec } = s.spec;
  const { RehearsalRun, rehearsalCap } = await import('/sim/rehearsal.js');
  const scen = scenarioFor(task, s.raw);
  if (!scen.tpl || !scen.stageId) throw new Error('no standard scenario available');
  // waves 模板 → spec（key→enemyKey；slot/branches 丢弃；敌人用模板基准属性，不乘 enemyScale——固定可比）
  const units = (Array.isArray(task.cells) ? task.cells : [])
    .filter((c) => c && typeof c.id === 'string' && c.id
      && Number.isInteger(c.row) && Number.isInteger(c.col)
      && c.row >= 9 && c.row <= 12 && c.col >= 2 && c.col <= 10)
    .map((c) => ({ chessId: c.id, row: c.row, col: c.col, ...(c.dir ? { dir: c.dir } : {}) }));
  if (units.length < 2) throw new Error('task has no legal cells');
  const spawns = (scen.tpl.spawns || [])
    .filter((sp) => sp && Number.isFinite(Number(sp.time)))
    .map((sp) => ({ time: Number(sp.time), enemyKey: sp.key, count: Number(sp.count) || 1,
      interval: Number(sp.interval) || 0, routeIndex: Number(sp.routeIndex) || 0 }));
  const spec = buildBattleSpec({
    kind: 'normal', seed: 1, modeId: task.modeId || null, round: 1, stageId: scen.stageId,
    timeLimit: scen.timeLimit, players: [{ playerId: 'p1', side: 'L', units }],
    spawns, routes: JSON.parse(JSON.stringify(scen.tpl.routes || [])),
  });
  const built = [];
  const run = new RehearsalRun([() => { const b = createBattleFromSpec(spec, s.ds, { quiet: true, recordEvents: false }); built.push(b); return b; }], 'p1', rehearsalCap(scen.timeLimit));
  run.run();
  if (!built.length) throw new Error('battle not built');
  const r = built[0].result();
  const pp = r && r.perPlayer && r.perPlayer.p1;
  if (!pp || !isFinite(run.score.score)) throw new Error('no result for standard scenario');
  return [{ index: 0, built: built.length, leaks: run.score.leaks, kills: pp.killed || 0, score: run.score.score }];
}

self.postMessage({ t: 'ready' });

self.onmessage = (ev) => {
  const msg = ev && ev.data;
  if (!msg || msg.t !== 'score') return; // 基座 Worker 同款纪律：不认识的消息静默忽略
  const taskId = msg.taskId != null ? msg.taskId : msg.id;
  score(msg).then(
    (results) => self.postMessage({ t: 'done', taskId, results }),
    (e) => self.postMessage({ t: 'error', taskId, message: String((e && e.message) || e) }),
  );
};
