// server/hubVideo.js — 大厅「视频背景」的同源取流（mod: hub-video）
//
// The lobby page runs under a strict CSP (connect-src / media-src / img-src are 'self'), so a Bilibili page
// URL or a remote video can never be handed to <video> directly. This module is the one same-origin door:
//
//   GET /hub-video/resolve?url=<page or media URL>  -> JSON: kind, title, cover, duration, segments[]
//   GET /hub-video/s/<token>                        -> the bytes (Range / HEAD forwarded)
//   GET /hub-video/cover?u=<bilibili image URL>     -> the cover (hdslb.com only)
//
// A resolved upstream lives in an in-memory token map for two hours; /resolve is called again by the client
// whenever a stream 403s, so expiring Bilibili CDN signatures are harmless. Nothing is written to disk and
// nothing is uploaded: the client keeps its own playlist and local files in IndexedDB.
//
// Safety: only http(s); loopback / private / link-local addresses are refused (also after redirects); the
// Bilibili API is called with the normal browser UA + Referer; the stream endpoint only serves tokens that
// this process minted, never an arbitrary caller-supplied URL.
// (i18n-ignore-file: server diagnostics are Chinese by design)

import { Readable } from 'node:stream';
import { randomBytes } from 'node:crypto';
import dns from 'node:dns/promises';
import net from 'node:net';
import { sendError, sendJson } from './http/common.js';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const BILI_REFERER = 'https://www.bilibili.com/';
const TOKEN_TTL = 2 * 60 * 60 * 1000;
const TOKEN_MAX = 2000;
const JSON_MAX = 2 * 1024 * 1024;
const IMAGE_MAX = 8 * 1024 * 1024;
const API_TIMEOUT = 15000;

/** quality id -> the label the panel shows. */
const QUALITY = { 16: '360P', 32: '480P', 64: '720P', 74: '720P60', 80: '1080P', 112: '1080P+', 116: '1080P60', 120: '4K' };

/** Bilibili error codes that a player can act on. */
const BILI_ERRORS = {
  '-404': '视频不存在或已被删除',
  '-403': '没有权限播放这个视频',
  62002: '视频不可见（可能已删除或设为私密）',
  62004: '视频正在审核中',
  87007: '充电专属视频，无法直接播放',
  87008: '该视频需要大会员',
  '-10403': '该视频受地区限制',
};

/** token -> { url, headers, expires }. Only this process can create one. */
const tokens = new Map();
/** "<bvid|aid>:<cid>:<page>" -> { value, expires }: /resolve is called on every play, the CDN URL itself expires. */
const resolved = new Map();

function prune(now = Date.now()) {
  for (const [k, v] of tokens) if (v.expires <= now) tokens.delete(k);
  for (const [k, v] of resolved) if (v.expires <= now) resolved.delete(k);
  // a pathological client cannot grow the maps without bound
  while (tokens.size > TOKEN_MAX) tokens.delete(tokens.keys().next().value);
  while (resolved.size > 500) resolved.delete(resolved.keys().next().value);
}

function putToken(url, headers = {}, ttl = TOKEN_TTL, type = '') {
  prune();
  const token = randomBytes(18).toString('hex');
  tokens.set(token, { url, headers, expires: Date.now() + ttl, type });
  return token;
}

/** Loopback / private / link-local / CGNAT / metadata: never fetched by this proxy. */
function privateIp(ip) {
  if (!ip) return true;
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31)
      || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
  }
  const s = ip.toLowerCase();
  return s === '::1' || s === '::' || s.startsWith('fc') || s.startsWith('fd') || s.startsWith('fe80:')
    || s.startsWith('::ffff:127.') || s.startsWith('::ffff:10.') || s.startsWith('::ffff:192.168.')
    || /^::ffff:172\.(1[6-9]|2\d|3[01])\./.test(s);
}

/** Parse + vet a remote URL. Throws a message fit for the panel. */
async function publicUrl(raw) {
  let u;
  try { u = new URL(String(raw || '').trim()); } catch { throw new Error('链接格式不对，请粘贴完整的 http(s) 地址'); }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('只支持 http / https 链接');
  const host = u.hostname.toLowerCase();
  if (!host || host === 'localhost' || host.endsWith('.local') || host.endsWith('.internal')) throw new Error('这个地址不允许访问');
  let addrs;
  if (net.isIP(host)) addrs = [{ address: host }];
  else {
    try { addrs = await dns.lookup(host, { all: true, verbatim: true }); }
    catch { throw new Error('解析不了这个网址：' + host); }
  }
  if (!addrs.length || addrs.some((a) => privateIp(a.address))) throw new Error('内网地址不允许访问');
  return u;
}

async function fetchJson(url, headers) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), API_TIMEOUT);
  try {
    const r = await fetch(url, { headers, signal: ac.signal, redirect: 'follow' });
    const text = await r.text();
    if (text.length > JSON_MAX) throw new Error('接口返回的数据太大');
    if (!r.ok) throw new Error('接口请求失败（HTTP ' + r.status + '）');
    return JSON.parse(text);
  } finally { clearTimeout(timer); }
}

const BILI_HEADERS = { 'User-Agent': UA, Referer: BILI_REFERER, 'Accept-Language': 'zh-CN,zh;q=0.9' };

/** The video id in a Bilibili page link (BV… / av…), plus the page number. */
function biliId(input) {
  const s = String(input || '').trim();
  let m = s.match(/(?:^|[/?#&=])(BV[0-9A-Za-z]{10})(?=[/?#&]|$)/);
  if (m) return { bvid: m[1], page: pageOf(s) };
  m = s.match(/(?:^|[/?#&=])av(\d+)(?=[/?#&]|$)/i);
  if (m) return { aid: Number(m[1]), page: pageOf(s) };
  if (/^BV[0-9A-Za-z]{10}$/.test(s)) return { bvid: s, page: 1 };
  if (/^av\d+$/i.test(s)) return { aid: Number(s.slice(2)), page: 1 };
  return null;
}
function pageOf(s) {
  try { const p = Number(new URL(s, 'https://www.bilibili.com/').searchParams.get('p')); return Number.isFinite(p) && p > 0 ? Math.min(100, Math.floor(p)) : 1; }
  catch { return 1; }
}
function shortLink(u) {
  const h = u.hostname.toLowerCase();
  return h === 'b23.tv' || h === 'bili2233.cn' || h === 'www.b23.tv';
}
async function expandShort(u) {
  const r = await fetch(u.href, { method: 'GET', headers: { 'User-Agent': UA }, redirect: 'manual', signal: AbortSignal.timeout(API_TIMEOUT) });
  const loc = r.headers.get('location');
  if (!loc) throw new Error('这个短链接打不开（没有跳转地址）');
  return new URL(loc, u.href);
}

async function biliView(id) {
  const q = id.bvid ? 'bvid=' + encodeURIComponent(id.bvid) : 'aid=' + id.aid;
  const j = await fetchJson('https://api.bilibili.com/x/web-interface/view?' + q, BILI_HEADERS);
  if (j.code !== 0) throw new Error(BILI_ERRORS[j.code] || ('B 站接口：' + (j.message || j.code)));
  return j.data;
}

async function biliPlay(bvid, cid) {
  let last = null;
  for (const qn of [80, 64, 32, 16]) {
    const u = 'https://api.bilibili.com/x/player/playurl?bvid=' + encodeURIComponent(bvid) + '&cid=' + encodeURIComponent(cid)
      + '&qn=' + qn + '&fnval=1&platform=html5&high_quality=1';
    const j = await fetchJson(u, BILI_HEADERS);
    if (j.code === 0 && j.data && Array.isArray(j.data.durl) && j.data.durl.length) return j.data;
    last = j;
  }
  if (last && last.code !== 0) throw new Error(BILI_ERRORS[last.code] || ('B 站接口：' + (last.message || last.code)));
  throw new Error('这个视频没有可直接播放的 MP4 流（可能只提供 DASH），换一个视频试试');
}

/** Resolve a Bilibili page / short link / bare BV id into one or more proxied segments. */
async function resolveBilibili(input) {
  let id = biliId(input);
  if (!id) {
    let u;
    try { u = new URL(input); } catch { u = null; }
    if (u && shortLink(u)) {
      const full = await expandShort(u);
      id = biliId(full.href);
    }
  }
  if (!id) throw new Error('没有认出 B 站视频号：请粘贴 https://www.bilibili.com/video/BV… 或 b23.tv 短链接');
  const view = await biliView(id);
  const pages = Array.isArray(view.pages) ? view.pages : [];
  const pageNo = Math.min(Math.max(1, id.page || 1), Math.max(1, pages.length));
  const page = pages[pageNo - 1];
  const cid = page?.cid || view.cid;
  if (!cid) throw new Error('这个视频没有可播放的分 P');
  const bvid = view.bvid;
  const key = bvid + ':' + cid;
  const hit = resolved.get(key);
  let data = hit && hit.expires > Date.now() ? hit.value : null;
  if (!data) {
    const play = await biliPlay(bvid, cid);
    data = { quality: play.quality || 16, durl: play.durl.map((d) => ({ url: d.url, length: d.length, size: d.size })) };
    resolved.set(key, { value: data, expires: Date.now() + 5 * 60 * 1000 });
  }
  const segments = data.durl.map((d) => ({
    src: '/hub-video/s/' + putToken(d.url, { Referer: BILI_REFERER }, TOKEN_TTL, 'video/mp4'),
    durationMs: Number(d.length) || 0,
    size: Number(d.size) || 0,
  }));
  const pic = String(view.pic || '').replace(/^http:/, 'https:');
  return {
    ok: true, kind: 'bilibili',
    title: String(view.title || 'B 站视频'),
    author: view.owner?.name || '',
    cover: pic ? '/hub-video/cover?u=' + encodeURIComponent(pic) : '',
    duration: Number(view.duration) || 0,
    bvid, cid, page: pageNo, pages: Math.max(1, pages.length),
    quality: QUALITY[data.quality] || String(data.quality),
    segments,
  };
}

/** fetch that follows redirects itself, so every hop goes through publicUrl() (no redirect into the LAN). */
async function safeFetch(raw, options, maxHops = 5) {
  let u = await publicUrl(raw);
  for (let hop = 0; hop <= maxHops; hop++) {
    const r = await fetch(u.href, { ...options, redirect: 'manual' });
    if (r.status >= 300 && r.status < 400) {
      const loc = r.headers.get('location');
      try { r.body?.cancel(); } catch { /* already gone */ }
      if (!loc) throw new Error('链接跳转没有目标地址');
      u = await publicUrl(new URL(loc, u.href).href);
      continue;
    }
    return { res: r, url: u.href };
  }
  throw new Error('链接跳转次数太多');
}

/** The first response of a direct media URL (Range 0-1 keeps it cheap) decides whether it is playable. */
async function probeDirect(raw) {
  const u = await publicUrl(raw);
  if (/\.m3u8(?:$|[?#])/i.test(u.pathname + u.search)) throw new Error('暂不支持 m3u8 / HLS 直播流，请换成 MP4 直链');
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), API_TIMEOUT);
  let got;
  try {
    got = await safeFetch(u.href, { headers: { 'User-Agent': UA, Range: 'bytes=0-1', 'Accept-Encoding': 'identity' }, signal: ac.signal });
  } catch (e) {
    clearTimeout(timer);
    if (e && e.message && e.message !== 'fetch failed') throw e;
    throw new Error('这个链接连不上（超时或被拒绝）');
  }
  clearTimeout(timer);
  const r = got.res;
  const type = (r.headers.get('content-type') || '').toLowerCase();
  try { r.body?.cancel(); } catch { /* already gone */ }
  if (r.status >= 400) throw new Error('这个链接返回 HTTP ' + r.status + '，无法播放');
  if (type.startsWith('text/html') || type.includes('application/json')) throw new Error('这个链接是一个网页，不是视频文件');
  let finalPath = u.pathname + u.search;
  try { const fu = new URL(got.url); finalPath = fu.pathname + fu.search; } catch { /* keep the original */ }
  const ext = /\.(mp4|webm|m4v|mov|ogv|ogg|mkv)(?:$|[?#])/i.test(finalPath);
  if (type && !type.startsWith('video/') && !type.startsWith('application/octet-stream') && !ext) {
    throw new Error('这个链接看起来不是视频（' + type.split(';')[0] + '）');
  }
  return { url: got.url, type: type.startsWith('video/') ? type.split(';')[0] : 'video/mp4' };
}

async function resolveDirect(raw) {
  const p = await probeDirect(raw);
  const token = putToken(p.url, { 'User-Agent': UA }, 30 * 60 * 1000, p.type);
  let name = '';
  try { name = decodeURIComponent(new URL(p.url).pathname.split('/').filter(Boolean).pop() || ''); } catch { /* keep empty */ }
  return {
    ok: true, kind: 'direct',
    title: name || new URL(p.url).hostname,
    cover: '', duration: 0, quality: '直链',
    segments: [{ src: '/hub-video/s/' + token, durationMs: 0, size: 0 }],
  };
}

async function handleResolve(req, res, q) {
  const raw = String(q.get('url') || '').trim();
  if (!raw) { sendJson(req, res, 200, { ok: false, error: 'EMPTY', message: '请粘贴视频链接' }); return; }
  try {
    let bili = biliId(raw);
    if (!bili) {
      try {
        const u = new URL(raw);
        if (shortLink(u)) bili = { short: true };
        else if (/(^|\.)bilibili\.com$/i.test(u.hostname) || /(^|\.)b23\.tv$/i.test(u.hostname)) bili = { short: true };
      } catch { /* a direct URL may still be valid */ }
    }
    const out = bili ? await resolveBilibili(raw) : await resolveDirect(raw);
    sendJson(req, res, 200, out);
  } catch (e) {
    sendJson(req, res, 200, { ok: false, error: 'RESOLVE', message: e?.message || '解析失败，换一个链接试试' });
  }
}

function copyHeaders(up, res, fallbackType) {
  const raw = up.headers.get('content-type');
  // some Bilibili / CDN edges answer application/octet-stream; the token knows what it really is
  const ct = !raw || /octet-stream/i.test(raw) ? (fallbackType || raw) : raw;
  const len = up.headers.get('content-length');
  const range = up.headers.get('content-range');
  const ranges = up.headers.get('accept-ranges');
  if (ct) res.setHeader('Content-Type', ct);
  // fetch has already decoded the body: a gzip upstream's length would not match the bytes we pipe
  if (len && !up.headers.get('content-encoding')) res.setHeader('Content-Length', len);
  if (range) res.setHeader('Content-Range', range);
  if (ranges) res.setHeader('Accept-Ranges', ranges);
  res.setHeader('Cache-Control', 'private, max-age=0');
}

async function handleStream(req, res, token) {
  const entry = tokens.get(token);
  if (!entry || entry.expires <= Date.now()) {
    sendError(req, res, 404, '视频地址已过期 · Video URL expired', '重新打开这个视频即可');
    return;
  }
  const headers = { 'User-Agent': UA, 'Accept-Encoding': 'identity', ...entry.headers };
  if (req.headers.range) headers.Range = req.headers.range;
  if (req.headers['if-range']) headers['If-Range'] = req.headers['if-range'];
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), 20000);
  let up;
  try {
    up = (await safeFetch(entry.url, { headers, signal: ac.signal }, 3)).res;
  } catch (e) {
    clearTimeout(timer);
    sendError(req, res, 502, '取不到视频流 · Upstream failed', e?.name === 'AbortError' ? '上游超时' : '上游没有响应');
    return;
  }
  clearTimeout(timer);
  if (!up.ok && up.status !== 206) {
    try { up.body?.cancel(); } catch { /* ignore */ }
    sendError(req, res, 502, '视频流被上游拒绝 · Upstream HTTP ' + up.status, '视频地址可能已过期，重新打开即可');
    return;
  }
  res.statusCode = up.status;
  copyHeaders(up, res, entry.type);
  if (req.method === 'HEAD' || !up.body) {
    try { up.body?.cancel(); } catch { /* ignore */ }
    res.end();
    return;
  }
  const stream = Readable.fromWeb(up.body);
  const stop = () => {
    ac.abort();
    try { stream.destroy(); } catch { /* ignore */ }
  };
  res.on('close', stop);
  stream.on('error', () => { try { res.destroy(); } catch { /* ignore */ } });
  stream.pipe(res);
}

const IMAGE_HOSTS = /(^|\.)(hdslb\.com|biliimg\.com)$/i;
async function handleCover(req, res, q) {
  let u;
  try { u = new URL(String(q.get('u') || '')); } catch { sendError(req, res, 400, '封面地址无效 · Bad cover'); return; }
  if (!/^https?:$/.test(u.protocol) || !IMAGE_HOSTS.test(u.hostname)) { sendError(req, res, 403, '封面地址不在白名单 · Cover host not allowed'); return; }
  if (u.protocol === 'http:') u.protocol = 'https:';
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), API_TIMEOUT);
  let up;
  try {
    up = await fetch(u.href, { headers: { 'User-Agent': UA, Referer: BILI_REFERER }, signal: ac.signal, redirect: 'follow' });
  } catch { clearTimeout(timer); sendError(req, res, 502, '取不到封面 · Cover failed'); return; }
  clearTimeout(timer);
  try { if (!IMAGE_HOSTS.test(new URL(up.url).hostname)) { try { up.body?.cancel(); } catch { /* ignore */ } sendError(req, res, 502, '封面跳转到了白名单外 · Cover redirect'); return; } } catch { /* keep the original host check */ }
  const type = up.headers.get('content-type') || '';
  const len = Number(up.headers.get('content-length') || 0);
  if (!up.ok || !/^image\//i.test(type) || len > IMAGE_MAX) {
    try { up.body?.cancel(); } catch { /* ignore */ }
    sendError(req, res, 502, '取不到封面 · Cover failed');
    return;
  }
  const buf = Buffer.from(await up.arrayBuffer());
  if (buf.length > IMAGE_MAX) { sendError(req, res, 502, '封面太大 · Cover too large'); return; }
  res.writeHead(200, {
    'Content-Type': type, 'Content-Length': buf.length, 'Cache-Control': 'public, max-age=86400',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(req.method === 'HEAD' ? undefined : buf);
}

/**
 * The /hub-video/… dispatcher, called from server/http/routes.js before the static files.
 * @returns {Promise<void>}
 */
export async function handleHubVideo(req, res, parts) {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.setHeader('Allow', 'GET, HEAD');
    sendError(req, res, 405, '不支持的请求方法 · Method not allowed');
    return;
  }
  const path = parts.rawPath;
  if (path === '/hub-video/resolve') { await handleResolve(req, res, new URLSearchParams(parts.query)); return; }
  if (path.startsWith('/hub-video/s/')) {
    const token = path.slice('/hub-video/s/'.length);
    if (!/^[0-9a-f]{36}$/.test(token)) { sendError(req, res, 404, '视频地址无效 · Bad video URL'); return; }
    await handleStream(req, res, token);
    return;
  }
  if (path === '/hub-video/cover') { await handleCover(req, res, new URLSearchParams(parts.query)); return; }
  if (path === '/hub-video/ping') { sendJson(req, res, 200, { ok: true, tokens: tokens.size, resolved: resolved.size }); return; }
  sendError(req, res, 404, '没有这个视频接口 · Not found');
}
