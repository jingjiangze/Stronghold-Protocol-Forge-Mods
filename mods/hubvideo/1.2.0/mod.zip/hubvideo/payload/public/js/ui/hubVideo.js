
// 视频背景 — a standalone module: up to VIDEO_MAX videos (local files or links), one native <video> on the hub,
// its own IndexedDB ('sp-hub-video') and its own localStorage pref ('hub.video'), the whole 视频背景 panel of the
// 大厅背景 dialog and the keyboard transport (↑↓ volume, ←→ seek, a double ←/→ for the previous / next video,
// Space pause). ui/hubBackdrop.js only imports useVideo / VideoStage / VideoPanel / VideoGlyph and composes them.
//
// A local file stays on this device: the file is kept as a Blob in IndexedDB, its poster as a small JPEG data URL and
// only the order + settings go into the pref. A link is resolved through the game's own server (/hub-video/resolve)
// because the page's CSP forbids talking to Bilibili directly; the server hands back a same-origin stream token, so
// <video> can play it like any local file and every transport control works the same for both kinds.
import { html } from './components.js';
import { useEffect, useMemo, useRef, useState } from '../../vendor/hooks.module.js';
import { loadPref, savePref } from '../store.js';
import { audio } from '../audio.js';
import { toast } from './toasts.js';

export const VIDEO_MAX = 20;
export const VIDEO_ACCEPT = 'video/*,.mp4,.webm,.m4v,.mov,.ogv,.ogg,.mkv,.avi';
/** The three ways a finished video hands over to the next one. */
export const VIDEO_PLAY_MODES = [
  { id: 'single', name: '单体循环', en: 'LOOP ONE', hint: '当前视频放完重头再来，不切换。' },
  { id: 'shuffle', name: '随机播放', en: 'SHUFFLE', hint: '当前视频放完，从列表里随机换一个（不会连续播同一个）。' },
  { id: 'list', name: '列表播放', en: 'PLAYLIST', hint: '当前视频放完，按列表顺序播下一个；最后一个播完回到第一个。' },
];
const PLAY_MODE_IDS = VIDEO_PLAY_MODES.map((x) => x.id);
const PREF_KEY = 'hub.video';
const DB_NAME = 'sp-hub-video';
const DB_VERSION = 1;
const STORE = 'videos';
const VIDEO_MAX_BYTES = 512 * 1024 * 1024;
const ID_CHARS = '0123456789abcdefghijklmnopqrstuvwxyz';
const URL_RE = /^https?:\/\//i;
const FILE_EXT = /\.(mp4|webm|m4v|mov|ogv|ogg|mkv|avi)$/i;

const num = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const fmtTime = (s) => {
  const n = Math.max(0, Math.floor(Number(s) || 0));
  const h = Math.floor(n / 3600);
  const m = Math.floor((n % 3600) / 60);
  const r = n % 60;
  return (h ? h + ':' + String(m).padStart(2, '0') : String(m)) + ':' + String(r).padStart(2, '0');
};

// ---- the video store: this module's own IndexedDB (Blobs, no base64 bloat, no localStorage quota) ----------------
function openDb() {
  return new Promise((resolve, reject) => {
    if (!globalThis.indexedDB) { reject(new Error('no indexedDB')); return; }
    const open = indexedDB.open(DB_NAME, DB_VERSION);
    open.onupgradeneeded = () => {
      const db = open.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' });
    };
    open.onerror = () => reject(open.error);
    open.onsuccess = () => resolve(open.result);
  });
}
function withStore(mode, fn) {
  return openDb().then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, mode);
    const rq = fn(tx.objectStore(STORE));
    tx.oncomplete = () => { db.close(); resolve(rq ? rq.result : undefined); };
    tx.onerror = tx.onabort = () => { db.close(); reject(tx.error); };
  }));
}
const getAll = () => withStore('readonly', (s) => s.getAll());
const putRow = (row) => withStore('readwrite', (s) => s.put(row));
const delRow = (id) => withStore('readwrite', (s) => s.delete(id));
const clearAll = () => withStore('readwrite', (s) => s.clear());

function videoId() {
  let s = '';
  for (let i = 0; i < 12; i++) s += ID_CHARS[(Math.random() * ID_CHARS.length) | 0];
  return Date.now().toString(36) + s;
}

// ---- the pref: the playlist + its transport settings; sanitised on every read ----------------------------------
function cleanText(v, max) { return typeof v === 'string' ? v.slice(0, max) : ''; }
function sanitizeItem(x) {
  if (!x || typeof x.id !== 'string' || !x.id) return null;
  const id = cleanText(x.id, 40);
  if (x.kind === 'url') {
    const url = cleanText(x.url, 2000);
    if (!URL_RE.test(url)) return null;
    return {
      id, kind: 'url', name: cleanText(x.name, 120) || '视频链接', url,
      site: x.site === 'bilibili' ? 'bilibili' : 'direct',
      bvid: cleanText(x.bvid, 24), page: clamp(num(x.page, 1), 1, 100),
      cover: cleanText(x.cover, 600), duration: Math.max(0, num(x.duration, 0)),
      quality: cleanText(x.quality, 24),
    };
  }
  if (x.kind !== 'file') return null;
  return {
    id, kind: 'file', name: cleanText(x.name, 120) || '本地视频',
    duration: Math.max(0, num(x.duration, 0)), width: Math.max(0, Math.round(num(x.width, 0))),
    height: Math.max(0, Math.round(num(x.height, 0))),
  };
}
/** The video pref, sanitised — a device that never used it simply gets the defaults. */
export function loadVideoPref() {
  const raw = loadPref(PREF_KEY, null);
  const o = raw && typeof raw === 'object' ? raw : {};
  const list = Array.isArray(o.list) ? o.list.map(sanitizeItem).filter(Boolean).slice(0, VIDEO_MAX) : [];
  return {
    mode: o.mode === 'video' ? 'video' : 'single',
    list,
    index: clamp(Math.floor(num(o.index, 0)), 0, Math.max(0, list.length - 1)),
    volume: clamp(num(o.volume, 0.6), 0, 1),
    muted: o.muted !== false,
    muteGame: o.muteGame !== false,
    // v1.1's two switches folded into one choice: loop on = 单体循环, autoNext on = 列表播放
    playMode: PLAY_MODE_IDS.includes(o.playMode) ? o.playMode : (o.loop === false && o.autoNext === true ? 'list' : 'single'),
    paused: o.paused === true,
  };
}

// ---- one picked local file: decode, read its metadata, grab a small poster -------------------------------------
function drawPoster(v) {
  const W = 320; const H = 180;
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const g = c.getContext('2d');
  g.fillStyle = '#0b1110'; g.fillRect(0, 0, W, H);
  const vw = v.videoWidth || 16; const vh = v.videoHeight || 9;
  const k = Math.max(W / vw, H / vh);
  g.drawImage(v, (W - vw * k) / 2, (H - vh * k) / 2, vw * k, vh * k);
  return c.toDataURL('image/jpeg', 0.72);
}
/** @returns {Promise<{duration:number,width:number,height:number,poster:string}>} */
function probeVideoFile(file) {
  const type = file.type || '';
  const ext = (String(file.name || '').match(FILE_EXT) || [])[0] || '';
  if (!type.startsWith('video/') && !ext) throw new Error('不是视频文件');
  if (!file.size) throw new Error('文件是空的');
  if (file.size > VIDEO_MAX_BYTES) throw new Error('超过 512MB 上限');
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const v = document.createElement('video');
    v.preload = 'metadata'; v.muted = true; v.playsInline = true;
    let done = false;
    let timer = 0;
    const finish = (fn) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      v.onloadedmetadata = null; v.onseeked = null; v.onerror = null;
      try { v.removeAttribute('src'); v.load(); } catch { /* ignore */ }
      URL.revokeObjectURL(url);
      fn();
    };
    timer = setTimeout(() => finish(() => reject(new Error('读取超时，换一个文件试试'))), 15000);
    v.onerror = () => finish(() => reject(new Error('浏览器无法播放这个视频（编码不受支持）')));
    v.onloadedmetadata = () => {
      if (!v.videoWidth || !v.videoHeight) { finish(() => reject(new Error('这个文件没有画面'))); return; }
      const meta = {
        duration: Number.isFinite(v.duration) ? v.duration : 0,
        width: v.videoWidth, height: v.videoHeight, poster: '',
      };
      const capture = () => {
        try { meta.poster = drawPoster(v); } catch { /* a codec that cannot draw still plays */ }
        finish(() => resolve(meta));
      };
      if (meta.duration > 0.2) {
        v.onseeked = capture;
        try { v.currentTime = Math.min(1, meta.duration * 0.15); } catch { capture(); }
      } else capture();
    };
    v.src = url;
  });
}

// ---- the public hook ---------------------------------------------------------------------------------------------
/**
 * The video background's state and transport. Pass it to <VideoStage> (the lobby layer) and <VideoPanel> (the
 * 大厅背景 dialog); the pref, the local files and the resolved stream all live here.
 * @returns {object}
 */
export function useVideo() {
  const [pref, setPref] = useState(loadVideoPref);
  const prefRef = useRef(pref); prefRef.current = pref;
  /** patch is a whole-pref object or a function of the latest pref: every write goes through here. */
  const update = (patch) => setPref((p) => {
    const next = typeof patch === 'function' ? { ...p, ...patch(p) } : { ...p, ...patch };
    savePref(PREF_KEY, next);
    return next;
  });

  const [blobs, setBlobs] = useState(() => new Map()); // id -> Blob (the pref only keeps the order)
  const [posters, setPosters] = useState(() => new Map()); // id -> small JPEG data URL
  const urlRef = useRef(new Map()); // id -> object URL (not state: the map itself is replaced on change)
  const [urls, setUrls] = useState(() => new Map());
  const [ready, setReady] = useState(false);
  const [el, setEl] = useState(null);
  const attach = useMemo(() => (node) => setEl((prev) => (prev === node ? prev : node)), []);
  const [source, setSource] = useState({ loading: false, error: '', segments: [], quality: '', title: '' });
  const [segIndex, setSegIndex] = useState(0);
  const [play, setPlay] = useState({ time: 0, duration: 0, buffered: 0, playing: false, waiting: false, error: '' });
  const [reload, setReload] = useState(0);
  const [hud, setHud] = useState(null);
  const hudTimer = useRef(0);
  const preResolved = useRef(new Map()); // url item id -> the last /resolve answer (a few minutes)
  const retried = useRef(new Map()); // url item id -> when its stream was last re-resolved
  const lastTap = useRef({ key: null, at: 0 });
  const live = useRef({});

  // 1. what this browser kept from earlier visits
  useEffect(() => {
    let dead = false;
    (async () => {
      try {
        const rows = await getAll();
        if (dead || !Array.isArray(rows)) return;
        const b = new Map(); const p = new Map();
        for (const r of rows) if (r && typeof r.id === 'string' && r.blob instanceof Blob) {
          b.set(r.id, r.blob);
          if (typeof r.poster === 'string' && r.poster.startsWith('data:image/')) p.set(r.id, r.poster);
        }
        setBlobs(b); setPosters(p);
      } catch { /* nothing readable: the panel simply starts empty */ }
      finally { if (!dead) setReady(true); }
    })();
    return () => { dead = true; };
  }, []);

  // 2. one object URL per stored file, revoked when the file leaves the playlist
  useEffect(() => {
    const m = urlRef.current;
    let changed = false;
    for (const [id, blob] of blobs) if (!m.has(id)) { m.set(id, URL.createObjectURL(blob)); changed = true; }
    for (const [id, url] of [...m]) if (!blobs.has(id)) { URL.revokeObjectURL(url); m.delete(id); changed = true; }
    if (changed) setUrls(new Map(m));
  }, [blobs]);
  useEffect(() => () => { for (const url of urlRef.current.values()) URL.revokeObjectURL(url); urlRef.current.clear(); }, []);

  // 3. the playlist: a file whose Blob vanished is left out (the pane names the gap)
  const entries = useMemo(() => pref.list.map((x) => {
    if (x.kind === 'url') return x;
    if (!blobs.has(x.id)) return null;
    return { ...x, poster: posters.get(x.id) || '', objectUrl: urls.get(x.id) || '' };
  }).filter(Boolean), [pref.list, blobs, posters, urls]);
  const missing = pref.list.length - entries.length;
  const index = entries.length ? clamp(pref.index, 0, entries.length - 1) : 0;
  const current = entries[index] || null;
  live.current = { pref, prefRef, entries, index, current, source, segIndex, play, el };

  // 视频背景开着时，游戏自己的 BGM / 音效 / 干员语音全部让位（视频元素不在 Web Audio 总线上，声音照常）
  const gameMuted = pref.mode === 'video' && !!current && pref.muteGame;
  useEffect(() => {
    audio.setVideoMuted?.(gameMuted);
    return () => audio.setVideoMuted?.(false);
  }, [gameMuted]);

  // 4. resolve the current item into a same-origin source: a Blob URL for a local file, /hub-video/s/<token> for a link
  useEffect(() => {
    if (!current) {
      setSource({ loading: false, error: '', segments: [], quality: '', title: '' });
      setSegIndex(0);
      return undefined;
    }
    let dead = false;
    setSegIndex(0);
    setSource({ loading: true, error: '', segments: [], quality: '', title: current.name });
    setPlay((p) => ({ ...p, time: 0, duration: Number(current.duration) || 0, buffered: 0, error: '' }));
    (async () => {
      try {
        if (current.kind === 'file') {
          const url = urlRef.current.get(current.id);
          if (!url) throw new Error('本机存储里找不到这个视频，请重新添加');
          if (!dead) setSource({ loading: false, error: '', segments: [{ src: url }], quality: '本地', title: current.name });
          return;
        }
        let j = preResolved.current.get(current.id);
        if (j && Date.now() - j.at > 4 * 60 * 1000) { preResolved.current.delete(current.id); j = null; }
        if (!j) {
          const r = await fetch('/hub-video/resolve?url=' + encodeURIComponent(current.url), { cache: 'no-store' });
          if (!r.ok) throw new Error('这台服务器还没有 /hub-video/ 视频接口，请重启服务器后再试');
          j = await r.json();
          if (!j.ok) throw new Error(j.message || '链接解析失败');
          if (!Array.isArray(j.segments) || !j.segments.length) throw new Error('这个链接没有可播放的视频流');
          preResolved.current.set(current.id, { ...j, at: Date.now() });
        }
        if (dead) return;
        setSource({ loading: false, error: '', segments: j.segments, quality: j.quality || '', title: j.title || current.name });
        // fold the metadata /resolve learned back into the playlist (the stored entry may be old)
        update((p) => {
          let changed = false;
          const list = p.list.map((x) => {
            if (x.id !== current.id) return x;
            const next = { ...x, name: j.title || x.name, cover: j.cover || x.cover, duration: Number(j.duration) || x.duration, quality: j.quality || x.quality };
            if (next.name !== x.name || next.cover !== x.cover || next.duration !== x.duration || next.quality !== x.quality) { changed = true; return next; }
            return x;
          });
          return changed ? { list } : {};
        });
      } catch (e) {
        if (!dead) setSource({ loading: false, error: e?.message || '视频解析失败', segments: [], quality: '', title: current.name });
      }
    })();
    return () => { dead = true; };
  }, [current?.id, current?.url, reload]);

  // 5. the visible element follows the segment URL; it stays the same <video> across slides and segments
  const src = source.segments[segIndex]?.src || '';
  const [hidden, setHidden] = useState(() => !!(globalThis.document && document.hidden));
  useEffect(() => {
    const onVis = () => setHidden(!!document.hidden);
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);

  // the element leaving the page (single / carousel mode) must stop, or its audio would follow the hub around
  useEffect(() => {
    const v = el;
    return () => {
      if (!v) return;
      try { v.pause(); } catch { /* ignore */ }
      // the stage is gone: make sure 大厅音乐 does not stay ducked behind a paused element
      window.dispatchEvent(new CustomEvent('sp:lobby-video-audio', { detail: { active: false } }));
    };
  }, [el]);

  useEffect(() => {
    const v = el;
    if (!v) return;
    if (!src) {
      try { v.pause(); } catch { /* ignore */ }
      try { v.removeAttribute('src'); v.load(); } catch { /* ignore */ }
      return;
    }
    if (v.dataset.hvSrc !== src) {
      v.dataset.hvSrc = src;
      try { v.src = src; v.load(); } catch { /* ignore */ }
    }
  }, [el, src]);

  // 6. volume / mute are a pref, not an element state: the panel and ↑↓ share one value
  useEffect(() => {
    const v = el;
    if (!v) return;
    v.volume = clamp(pref.volume, 0, 1);
    v.muted = pref.muted || pref.volume <= 0;
  }, [el, pref.volume, pref.muted]);

  // 7. play / pause; a browser that blocks unmuted autoplay falls back to muted once
  useEffect(() => {
    const v = el;
    if (!v || !src) return;
    if (pref.paused || hidden) { try { v.pause(); } catch { /* ignore */ } return; }
    const p = v.play();
    if (p && typeof p.catch === 'function') p.catch(() => {
      v.muted = true;
      if (!prefRef.current.muted) update({ muted: true });
      v.play().catch(() => { /* the player can still start it with a click */ });
      flash('浏览器拦截了带声音的自动播放，已静音（按 ↑ 开启）');
    });
  }, [el, src, pref.paused, hidden]);

  // 8. one listener set for the element's whole life
  useEffect(() => {
    const v = el;
    if (!v) return undefined;
    const buffered = () => {
      try {
        const b = v.buffered;
        if (!b || !b.length || !Number.isFinite(v.duration) || v.duration <= 0) return 0;
        return clamp(b.end(b.length - 1) / v.duration, 0, 1);
      } catch { return 0; }
    };
    const onTime = () => setPlay((p) => ({ ...p, time: v.currentTime || 0, buffered: buffered() }));
    const onMeta = () => setPlay((p) => ({ ...p, duration: Number.isFinite(v.duration) ? v.duration : p.duration, buffered: buffered() }));
    const onPlay = () => setPlay((p) => ({ ...p, playing: true, waiting: false, error: '' }));
    const onPause = () => setPlay((p) => ({ ...p, playing: false, waiting: false }));
    const onWait = () => setPlay((p) => ({ ...p, waiting: true }));
    const onCan = () => setPlay((p) => ({ ...p, waiting: false }));
    const onProgress = () => setPlay((p) => ({ ...p, buffered: buffered() }));
    const onError = () => {
      if (!v.error) return;
      const st = live.current;
      const item = st.entries[st.index];
      const id = item && item.id;
      // a Bilibili CDN signature expires: re-resolve the page once, then report a real error
      if (item && item.kind === 'url' && id && Date.now() - (retried.current.get(id) || 0) > 20000) {
        retried.current.set(id, Date.now());
        preResolved.current.delete(id);
        setReload((n) => n + 1);
        return;
      }
      setPlay((p) => ({ ...p, playing: false, error: '视频加载失败，换一个视频试试' }));
    };
    const onEnded = () => {
      const st = live.current;
      // a multi-segment Bilibili video first plays its own segments; the play mode decides what happens after the last
      if (st.segIndex < st.source.segments.length - 1) { setSegIndex((i) => i + 1); return; }
      const mode = st.pref.playMode;
      if (st.entries.length < 2 || mode === 'single') {
        if (st.segIndex > 0) { setSegIndex(0); return; }
        try { v.currentTime = 0; } catch { /* ignore */ }
        v.play().catch(() => {});
        return;
      }
      if (mode === 'shuffle') {
        let j = st.index;
        while (j === st.index) j = Math.floor(Math.random() * st.entries.length);
        goTo(j);
        return;
      }
      goTo((st.index + 1) % st.entries.length);
    };
    v.addEventListener('timeupdate', onTime);
    v.addEventListener('durationchange', onMeta);
    v.addEventListener('loadedmetadata', onMeta);
    v.addEventListener('play', onPlay);
    v.addEventListener('playing', onPlay);
    v.addEventListener('pause', onPause);
    v.addEventListener('waiting', onWait);
    v.addEventListener('canplay', onCan);
    v.addEventListener('progress', onProgress);
    v.addEventListener('error', onError);
    v.addEventListener('ended', onEnded);
    return () => {
      v.removeEventListener('timeupdate', onTime);
      v.removeEventListener('durationchange', onMeta);
      v.removeEventListener('loadedmetadata', onMeta);
      v.removeEventListener('play', onPlay);
      v.removeEventListener('playing', onPlay);
      v.removeEventListener('pause', onPause);
      v.removeEventListener('waiting', onWait);
      v.removeEventListener('canplay', onCan);
      v.removeEventListener('progress', onProgress);
      v.removeEventListener('error', onError);
      v.removeEventListener('ended', onEnded);
    };
  }, [el]);

  // 9. 大厅音乐 (ui/lobbyMusic.js) steps aside while the video is audible; it comes back when the video is paused
  useEffect(() => {
    const audible = !pref.muted && pref.volume > 0 && !pref.paused && !hidden && play.playing;
    window.dispatchEvent(new CustomEvent('sp:lobby-video-audio', { detail: { active: audible } }));
  }, [pref.muted, pref.volume, pref.paused, hidden, play.playing]);
  useEffect(() => () => window.dispatchEvent(new CustomEvent('sp:lobby-video-audio', { detail: { active: false } })), []);

  // 10. the transport: ↑↓ volume, ←→ seek, a double ←/→ for the previous / next video, Space pause
  useEffect(() => {
    if (pref.mode !== 'video' || !entries.length) return undefined;
    const onKey = (e) => {
      if (e.defaultPrevented || e.ctrlKey || e.metaKey || e.altKey) return;
      const t = e.target;
      const tag = t && t.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || (t && t.isContentEditable)) return;
      if (document.body && document.body.classList.contains('hub-dialog-open')) return;
      if (document.querySelector('.modal, .guide')) return;
      if (e.key === ' ' || e.code === 'Space') { e.preventDefault(); togglePlay(); return; }
      if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        e.preventDefault();
        bumpVolume(e.key === 'ArrowUp' ? 0.05 : -0.05);
        return;
      }
      if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
        e.preventDefault();
        const dir = e.key === 'ArrowRight' ? 1 : -1;
        const now = performance.now();
        const last = lastTap.current;
        if (!e.repeat && last.key === e.key && now - last.at < 320) {
          lastTap.current = { key: null, at: 0 };
          goTo(live.current.index + dir);
          flash(dir > 0 ? '下一个视频' : '上一个视频');
        } else {
          seekBy(dir * 5);
          if (!e.repeat) lastTap.current = { key: e.key, at: now };
        }
      }
    };
    addEventListener('keydown', onKey);
    return () => removeEventListener('keydown', onKey);
  }, [pref.mode, entries.length, el]);

  useEffect(() => () => clearTimeout(hudTimer.current), []);

  function flash(text) {
    setHud({ text, n: Date.now() });
    clearTimeout(hudTimer.current);
    hudTimer.current = setTimeout(() => setHud(null), 1500);
  }
  function goTo(i) {
    const n = live.current.entries.length;
    if (!n) return;
    const j = ((Math.floor(i) % n) + n) % n;
    setSegIndex(0);
    update((p) => ({ ...p, index: j, paused: false }));
  }
  function retry() {
    const item = live.current.current;
    if (item && item.kind === 'url') preResolved.current.delete(item.id);
    retried.current.delete(item && item.id);
    setReload((n) => n + 1);
    update({ paused: false });
    flash('正在重新加载视频…');
  }
  function select(i) {
    if (i === live.current.index) {
      if (live.current.source.error || live.current.play.error || !live.current.source.segments.length) retry();
      return;
    }
    goTo(i);
  }
  function next() { goTo(live.current.index + 1); }
  function prev() { goTo(live.current.index - 1); }
  function togglePlay() {
    const p = prefRef.current;
    update({ paused: !p.paused });
    flash(p.paused ? '继续播放' : '已暂停');
  }
  function setVolume(v) {
    const vol = clamp(Number(v) || 0, 0, 1);
    update({ volume: vol, muted: vol <= 0 });
  }
  function toggleMuted() {
    update((p) => ({ muted: !p.muted, volume: p.volume > 0 ? p.volume : 0.6 }));
  }
  function bumpVolume(d) {
    const p = prefRef.current;
    const vol = clamp(p.volume + d, 0, 1);
    update({ volume: vol, muted: vol <= 0 });
    flash(vol <= 0 ? '静音' : '音量 ' + Math.round(vol * 100) + '%');
  }
  function seekBy(d) {
    const v = el;
    if (!v) { flash('视频还没准备好'); return; }
    const dur = Number.isFinite(v.duration) && v.duration > 0 ? v.duration : (live.current.current?.duration || 0);
    const to = clamp((v.currentTime || 0) + d, 0, Math.max(0, dur - 0.15));
    try { v.currentTime = to; } catch { /* ignore */ }
    flash((d > 0 ? '+' : '') + Math.round(d) + ' 秒');
  }

  // ---- playlist CRUD ---------------------------------------------------------------------------------------------
  async function addFiles(files, onProgress) {
    const list = [...(files || [])];
    const room = Math.max(0, VIDEO_MAX - prefRef.current.list.length);
    const picked = list.slice(0, room);
    const rows = [];
    const reasons = [];
    for (let i = 0; i < picked.length; i++) {
      const f = picked[i];
      onProgress?.(i, picked.length, String(f.name || '').slice(0, 48));
      try {
        const meta = await probeVideoFile(f);
        const id = videoId();
        const name = String(f.name || '本地视频').slice(0, 120);
        await putRow({ id, blob: f, name, type: f.type || '', poster: meta.poster, duration: meta.duration, width: meta.width, height: meta.height, added: Date.now() });
        rows.push({ id, blob: f, poster: meta.poster, item: { id, kind: 'file', name, duration: meta.duration, width: meta.width, height: meta.height } });
      } catch (e) {
        const reason = e && e.name === 'QuotaExceededError' ? '浏览器存储空间不足' : (e?.message || '读取失败');
        reasons.push((f.name || '文件') + '：' + reason);
      }
    }
    if (rows.length) {
      setBlobs((m) => { const n = new Map(m); for (const r of rows) n.set(r.id, r.blob); return n; });
      setPosters((m) => { const n = new Map(m); for (const r of rows) n.set(r.id, r.poster); return n; });
      update((p) => ({
        list: [...p.list, ...rows.map((r) => r.item)].slice(0, VIDEO_MAX),
        index: p.list.length ? Math.min(p.list.length, VIDEO_MAX - 1) : 0, mode: 'video', paused: false,
      }));
    }
    return { added: rows.length, failed: reasons.length, dropped: list.length - picked.length, reasons };
  }

  async function addUrl(rawUrl) {
    const url = String(rawUrl || '').trim();
    if (!URL_RE.test(url)) throw new Error('请粘贴 http(s) 开头的视频链接');
    const p = prefRef.current;
    const dup = p.list.find((x) => x.kind === 'url' && x.url === url);
    if (dup) {
      const at = live.current.entries.findIndex((x) => x.id === dup.id);
      if (at >= 0) goTo(at);
      return { duplicate: true };
    }
    if (p.list.length >= VIDEO_MAX) throw new Error('最多 ' + VIDEO_MAX + ' 个视频');
    const r = await fetch('/hub-video/resolve?url=' + encodeURIComponent(url), { cache: 'no-store' });
    if (!r.ok) throw new Error('这台服务器还没有 /hub-video/ 视频接口，请重启服务器后再试');
    const j = await r.json();
    if (!j.ok) throw new Error(j.message || '链接解析失败');
    if (!Array.isArray(j.segments) || !j.segments.length) throw new Error('这个链接没有可播放的视频流');
    const item = {
      id: videoId(), kind: 'url', name: j.title || '视频链接', url,
      site: j.kind === 'bilibili' ? 'bilibili' : 'direct',
      bvid: j.bvid || '', page: Number(j.page) || 1,
      cover: j.cover || '', duration: Number(j.duration) || 0, quality: j.quality || '',
    };
    preResolved.current.set(item.id, { ...j, at: Date.now() });
    retried.current.delete(item.id);
    update((p2) => ({
      list: [...p2.list, item].slice(0, VIDEO_MAX),
      index: Math.min(p2.list.length, VIDEO_MAX - 1), mode: 'video', paused: false,
    }));
    return { added: true, kind: j.kind, title: item.name };
  }

  async function remove(id) {
    const removing = live.current.entries[live.current.index]?.id === id;
    if (removing) { try { el?.pause(); } catch { /* ignore */ } }
    try { await delRow(id); } catch { /* nothing stored */ }
    setBlobs((m) => { const n = new Map(m); n.delete(id); return n; });
    setPosters((m) => { const n = new Map(m); n.delete(id); return n; });
    preResolved.current.delete(id);
    retried.current.delete(id);
    update((p) => {
      const list = p.list.filter((x) => x.id !== id);
      return { list, index: clamp(p.index, 0, Math.max(0, list.length - 1)) };
    });
  }

  function move(id, by) {
    update((p) => {
      const i = p.list.findIndex((x) => x.id === id);
      const j = i + by;
      if (i < 0 || j < 0 || j >= p.list.length) return {};
      const list = [...p.list];
      list.splice(j, 0, list.splice(i, 1)[0]);
      return { list };
    });
  }

  async function clear() {
    try { await clearAll(); } catch { /* nothing stored */ }
    for (const url of urlRef.current.values()) URL.revokeObjectURL(url);
    urlRef.current.clear();
    setUrls(new Map());
    setBlobs(new Map());
    setPosters(new Map());
    preResolved.current.clear();
    retried.current.clear();
    update({ list: [], index: 0, paused: false });
  }

  return {
    pref, update, ready, entries, missing, index, current,
    attach, el, source, src, segIndex, play, hud,
    goTo, select, retry, next, prev, togglePlay, setVolume, toggleMuted, bumpVolume, seekBy, flash,
    addFiles, addUrl, remove, move, clear,
  };
}

// ---- the stage (the lobby layer) ---------------------------------------------------------------------------------
/** The hub's backdrop layer for a video: the element, the dim / grid the other modes share, and the transport HUD. */
export function VideoStage({ video, blur = 0, dim = 0, overlay = false }) {
  const { current, entries, index, play, source, hud } = video;
  const dur = play.duration || current?.duration || 0;
  const pct = dur > 0 ? clamp(play.time / dur, 0, 1) : 0;
  return html`<div class="hub-bg__vid" data-paused=${play.playing ? 'no' : 'yes'} data-loading=${source.loading ? 'on' : 'off'}
      style=${'--vid-blur:' + (blur || 0) + 'px'}>
    <video ref=${video.attach} class="hub-bg__video" playsInline preload="auto" aria-hidden="true"></video>
    <div class="hub-bg__shade" style=${'opacity:' + dim / 100}></div>
    ${source.error ? html`<div class="hub-vid__err"><b>视频没能播放</b><span>${source.error}</span></div>` : null}
    ${overlay ? html`<div class="hub-bg__grid"></div><div class="hub-bg__dots"></div>` : null}
    ${current ? html`<div class="hub-vid" aria-hidden="true">
      <span class="hub-vid__meta">
        <b class="hub-vid__n num">${index + 1}/${entries.length}</b>
        <span class="hub-vid__title">${current.name}</span>
        ${source.quality ? html`<span class="hub-vid__q num">${source.quality}</span>` : null}
      </span>
      <span class="hub-vid__hint num">↑↓ 音量 · ←→ 进度 · 连按两下 ←/→ 切换 · 空格暂停</span>
      ${hud ? html`<span class="hub-vid__hud" key=${hud.n}>${hud.text}</span>` : null}
      <span class="hub-vid__bar" aria-hidden="true"><b style=${'transform:scaleX(' + pct + ')'}></b></span>
    </div>` : null}
  </div>`;
}

/** The 视频背景 glyph of the 单张 / 轮播 / 视频 switch: a framed play mark. */
export function VideoGlyph() {
  return html`<svg class="bgset__modeicon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
    <path fill="currentColor" fill-rule="evenodd" d="M2 4h20v16H2zm2 2v12h16V6zm6 2.2 6 3.8-6 3.8z" />
    <path fill="currentColor" d="M4 4h3v1.4H5.4V9H4zm13 0h3v5h-1.6V5.4H17zM4 15h1.4v3.6H7V20H4zm14.6 0H20v5h-3v-1.4h1.6z" opacity=".55" />
  </svg>`;
}

// ---- the settings panel (inside the 大厅背景 dialog) --------------------------------------------------------------
/**
 * The 视频背景 settings panel: the video strip and its CRUD, local import, a link box (Bilibili / direct media),
 * the transport (previous / pause / next, volume), the three play modes and the mute switches. Pass it what useVideo() returned.
 */
export function VideoPanel({ video }) {
  const { pref, ready, entries, missing, index, current, play, source } = video;
  const fileRef = useRef(null);
  const [busy, setBusy] = useState('');
  const [url, setUrl] = useState('');
  const [adding, setAdding] = useState(false);
  const [urlErr, setUrlErr] = useState('');
  const browse = () => fileRef.current?.click();

  const onFiles = async (e) => {
    const input = e.currentTarget;
    const all = [...(input.files || [])];
    input.value = '';
    if (!all.length) return;
    const room = Math.max(0, VIDEO_MAX - pref.list.length);
    if (!room) { toast('最多 ' + VIDEO_MAX + ' 个视频，先移除几个再添加', 'warn'); return; }
    setBusy('准备读取…');
    try {
      const r = await video.addFiles(all, (i, n, name) => setBusy('正在读取 ' + (i + 1) + '/' + n + '：' + name));
      const bits = [];
      if (r.added) bits.push('已加入 ' + r.added + ' 个视频');
      if (r.dropped) bits.push('超出 ' + VIDEO_MAX + ' 个上限，忽略 ' + r.dropped + ' 个');
      if (r.failed) bits.push(r.failed + ' 个没能加入');
      if (r.added) toast(bits.join('；'), 'info');
      else toast(bits.join('；') + (r.reasons[0] ? '（' + r.reasons[0] + '）' : ''), 'warn');
    } finally {
      setBusy('');
    }
  };

  const addLink = async () => {
    const text = url.trim();
    if (!text || adding) return;
    setAdding(true); setUrlErr('');
    try {
      const r = await video.addUrl(text);
      setUrl('');
      toast(r.duplicate ? '这个链接已经在列表里了' : '已加入：' + (r.title || '视频'), 'info');
    } catch (e) {
      const msg = e?.message || '添加失败';
      setUrlErr(msg);
      toast(msg, 'warn');
    } finally { setAdding(false); }
  };

  const cur = current;
  const pctVol = Math.round(pref.volume * 100);
  return html`<div class="bgset__panel bgset__panel--vid">
    <input ref=${fileRef} type="file" accept=${VIDEO_ACCEPT} multiple hidden onChange=${onFiles} />
    <div class="bgset__carhead">
      <span class="bgset__count"><b class="num">${entries.length}</b><span>/${VIDEO_MAX} 个视频</span>
        ${missing > 0 ? html`<span class="bgset__warn">（${missing} 个在本浏览器里找不到了）</span>` : null}
      </span>
      <span class="bgset__row">
        <button type="button" class="btn btn--secondary btn--sm" disabled=${!!busy} onClick=${browse}>
          <span class="btn__label">${busy ? busy : '添加视频'}</span></button>
        <button type="button" class="btn btn--ghost btn--sm" disabled=${!pref.list.length} onClick=${() => video.clear()}>
          <span class="btn__label">清空</span></button>
      </span>
    </div>

    ${entries.length ? html`<div class="bgset__strip bgset__strip--vid" role="list" aria-label="视频顺序">
      ${entries.map((x, i) => {
        const cover = x.kind === 'file' ? x.poster : x.cover;
        return html`<div key=${x.id} role="listitem" title=${x.name}
          class=${'bgset__thumb bgset__thumb--vid' + (i === index ? ' is-playing' : '')}
          style=${cover ? 'background-image:url("' + cover + '")' : ''}
          onClick=${() => video.select(i)}>
          <span class="bgset__thumb-n num">${i + 1}</span>
          <span class=${'bgset__vid-badge bgset__vid-badge--' + (x.kind === 'file' ? 'file' : x.site)}>${x.kind === 'file' ? '本地' : x.site === 'bilibili' ? 'B站' : '链接'}</span>
          ${i === index ? html`<span class="bgset__vid-live">▶</span>` : null}
          <span class="bgset__thumb-acts">
            <button type="button" title="前移" disabled=${i === 0} onClick=${() => video.move(x.id, -1)}>◀</button>
            <button type="button" title="后移" disabled=${i === entries.length - 1} onClick=${() => video.move(x.id, 1)}>▶</button>
            <button type="button" title="移除这个视频" onClick=${() => video.remove(x.id)}>×</button>
          </span>
        </div>`;
      })}
    </div>` : html`<button type="button" class="bgset__drop bgset__drop--vid" onClick=${browse}>
      <span class="bgset__plus">+</span><span>添加视频（可一次多选，最多 ${VIDEO_MAX} 个；MP4 / WebM / MOV / MKV 等）</span>
    </button>`}

    ${!ready ? html`<p class="bgset__note">正在读取本机已保存的视频…</p>` : null}

    <div class="bgset__urladd">
      <span class="bgset__label">视频链接</span>
      <div class="bgset__urlrow">
        <input class="bgset__urlinput" type="url" value=${url} placeholder="粘贴 B 站视频链接（bilibili.com/video/BV… 或 b23.tv 短链），或 MP4 / WebM 直链"
          onInput=${(e) => { setUrl(e.currentTarget.value); if (urlErr) setUrlErr(''); }}
          onKeyDown=${(e) => { if (e.key === 'Enter') { e.preventDefault(); addLink(); } }} />
        <button type="button" class="btn btn--secondary btn--sm" disabled=${adding || !url.trim()} onClick=${addLink}>
          <span class="btn__label">${adding ? '解析中…' : '添加链接'}</span></button>
      </div>
      ${urlErr ? html`<p class="bgset__warn">${urlErr}</p>` : html`<p class="bgset__note">B 站链接会经本机服务器解析成 MP4 流；也支持任意 MP4 / WebM / MOV 直链。链接只保存地址，不占本机存储。</p>`}
    </div>

    ${cur ? html`<div class="bgset__vidnow">
      <div class="bgset__vidtitle">
        <b>${index + 1}. ${cur.name}</b>
        <span class="num">${source.quality || (cur.kind === 'file' ? '本地' : '链接')} · ${fmtTime(play.time)} / ${fmtTime(play.duration || cur.duration)}</span>
      </div>
      <div class="bgset__transport">
        <button type="button" class="btn btn--ghost btn--sm" onClick=${() => video.prev()}><span class="btn__label">◀ 上一个</span></button>
        <button type="button" class="btn btn--secondary btn--sm" onClick=${() => video.togglePlay()}>
          <span class="btn__label">${pref.paused ? '▶ 播放' : '⏸ 暂停'}</span></button>
        <button type="button" class="btn btn--ghost btn--sm" onClick=${() => video.next()}><span class="btn__label">下一个 ▶</span></button>
      </div>
      <div class="bgset__group" role="radiogroup" aria-label="播放方式">
        <span class="bgset__label">播放方式</span>
        <div class="bgset__presetrow">
          ${VIDEO_PLAY_MODES.map((m) => html`<button key=${m.id} type="button" role="radio" aria-checked=${pref.playMode === m.id ? 'true' : 'false'}
              class=${'bgset__preset' + (pref.playMode === m.id ? ' is-selected' : '')} title=${m.hint}
              onClick=${() => video.update({ playMode: m.id })}>
            <span class="bgset__tname">${m.name}</span><span class="bgset__ten">${m.en}</span>
          </button>`)}
        </div>
        <p class="bgset__note">${(VIDEO_PLAY_MODES.find((x) => x.id === pref.playMode) || VIDEO_PLAY_MODES[0]).hint}</p>
      </div>
      <label class="bgset__slider"><span>音量</span>
        <input type="range" min="0" max="100" step="1" value=${pctVol}
          onInput=${(e) => video.setVolume(Number(e.currentTarget.value) / 100)} />
        <b class="num">${pctVol}%</b></label>
      <div class="bgset__row bgset__vidopts">
        <label class="bgset__check"><input type="checkbox" checked=${pref.muted} onChange=${() => video.toggleMuted()} /><span>静音</span></label>
        <label class="bgset__check" title="视频背景开着时把游戏 BGM / 音效 / 干员语音静音，只留视频自己的声音"><input type="checkbox" checked=${pref.muteGame} onChange=${(e) => video.update({ muteGame: e.currentTarget.checked })} /><span>视频背景时静音游戏</span></label>
      </div>
      ${source.loading ? html`<p class="bgset__note">正在准备视频…</p>` : null}
      ${source.error ? html`<p class="bgset__warn">${source.error}</p>` : null}
      ${play.error ? html`<p class="bgset__warn">${play.error}${cur.kind === 'url' ? '（链接可能过期，重新点一下这个视频即可）' : ''}</p>` : null}
      ${source.error || play.error ? html`<div class="bgset__row"><button type="button" class="btn btn--secondary btn--sm" onClick=${() => video.retry()}><span class="btn__label">重试</span></button></div>` : null}
    </div>` : null}

    <p class="bgset__note">本地视频只保存在这台设备的浏览器里（IndexedDB，单个上限 512MB），不会上传；链接只保存地址。
      视频默认静音：按 ↑ 或取消「静音」即可开声音（会暂停 ♫ 大厅音乐）。
      视频背景开着时默认把游戏 BGM / 音效 / 干员语音静音，只留视频的声音；不需要可在上面取消「视频背景时静音游戏」。
      大厅里（对话框关着时）：↑↓ 调音量、←→ 调进度、连按两下 ← / → 切上一个 / 下一个、空格暂停。</p>
  </div>`;
}
