// Lobby hub backdrop (owner's request, 2026-10-13): original procedural scenes without a sun — 夜巡 (default), 霜原,
// 烬野, 静默 — or the player's own picture, or a 轮播图 of their own. The slideshow itself is a standalone module
// (ui/hubCarousel.js: its own pref, its own IndexedDB, its own panel); this file owns the generated skyline, the
// single custom picture and the look both modes share, and composes the slideshow into the hub and into the
// 大厅背景 dialog. A picture is downscaled on this device and kept in IndexedDB (never uploaded); every choice is a
// localStorage pref. The ridges and the stronghold silhouette are generated from fixed seeds, so every visit draws
// the same skyline.
import { html } from './components.js';
import { useEffect, useRef, useState } from '../../vendor/hooks.module.js';
import { loadPref, savePref } from '../store.js';
import { toast } from './toasts.js';
import { isImageFile, shrinkPicture } from './pictureFile.js';
import { useCarousel, CarouselStage, CarouselPanel, CarouselGlyph, CAROUSEL_MAX } from './hubCarousel.js';
import { useVideo, VideoStage, VideoPanel, VideoGlyph, VIDEO_MAX } from './hubVideo.js';

export const HUB_THEMES = [
  { id: 'night', name: '夜巡', en: 'NIGHT WATCH' },
  { id: 'frost', name: '霜原', en: 'FROSTLINE' },
  { id: 'ember', name: '烬野', en: 'EMBERFIELD' },
  { id: 'calm', name: '静默', en: 'SILENT' },
];
const THEME_IDS = HUB_THEMES.map((x) => x.id);
const PREF_KEY = 'hub.backdrop';
const MAX_EDGE = 2560; // longest edge kept of a custom picture
const MAX_FILE = 30 * 1024 * 1024;

const num = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

// ---- the single custom picture (IndexedDB: one Blob, no base64 bloat, no localStorage quota) ----------------------
const DB_NAME = 'sp-hub-backdrop';
const DB_VERSION = 2; // 2: it once held the slideshow too; ui/hubCarousel.js moved those bytes to its own database
const STORE = 'kv';
const KEY = 'image';
function withStore(mode, fn) {
  return new Promise((resolve, reject) => {
    if (!globalThis.indexedDB) { reject(new Error('no indexedDB')); return; }
    const open = indexedDB.open(DB_NAME, DB_VERSION);
    open.onupgradeneeded = () => {
      const db = open.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    open.onerror = () => reject(open.error);
    open.onsuccess = () => {
      const db = open.result;
      const tx = db.transaction(STORE, mode);
      const rq = fn(tx.objectStore(STORE));
      tx.oncomplete = () => { db.close(); resolve(rq.result); };
      tx.onerror = tx.onabort = () => { db.close(); reject(tx.error); };
    };
  });
}
const idbGet = () => withStore('readonly', (s) => s.get(KEY));
const idbPut = (blob) => withStore('readwrite', (s) => s.put(blob, KEY));
const idbDel = () => withStore('readwrite', (s) => s.delete(KEY));

/** The saved backdrop choice, sanitised. Which mode is on lives in the slideshow's own pref (ui/hubCarousel.js). */
export function loadBackdropPref() {
  const raw = loadPref(PREF_KEY, null);
  const o = raw && typeof raw === 'object' ? raw : {};
  return {
    theme: THEME_IDS.includes(o.theme) || o.theme === 'custom' ? o.theme : 'night',
    dim: clamp(num(o.dim, 45), 0, 85),
    blur: clamp(num(o.blur, 0), 0, 16),
    overlay: o.overlay !== false,
    motion: o.motion !== false,
  };
}

/**
 * Backdrop state for the lobby: the pref, the custom picture's object URL and the settings dialog's actions, plus the
 * slideshow from ui/hubCarousel.js (bg.carousel = its slides and CRUD, bg.car = its runner). ready turns true once the
 * stored picture was looked up (a custom backdrop draws nothing but the sky until then).
 */
export function useHubBackdrop() {
  const [pref, setPref] = useState(loadBackdropPref);
  const [imageUrl, setImageUrl] = useState(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let dead = false;
    idbGet().then((blob) => {
      if (!dead && blob instanceof Blob) setImageUrl(URL.createObjectURL(blob));
    }).catch(() => {}).finally(() => { if (!dead) setReady(true); });
    return () => { dead = true; };
  }, []);
  useEffect(() => () => { if (imageUrl) URL.revokeObjectURL(imageUrl); }, [imageUrl]);
  const update = (patch) => setPref((p) => {
    const next = { ...p, ...patch };
    savePref(PREF_KEY, next);
    return next;
  });

  /** @returns {Promise<boolean>} false when the picture is shown but could not be stored on this device */
  const setImage = async (file) => {
    const blob = await shrinkPicture(file, MAX_EDGE, 0.86);
    let saved = true;
    try { await idbPut(blob); } catch { saved = false; }
    setImageUrl(URL.createObjectURL(blob));
    update({ theme: 'custom' });
    return saved;
  };
  const clearImage = async () => {
    try { await idbDel(); } catch { /* nothing stored */ }
    setImageUrl(null);
    update({ theme: 'night', dim: 45, blur: 0 });
  };

  // the slideshow and the video background each own a pref; only one of the three modes is on at a time
  const slideshow = useCarousel({ motion: pref.motion });
  const video = useVideo();
  const videoMode = video.pref.mode === 'video';
  const carousel = !videoMode && slideshow.pref.mode === 'carousel';
  const mode = videoMode ? 'video' : carousel ? 'carousel' : 'single';
  const setMode = (m) => {
    if (m === 'video') { slideshow.update({ mode: 'single' }); video.update({ mode: 'video', paused: false }); return; }
    video.update({ mode: 'single' });
    slideshow.update({ mode: m === 'carousel' ? 'carousel' : 'single' });
  };
  const bg = {
    pref, update, imageUrl, ready, setImage, clearImage,
    carousel: slideshow, car: slideshow.car, video,
    mode, setMode,
  };
  return bg;
}

/** What the backdrop draws: a theme id, 'photo' (custom picture), 'carousel', or 'blank' (still loading). */
function sceneOf(bg) {
  if (bg.mode === 'video' && bg.video.current) return 'video';
  if (bg.mode === 'carousel' && bg.car.n > 0) return 'carousel';
  if (bg.pref.theme !== 'custom') return bg.pref.theme;
  return bg.imageUrl ? 'photo' : bg.ready ? 'night' : 'blank';
}
/** The data-hub-theme of the lobby root: the colour tokens shared by the backdrop, the radar and the swatches. */
export function backdropTheme(bg) {
  const s = sceneOf(bg);
  return s === 'photo' || s === 'carousel' || s === 'video' ? 'custom' : s === 'blank' ? 'night' : s;
}

// ---- the generated skyline (viewBox 1600x600, ground at the bottom) --------------------------------------------------
function rng(seed) {
  let s = seed >>> 0;
  return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 2 ** 32);
}
/** A ridge profile by midpoint displacement: 65 points across the width. */
function ridgePoints(seed, base, amp, rough) {
  const rnd = rng(seed);
  let pts = [base + (rnd() - 0.5) * amp, base + (rnd() - 0.5) * amp];
  let disp = amp;
  while (pts.length < 65) {
    const next = [];
    for (let i = 0; i < pts.length - 1; i++) next.push(pts[i], (pts[i] + pts[i + 1]) / 2 + (rnd() - 0.5) * disp);
    next.push(pts[pts.length - 1]);
    pts = next;
    disp *= rough;
  }
  return pts;
}
const DX = 1600 / 64;
const yAt = (pts, x) => {
  const i = Math.min(63, Math.max(0, Math.floor(x / DX)));
  const f = x / DX - i;
  return pts[i] * (1 - f) + pts[i + 1] * f;
};
const edge = (pts) => pts.map((y, i) => (i ? 'L' : 'M') + (i * DX).toFixed(1) + ' ' + y.toFixed(1)).join('');
const area = (pts) => edge(pts) + 'V600H0Z';

// the far range opens into a valley behind the title, its peaks frame the emblem from both sides
const FAR = ridgePoints(0x51a7, 286, 150, 0.56).map((y, i) => y + 70 * Math.exp(-(((i * DX - 800) / 340) ** 2)));
// the stronghold stands on a levelled shelf of the middle ridge (x 540-1060)
const MID = ridgePoints(0x7e11, 440, 90, 0.55).map((y, i) => {
  const x = i * DX;
  const w = x < 480 || x > 1120 ? 0 : x < 560 ? (x - 480) / 80 : x > 1040 ? (1120 - x) / 80 : 1;
  return y * (1 - w) + 424 * w;
});
const NEAR = ridgePoints(0x2b3c, 512, 46, 0.5);

/** A crenellated block: base -> up the left side -> merlons along the top -> down the right side. */
function block(x0, x1, top, base, h, w, gap) {
  let d = 'M' + x0 + ' ' + base + 'V' + top;
  for (let x = x0 + 3; x + w <= x1 - 3; x += w + gap) d += 'H' + x + 'V' + (top - h) + 'H' + (x + w) + 'V' + top;
  return d + 'H' + x1 + 'V' + base + 'Z';
}
const FORT = [
  block(540, 1060, 400, 440, 5, 7, 6), // curtain wall
  block(580, 616, 358, 440, 6, 6, 5),
  'M660 440V394L690 381L720 394V440Z', // depot
  block(760, 822, 324, 440, 7, 8, 6), // keep
  block(777, 805, 302, 330, 5, 5, 4),
  'M790 302V266h2v36zM785 278h12v1.6h-12z', // mast
  block(930, 962, 350, 440, 6, 6, 5),
  'M945 350V318h1.6v32z',
  block(1020, 1046, 368, 440, 5, 5, 4),
].join('');
const MASTS = [260, 1330].map((x) => {
  const y = yAt(FAR, x);
  return 'M' + x + ' ' + y.toFixed(1) + 'V' + (y - 46).toFixed(1) + 'h1.4V' + y.toFixed(1) + 'zM' + (x - 5) + ' ' + (y - 30).toFixed(1) + 'h11.4v1.2h-11.4z';
}).join('');
const MAST_TOPS = [260, 1330].map((x) => [x + 0.7, yAt(FAR, x) - 47]);
const BEACONS = [[791, 265, 2.4, 0], [945.8, 317, 2, 1.3], [598, 351, 1.6, 2.1], ...MAST_TOPS.map(([x, y], i) => [x, y, 1.6, 0.7 + i * 1.7])];
const WINDOWS = [[771, 338], [808, 350], [786, 372], [594, 380], [944, 372], [1031, 386], [700, 410], [870, 412]];

const MOTES = (() => {
  const rnd = rng(0x5eed);
  return Array.from({ length: 26 }, () => ({
    x: rnd() * 100, y: 28 + rnd() * 66, s: 1 + rnd() * 2.2, d: 14 + rnd() * 16, dl: rnd() * 30,
  }));
})();
const STARS = (() => {
  const rnd = rng(0x57a2);
  return Array.from({ length: 46 }, () => {
    const a = 0.25 + rnd() * 0.55;
    return (rnd() * 100).toFixed(2) + 'vw ' + (rnd() * 44).toFixed(2) + 'vh 0 ' + (rnd() < 0.15 ? '.6px' : '0')
      + ' rgba(220, 240, 235, ' + a.toFixed(2) + ')';
  }).join(',');
})();

function Scene({ theme }) {
  return html`
    <div class="hub-bg__sky"></div>
    ${theme === 'night' || theme === 'frost' ? html`<i class="hub-bg__stars" style=${'box-shadow:' + STARS}></i>` : null}
    <div class="hub-bg__haze"></div>
    ${theme !== 'calm' ? html`<div class="hub-bg__clouds"></div>` : null}
    <svg class="hub-bg__land" viewBox="0 0 1600 600" preserveAspectRatio="xMidYMax slice">
      <defs>
        <linearGradient id="hubFog" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" class="hub-fog-0" /><stop offset=".55" class="hub-fog-1" /><stop offset="1" class="hub-fog-0" />
        </linearGradient>
        <linearGradient id="hubBeam" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" class="hub-beam-0" /><stop offset="1" class="hub-beam-1" />
        </linearGradient>
      </defs>
      <path class="hub-bg__ridge hub-bg__ridge--far" d=${area(FAR)} />
      <path class="hub-bg__rim" d=${edge(FAR)} />
      <path class="hub-bg__ridge--far" d=${MASTS} />
      <rect x="0" y="290" width="1600" height="170" fill="url(#hubFog)" />
      ${theme === 'night' || theme === 'frost' ? html`<path class="hub-bg__beam" d="M791 300L700 -300H776Z" fill="url(#hubBeam)" />` : null}
      <path class="hub-bg__fort" d=${FORT} />
      <g class="hub-bg__windows">${WINDOWS.map(([x, y], i) => html`<rect key=${i} x=${x} y=${y} width="3" height="5" style=${'--dl:' + ((i * 1.9) % 7) + 's'} />`)}</g>
      <g class="hub-bg__beacons">${BEACONS.map(([x, y, r, dl], i) => html`<g key=${i} style=${'--dl:' + dl + 's'}>
        <circle class="hub-bg__beacon-glow" cx=${x} cy=${y} r=${r * 4} /><circle cx=${x} cy=${y} r=${r} /></g>`)}</g>
      <path class="hub-bg__ridge hub-bg__ridge--mid" d=${area(MID)} />
      <rect x="0" y="430" width="1600" height="120" fill="url(#hubFog)" opacity=".7" />
      <path class="hub-bg__ridge hub-bg__ridge--near" d=${area(NEAR)} />
    </svg>
    ${theme !== 'calm' ? html`<div class="hub-bg__motes">${MOTES.map((m, i) => html`<i key=${i} class="hub-bg__mote"
      style=${'left:' + m.x.toFixed(2) + '%;top:' + m.y.toFixed(2) + '%;width:' + m.s.toFixed(1) + 'px;height:' + m.s.toFixed(1) + 'px;--d:' + m.d.toFixed(1) + 's;--dl:-' + m.dl.toFixed(1) + 's'}></i>`)}</div>` : null}`;
}

/** The hub's backdrop layer (behind everything; never takes pointer events). */
export function HubBackdrop({ bg }) {
  const scene = sceneOf(bg);
  const { pref } = bg;
  const pic = scene === 'photo';
  return html`<div class="hub-bg" data-scene=${scene} data-mode=${bg.mode} data-motion=${pref.motion ? 'on' : 'off'} aria-hidden="true">
    ${pic
      ? html`<div class="hub-bg__photo" style=${'background-image:url("' + bg.imageUrl + '");filter:' + (pref.blur ? 'blur(' + pref.blur + 'px)' : 'none')}></div>
        <div class="hub-bg__shade" style=${'opacity:' + pref.dim / 100}></div>`
      : scene === 'video' ? html`<${VideoStage} video=${bg.video} blur=${pref.blur} dim=${pref.dim} overlay=${pref.overlay} />`
      : scene === 'carousel' ? html`<${CarouselStage} car=${bg.car} urls=${bg.carousel.urls} blur=${pref.blur} dim=${pref.dim} overlay=${pref.overlay} />`
      : scene === 'blank' ? html`<div class="hub-bg__sky"></div>` : html`<${Scene} theme=${scene} />`}
    ${scene !== 'photo' && scene !== 'carousel' && scene !== 'video' ? html`<div class="hub-bg__grid"></div><div class="hub-bg__dots"></div>` : null}
    <div class="hub-bg__scan"></div>
    <div class="hub-bg__vignette"></div>
  </div>`;
}


/** Range rings and a slow sweep behind the emblem (the sweep only with motion on, never on 静默). */
export function HubRadar({ bg }) {
  const sweep = bg.pref.motion && sceneOf(bg) !== 'calm';
  return html`<div class="hub-radar" aria-hidden="true">
    <svg viewBox="-240 -240 480 480">
      <circle r="92" /><circle r="152" /><circle class="hub-radar__ticks" r="214" />
      <path d="M-236 0H-176M176 0H236M0 -236V-176M0 176V236" />
    </svg>
    ${sweep ? html`<i class="hub-radar__sweep"></i>` : null}
  </div>`;
}

/** The topbar button glyph: a framed landscape. */
export function BackdropGlyph() {
  return html`<svg class="btn__icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
    <path fill="currentColor" fill-rule="evenodd" d="M2 4h20v16H2zm2 2v9.6l4.6-4.8 3.6 3.7 2.6-2.6L20 17V6zm13 1.6a1.8 1.8 0 1 1 0 3.6 1.8 1.8 0 0 1 0-3.6z" />
  </svg>`;
}

function Swatch({ theme }) {
  return html`<span class="bgset__swatch" data-hub-theme=${theme} aria-hidden="true">
    <svg viewBox="0 0 160 90" preserveAspectRatio="none">
      <path class="sw-far" d="M0 56L18 49L34 53L56 38L76 47L98 36L122 49L142 42L160 51V90H0Z" />
      <path class="sw-mid" d="M0 68L28 62L50 66H56V60H60V55H66V48H70V55H76V60H100V66L124 62L160 68V90H0Z" />
      <path class="sw-near" d="M0 80L40 74L90 79L130 73L160 78V90H0Z" />
      <circle class="sw-beacon" cx="68" cy="46" r="1.3" />
    </svg>
  </span>`;
}

/** The body of the 大厅背景 dialog: the 单张 / 轮播 switch, then this file's own scenes or the slideshow panel from
 *  ui/hubCarousel.js; the look both modes share (dim / blur / grid / motion) stays here. */
export function BackdropSettings({ bg }) {
  const { pref, update, imageUrl } = bg;
  const fileRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const browse = () => fileRef.current?.click();
  const onFile = async (e) => {
    const input = e.currentTarget;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    if (!isImageFile(file)) { toast('请选择图片文件', 'warn'); return; }
    if (file.size > MAX_FILE) { toast('图片太大（上限 30MB）', 'warn'); return; }
    setBusy(true);
    try {
      if (!(await bg.setImage(file))) toast('这个浏览器无法保存图片：本次可以使用，刷新后会恢复默认背景', 'warn');
    } catch {
      toast('这张图片读取失败，换一张试试', 'warn');
    } finally {
      setBusy(false);
    }
  };
  const custom = pref.theme === 'custom';
  const videoMode = bg.mode === 'video';
  const carousel = bg.mode === 'carousel';
  const slides = bg.carousel.stored.length;
  const vids = bg.video.entries.length;
  return html`<div class="bgset" data-mode=${bg.mode}>
    <div class="bgset__modes" role="radiogroup" aria-label="背景方式">
      <button type="button" role="radio" aria-checked=${!carousel && !videoMode ? 'true' : 'false'}
          class=${'bgset__mode' + (!carousel && !videoMode ? ' is-selected' : '')} onClick=${() => bg.setMode('single')}>
        <span class="bgset__modeicon"><${BackdropGlyph} /></span>
        <span class="bgset__name">单张背景</span><span class="bgset__en">SINGLE</span>
      </button>
      <button type="button" role="radio" aria-checked=${carousel ? 'true' : 'false'}
          class=${'bgset__mode' + (carousel ? ' is-selected' : '')} onClick=${() => bg.setMode('carousel')}>
        <span class="bgset__modeicon"><${CarouselGlyph} /></span>
        <span class="bgset__name">轮播图</span><span class="bgset__en">CAROUSEL ${slides}/${CAROUSEL_MAX}</span>
      </button>
      <button type="button" role="radio" aria-checked=${videoMode ? 'true' : 'false'}
          class=${'bgset__mode' + (videoMode ? ' is-selected' : '')} onClick=${() => bg.setMode('video')}>
        <span class="bgset__modeicon"><${VideoGlyph} /></span>
        <span class="bgset__name">视频背景</span><span class="bgset__en">VIDEO ${vids}/${VIDEO_MAX}</span>
      </button>
    </div>

    ${videoMode ? html`<${VideoPanel} video=${bg.video} />` : carousel ? html`<${CarouselPanel} slideshow=${bg.carousel} />` : html`<div class="bgset__panel">
      <div class="bgset__themes" role="radiogroup" aria-label="背景主题">
        ${HUB_THEMES.map((x) => html`<button key=${x.id} type="button" role="radio" aria-checked=${pref.theme === x.id ? 'true' : 'false'}
            class=${'bgset__theme' + (pref.theme === x.id ? ' is-selected' : '')} onClick=${() => update({ theme: x.id })}>
          <${Swatch} theme=${x.id} />
          <span class="bgset__name">${x.name}</span><span class="bgset__en">${x.en}</span>
        </button>`)}
        <button type="button" role="radio" aria-checked=${custom ? 'true' : 'false'} class=${'bgset__theme' + (custom ? ' is-selected' : '')}
            onClick=${() => (imageUrl ? update({ theme: 'custom' }) : browse())}>
          <span class="bgset__swatch bgset__swatch--custom" style=${imageUrl ? 'background-image:url("' + imageUrl + '")' : ''} aria-hidden="true">
            ${imageUrl ? null : html`<span class="bgset__plus">+</span>`}
          </span>
          <span class="bgset__name">自定义图片</span><span class="bgset__en">CUSTOM</span>
        </button>
      </div>
      <input ref=${fileRef} type="file" accept="image/*" hidden onChange=${onFile} />
      ${custom && imageUrl ? html`<div class="bgset__custom">
        <div class="bgset__row">
          <button type="button" class="btn btn--secondary btn--sm" disabled=${busy} onClick=${browse}><span class="btn__label">${busy ? '处理中…' : '更换图片'}</span></button>
          <button type="button" class="btn btn--ghost btn--sm" disabled=${busy} onClick=${() => bg.clearImage()}><span class="btn__label">移除图片</span></button>
        </div>
      </div>` : busy ? html`<p class="bgset__note">图片处理中…</p>` : null}
      ${slides ? html`<p class="bgset__note">轮播图里已有 ${slides} 张图片，切到「轮播图」即可播放。</p>` : null}
      ${vids ? html`<p class="bgset__note">视频背景里已有 ${vids} 个视频，切到「视频背景」即可播放。</p>` : null}
    </div>`}

    <div class="bgset__common">
      <span class="bgset__label">画面</span>
      <label class="bgset__slider"><span>暗化</span>
        <input type="range" min="0" max="85" step="1" value=${pref.dim} onInput=${(e) => update({ dim: Number(e.currentTarget.value) })} />
        <b class="num">${pref.dim}%</b></label>
      <label class="bgset__slider"><span>模糊</span>
        <input type="range" min="0" max="16" step="1" value=${pref.blur} onInput=${(e) => update({ blur: Number(e.currentTarget.value) })} />
        <b class="num">${pref.blur}px</b></label>
      <label class="bgset__check"><input type="checkbox" checked=${pref.overlay} onChange=${(e) => update({ overlay: e.currentTarget.checked })} /><span>叠加战术网格</span></label>
      <label class="bgset__check"><input type="checkbox" checked=${pref.motion} onChange=${(e) => update({ motion: e.currentTarget.checked })} /><span>动态效果（云层、粒子、雷达扫描、转场动画）</span></label>
    </div>
    <p class="bgset__note">图片和本地视频只保存在这台设备的浏览器里，不会上传到服务器；轮播图最多 ${CAROUSEL_MAX} 张，横版图片效果最好。
      点一下上面的缩略图就切到那一张（点大厅背景不会换页），也可以用 ← / → 换页、空格暂停。
      视频背景最多 ${VIDEO_MAX} 个，支持本机文件与 B 站 / 直链链接；关闭对话框后，↑↓ 音量、←→ 进度、连按两下 ← / → 切换视频、空格暂停。</p>
  </div>`;
}
