# 大厅视频背景（独立 mod）· `mod-hubvideo` v1.2.0

在大厅「大厅背景」对话框里加第三个页签 **视频背景**：最多 **20** 个视频，本地文件或链接都行；
本地视频存浏览器 IndexedDB，链接经**本机游戏服务器**同源取流（B 站页面 / b23.tv 短链 / MP4·WebM 直链）。
不依赖任何第三方网站的前端脚本，也不需要给页面放宽 CSP。

![视频背景面板](screenshots/panel.png)

![大厅里的视频背景](screenshots/lobby.png)

> 这是给 **0.3.0、且「大厅背景」里已经集成大厅轮播图** 的那一版做的。
> `manifest.json` 的 `requires` 钉住了安装前的六个文件哈希；目标不是那一版会拒绝写入（`--force` 可强行覆盖，备份仍然保留）。

## 装什么

| 文件 | 类型 | 作用 |
|---|---|---|
| `public/js/ui/hubVideo.js` | 新增 | 视频模块：播放列表、IndexedDB、视频面板、大厅舞台、键盘操作 |
| `public/js/ui/hubBackdrop.js` | 覆盖 | 把「视频背景」页签、舞台和面板组合进大厅背景（先备份） |
| `public/css/screens/lobby.css` | 追加 | 视频舞台 / 面板 / 三个页签的样式（标记 `大厅背景：视频背景`，只追加一次） |
| `server/hubVideo.js` | 新增 | `/hub-video/resolve`、`/hub-video/s/<token>`、`/hub-video/cover`：B 站解析 + 同源流代理 |
| `server/http/routes.js` | 打补丁 | 一条 import + 一条 `/hub-video/` 分支（先备份） |
| `public/js/audio.js` | 打补丁 | 加 `setVideoMuted()`：视频背景开着时静音游戏 BGM / 音效 / 语音（先备份；不覆盖玩家自己的静音设置） |

**为什么 B 站链接要经过服务器**：页面 CSP 是 `default-src 'self'`（`connect-src` / `media-src` / `img-src` 都只允许同源），
浏览器既不能直接 fetch B 站接口，也不能把 `bilivideo.com` 的地址交给 `<video>`。
`server/hubVideo.js` 用服务端的 Node fetch 调 B 站 `view` / `playurl`（带正常 UA + Referer，`platform=html5`，拿到带音轨的 MP4 durl），
再把字节以同源 URL 转给页面。这样本地文件和链接在 `<video>` 里是同一种东西，**音量 / 进度 / 暂停 / 切换全部可用**。

## 功能

- **本地视频**：一次多选，支持 MP4 / WebM / M4V / MOV / OGV / MKV / AVI 等（能否播放以浏览器解码为准；不支持会明确报错）。
  单个上限 512MB；文件与自动截取的封面存在本机 IndexedDB（`sp-hub-video`），不上传服务器。
- **视频链接**：
  - 哔哩哔哩：`https://www.bilibili.com/video/BV…`、`av…`、`b23.tv` 短链，可带 `?p=2` 分 P；
  - 直链：任意公网 MP4 / WebM / MOV 等；m3u8 / HLS 直播流暂不支持；
  - 链接只保存地址与标题/封面/时长等元数据，播放时再解析，CDN 签名过期会自动重取一次。
- **最多 20 个**（本地 + 链接一起算）；缩略图条可前移 / 后移 / 移除 / 清空，点缩略图直接切到那个视频。
- **三种播放方式**：
  - `单体循环`：当前视频放完重头再来，不切换；
  - `随机播放`：放完从列表里随机换一个（不会连续播同一个）；
  - `列表播放`：按列表顺序播下一个，最后一个播完回到第一个。
- **键盘**（大厅里、对话框关着、焦点不在输入框时）：
  - `↑` / `↓`：音量 ±5%，并自动取消静音；
  - `←` / `→`：进度 ∓/±5 秒；
  - **连按两下** `←` / `→`（350ms 内）：上一个 / 下一个视频（循环）；
  - `空格`：暂停 / 继续。
- 面板里还有：上一个 / 暂停 / 下一个、音量滑杆、静音、三种播放方式、视频背景时静音游戏、重试。
- 默认静音（浏览器自动播放策略）；按 `↑` 或取消「静音」开声音，视频有声时会自动暂停 ♫ 大厅音乐。
- **视频背景开着时默认把游戏声音全部静音**（BGM / 音效 / 干员语音），只留视频自己的声音；面板里的「视频背景时静音游戏」可以关掉。它走 `audio.setVideoMuted()`，是独立于玩家「设置 → 静音」的一层，切回单张 / 轮播即恢复原来的音量。
- 暗化 / 模糊 / 叠加战术网格 / 动态效果沿用「大厅背景」原有设置；播放方式默认单体循环，切出大厅或隐藏网页会暂停。

## 安装

需要 Node.js 22+。目标目录是含 `public/`、`server/`、`shared/` 的那一层（游戏根目录）。

    node install.mjs <目标目录>             # 安装（先备份到 <目标>/mod-hubvideo/backup/）
    node install.mjs <目标目录> --dry-run   # 只打印会做什么，不写任何文件
    node install.mjs <目标目录> --verify    # 安装后自检
    node install.mjs <目标目录> --uninstall # 还原四个被改文件、删掉两个新增文件
    node install.mjs <目标目录> --force     # 目标不是期望版本时强行覆盖

安装会：

1. 校验目标像《卫戍协议：盟约》checkout，且版本是 `0.3.0`；
2. 校验 `requires` 的六个文件（未安装过时）与 `manifest.json` 一致；
3. 备份 `hubBackdrop.js` / `lobby.css` / `routes.js` / `audio.js`；
4. 复制两个新文件与新的 `hubBackdrop.js`；
5. 往 `lobby.css` 末尾追加一次视频样式，往 `routes.js` 插入 import 与分支，往 `audio.js` 插入 `setVideoMuted()`；
6. 写 `<目标>/mod-hubvideo/mod-manifest.json`，`--uninstall` 靠它还原。

**装完必须重启游戏服务器**（`server/hubVideo.js` 与 `routes.js` 是服务端代码），然后玩家刷新页面。

## 撤销

    node install.mjs <目标目录> --uninstall

实测：在测试目标上安装 → 卸载，四个被改文件（含 `audio.js`）逐字节回到安装前，两个新增文件删除，`mod-hubvideo/` 目录清掉，零残留。
备份保留最长的一份，重复安装不会覆盖最早的备份。

## 和轮播图 / 其他 mod 的关系

- 本包**要求** `public/js/ui/hubCarousel.js`（大厅轮播图）与 `pictureFile.js` 已在目标里；没有就拒绝。
- 本包会覆盖 `hubBackdrop.js`。以后**重装大厅轮播图或大厅界面**时，视频背景会被盖掉；
  重新跑一次 `node install.mjs <目标>`（或 `--force`）即可恢复。
  反之先卸视频背景、再卸轮播图，最干净。
- 本地视频与设置只存在每个玩家自己的浏览器里（`sp.pref.hub.video` + IndexedDB `sp-hub-video`），
  与 `hub.carousel` / `hub.backdrop` 互不干扰；链接也不占本机存储。

## 已知限制

- B 站**番剧 / 直播 / 课程**链接（`/bangumi/play/ep…`、live.bilibili.com）不支持；普通投稿视频支持。
- 未登录状态下由 B 站接口给出的清晰度（常见 360P / 720P / 1080P，取决于稿件）就是能播的上限；大会员 / 充电专属会返回明确错误。
- 只提供 DASH 而没有 MP4 `durl` 的稿件会提示换一个视频；m3u8 / HLS 直链不支持。
- 本地视频单个 512MB；浏览器 IndexedDB 配额因浏览器而异，存不下会提示「浏览器存储空间不足」。
- 本机服务器会代理公网视频；已拒绝回环 / 内网 / 链路本地地址，并逐跳校验重定向，避免被当成内网扫描器。
  它只服务本进程自己签发的 token，不接受调用方直接传任意 URL 取流。
- 键盘只在**大厅**生效；打开「大厅背景」对话框或在输入框里打字时不会抢键。

## 验证记录（2026-10-18）

在 0.3.0 + 大厅轮播图的真实构建上，无头 Chrome（puppeteer-core）跑通：

- 三个页签出现；本地 MP4 上传 → 自动播放 → 关闭对话框 → 大厅舞台接管；
- B 站 `BV1GJ411x7h7` 链接解析成 720P MP4，同源 `/hub-video/s/…` 流播放，可拖动进度；
- `↑` 音量 60% → 70% 且取消静音；`→` 进度 +5 秒；`空格` 暂停/继续；
- 连按两下 `→` 从 2/2 切到 1/2；
- 刷新后视频模式、顺序、当前项、播放方式与本地文件都还在；
- 单体循环：6 秒短片放到结尾后仍是同一项、进度回到开头；列表播放：2/3 → 3/3、3/3 → 1/3；随机播放：1/3 → 2/3（不会连续同一项）；
- 20 个视频上限（第 21 个被忽略并提示）；
- 切回单张背景 → 舞台与 `<video>` 消失并暂停，再切回视频自动恢复；
- 视频模式 → `audio.videoMuted=true`、master gain 0；切回单张 → 1；面板「视频背景时静音游戏」关掉 → 1，再开 → 0；
- 无 pageerror / console.error。

脚本与截图在仓库的 `work/e2e-browser/`（`hub-video-e2e.cjs`、`hub-video-modes.cjs`、`hub-video-many.cjs`、`hub-video-audio-mute.cjs`、`hub-video-playmodes.cjs`）。

## 文件哈希

见 `manifest.json`。文本文件按 LF 归一化后计算 SHA-256（与仓库其他 mod 的安装器一致）。
