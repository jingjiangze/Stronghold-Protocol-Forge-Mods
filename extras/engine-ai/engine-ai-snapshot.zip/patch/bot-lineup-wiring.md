# 接线补丁：让 bot.js 消费学习库（humanPlans）

现状（实测）：`humanPlans` 在部署主流树只有导出、没有调用点；已接通的参考实现是
`_tmp/newrepo-server-agent/server/match/bot.js`（其树把 lineupLibrary 放在 server/ 根，
本包保持 plugins/mota/ 原深度，所以 import 路径不同——除此之外逐字相同）。

对 `server/match/bot.js`（本包内，0.2.5 原字节）做两处修改：

1) import 区新增一行（参考位置：bot.js:95 附近的 import 块）：

```js
import { humanPlans } from '../../plugins/mota/server/lineupLibrary.js';
```

2) `arrangeSteps` 的 final 分支（REHEARSAL_VARIANTS 循环之后，本包 bot.js 第 1641 行的 const plans 声明、第 1643 行 REHEARSAL_VARIANTS 循环）：

```js
  if (final && m.wave && m.botRehearsal > 0) {
    for (const v of REHEARSAL_VARIANTS) plans.push(yield* planLayoutSteps(m, ps, chosen, { ...LAYOUT_PARAMS, ...v }));
    // 新增：本关/本难度/本轮已录入的人类布阵，作为额外候选插在默认计划之后；
    // 截断到 botRehearsal 时保留它们，由彩排结果裁决（不优于参数计划的候选永不被选）
    plans.splice(1, 0, ...humanPlans(m, chosen));
  } else { ... }
```

生效前提：服务端设置 `SP_LINEUP_LIBRARY=<目录>`（未设时 humanPlans 恒返回 []，功能 off）。
种子文件放入该目录时用本包 data/ 的原文件名（lineups_<modeId>__<DIFFICULTY>.jsonl）。
