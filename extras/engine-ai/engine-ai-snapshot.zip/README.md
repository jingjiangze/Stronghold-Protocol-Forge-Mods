# 卫戍协议 · 引擎 AI 组件快照 v0.2.5+lineup（v2）

v1（sim/ai.js + match/bot.js + botEmotes.js 源码快照）+ 本次并入的**布阵学习库链**与 **Hank 胜局种子**。

## 包内结构（三块，各有字节口径）

- `server/sim/ai.js`、`server/match/bot.js`、`server/match/botEmotes.js` —— 与 v1 逐字节一致（sha 见 MANIFEST）。
- `plugins/mota/server/lineup*.js` + `plugins/mota/server/match/board.js` + `plugins/mota/server/sim/{constants,dir}.js` + `plugins/mota/shared/*` + `server/mods-lineup.js` —— 布阵学习库链（采集→落盘→检索），取自部署主流树原字节；桥 `server/mods-lineup.js` 的相对 import 在本包布局内可直接解析。
- `data/lineups_*.jsonl` —— Hank 胜局种子（合成布位，见 NOTICE-SEEDS.md）。

## 「引擎层不兼容」结论不变

ai.js / bot.js 脱离完整引擎检出无法运行（闭包 14 / 118 文件，数字与 v1 同源字节未变）。
学习库闭包实测 10 文件 / 2613 行 / 136.6 KB、纯相对 import——放回完整树同样原样可用。
唯一正确用法：把 server/ 与 plugins/ 放回版本一致（0.2.5）的完整引擎检出。

## 接线现状（重要，别被导出骗了）

- 写入侧已接通（prep.endPrep 暂存、settle.finish 仅 victory/defeat 落盘）。
- **检索侧 `humanPlans` 在主流部署树只有导出、没有调用点**；按 `patch/bot-lineup-wiring.md` 给 bot.js 打两行补丁后，学习库才真正参与决策（候选插在参数计划之后，由彩排裁决）。
- 功能开关是服务端 env `SP_LINEUP_LIBRARY`；未设置时读写全链恒空，属 opt-in。

## 种子数据口径

`data/*.jsonl` 的 `cells` 布位是**合成**的（Hank 原始数据只有干员 id，无坐标），
阵容与胜负记录来自 `HankDUMPLINGZhong/Stronghold-Protocol-AI` 胜局快照（victory=true 的 r13/bossPrep）。
每条记录带 `source:"seed-hank"` 与 origin/variant/seed 字段可回溯。GPL-3.0-or-later 署名见 NOTICE-SEEDS.md。
