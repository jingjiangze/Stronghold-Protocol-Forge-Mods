# 种子数据来源与许可

来源仓库：https://github.com/HankDUMPLINGZhong/Stronghold-Protocol-AI
提交：7d4e051b990a0b63578e33bddac44fe2c068b5e3
许可：GPL-3.0-or-later（与本源引擎快照许可证一致）。

该仓自称「卫戍协议 AI 策略合集」；本包只取其 benchmarks/results.json 中 victory=true 条目的
r13/bossPrep 干员列表（其 README 明示：选种不读取 AI 胜负；数据为 bot 自战诊断集，不代表多人房胜率）。
布位（row/col/dir）由本包按固定规则合成（行 9 起每 3 子一排、列 2/5/8、朝向上），不是任何人的原始摆位。
Hank 仓声明：非官方、非商业同人扩展；明日方舟角色名与美术/音频归各自权利方，本包不含任何游戏素材。
